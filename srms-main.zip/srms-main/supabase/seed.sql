-- Development seed data
-- Password: tomodachi (bcrypt hashed)
-- DO NOT USE IN PRODUCTION

-- Insert admin user
INSERT INTO app_users (id, email, password_hash, role, display_name, name, is_active)
VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'admin@example.com',
  '$2b$12$plOMVPz.9uJqXTb8c6HvxuqSb4zLb5Q9i3sorLhhWWG5D2cflaCMe',
  'admin',
  '管理者',
  '管理者 太郎',
  true
);

-- Insert provider (teacher) users
INSERT INTO app_users (id, email, password_hash, role, display_name, name, is_active)
VALUES
  (
    'b0000000-0000-0000-0000-000000000001',
    'provider1@example.com',
    '$2b$12$plOMVPz.9uJqXTb8c6HvxuqSb4zLb5Q9i3sorLhhWWG5D2cflaCMe',
    'provider',
    '講師A',
    '講師 一郎',
    true
  ),
  (
    'b0000000-0000-0000-0000-000000000002',
    'provider2@example.com',
    '$2b$12$plOMVPz.9uJqXTb8c6HvxuqSb4zLb5Q9i3sorLhhWWG5D2cflaCMe',
    'provider',
    '講師B',
    '講師 二郎',
    true
  ),
  (
    'b0000000-0000-0000-0000-000000000003',
    'provider3@example.com',
    '$2b$12$plOMVPz.9uJqXTb8c6HvxuqSb4zLb5Q9i3sorLhhWWG5D2cflaCMe',
    'provider',
    '講師C',
    '講師 三郎',
    true
  );

-- Insert providers table records (required for provider role)
INSERT INTO providers (user_id, hourly_rate_offline, hourly_rate_online)
VALUES
  ('b0000000-0000-0000-0000-000000000001', 2000, 1800),
  ('b0000000-0000-0000-0000-000000000002', 2500, 2200),
  ('b0000000-0000-0000-0000-000000000003', 3000, 2700);

-- Insert provider_profiles
INSERT INTO provider_profiles (user_id, name, job, hobbies, likes, lang_ja, lang_en, in_person, online, message)
VALUES
  ('b0000000-0000-0000-0000-000000000001', '講師 一郎', '英語教師', '読書、旅行', '音楽、映画', true, true, true, true, 'よろしくお願いします！'),
  ('b0000000-0000-0000-0000-000000000002', '講師 二郎', '数学教師', 'プログラミング', 'ゲーム', true, false, true, true, '一緒に頑張りましょう！'),
  ('b0000000-0000-0000-0000-000000000003', '講師 三郎', 'ピアノ講師', '作曲', 'クラシック音楽', true, false, false, true, '音楽を楽しみましょう！');

-- Insert receiver (student) users
INSERT INTO app_users (id, email, password_hash, role, display_name, name, is_active)
VALUES
  (
    'c0000000-0000-0000-0000-000000000001',
    'receiver1@example.com',
    '$2b$12$plOMVPz.9uJqXTb8c6HvxuqSb4zLb5Q9i3sorLhhWWG5D2cflaCMe',
    'receiver',
    '生徒A',
    '生徒 花子',
    true
  ),
  (
    'c0000000-0000-0000-0000-000000000002',
    'receiver2@example.com',
    '$2b$12$plOMVPz.9uJqXTb8c6HvxuqSb4zLb5Q9i3sorLhhWWG5D2cflaCMe',
    'receiver',
    '生徒B',
    '生徒 次郎',
    true
  ),
  (
    'c0000000-0000-0000-0000-000000000003',
    'receiver3@example.com',
    '$2b$12$plOMVPz.9uJqXTb8c6HvxuqSb4zLb5Q9i3sorLhhWWG5D2cflaCMe',
    'receiver',
    '生徒C',
    '生徒 三子',
    true
  );

-- Insert receivers table records (required for receiver role)
INSERT INTO receivers (user_id, notes)
VALUES
  ('c0000000-0000-0000-0000-000000000001', '英語を勉強したい'),
  ('c0000000-0000-0000-0000-000000000002', '数学を強化したい'),
  ('c0000000-0000-0000-0000-000000000003', 'ピアノを習いたい');
