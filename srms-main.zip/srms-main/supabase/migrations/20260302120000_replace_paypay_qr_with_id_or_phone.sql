-- providersテーブルのPayPay受取情報をQR URLからID/電話番号へ移行
ALTER TABLE public.providers
  ADD COLUMN IF NOT EXISTS paypay_id text,
  ADD COLUMN IF NOT EXISTS paypay_phone_number text;

ALTER TABLE public.providers
  DROP COLUMN IF EXISTS paypay_qr_url;
