
  create table "public"."receiver_profiles" (
    "id" uuid not null default gen_random_uuid(),
    "user_id" uuid not null,
    "name" text,
    "age" integer,
    "gender" text,
    "nationality" text,
    "self_introduction" text,
    "learning_goals" text,
    "created_at" timestamp without time zone default now(),
    "updated_at" timestamp without time zone default now()
      );


alter table "public"."receiver_profiles" enable row level security;

CREATE UNIQUE INDEX receiver_profiles_pkey ON public.receiver_profiles USING btree (id);

alter table "public"."receiver_profiles" add constraint "receiver_profiles_pkey" PRIMARY KEY using index "receiver_profiles_pkey";

alter table "public"."receiver_profiles" add constraint "receiver_profiles_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public.app_users(id) ON DELETE CASCADE not valid;

alter table "public"."receiver_profiles" validate constraint "receiver_profiles_user_id_fkey";

grant delete on table "public"."receiver_profiles" to "anon";

grant insert on table "public"."receiver_profiles" to "anon";

grant references on table "public"."receiver_profiles" to "anon";

grant select on table "public"."receiver_profiles" to "anon";

grant trigger on table "public"."receiver_profiles" to "anon";

grant truncate on table "public"."receiver_profiles" to "anon";

grant update on table "public"."receiver_profiles" to "anon";

grant delete on table "public"."receiver_profiles" to "authenticated";

grant insert on table "public"."receiver_profiles" to "authenticated";

grant references on table "public"."receiver_profiles" to "authenticated";

grant select on table "public"."receiver_profiles" to "authenticated";

grant trigger on table "public"."receiver_profiles" to "authenticated";

grant truncate on table "public"."receiver_profiles" to "authenticated";

grant update on table "public"."receiver_profiles" to "authenticated";

grant delete on table "public"."receiver_profiles" to "postgres";

grant insert on table "public"."receiver_profiles" to "postgres";

grant references on table "public"."receiver_profiles" to "postgres";

grant select on table "public"."receiver_profiles" to "postgres";

grant trigger on table "public"."receiver_profiles" to "postgres";

grant truncate on table "public"."receiver_profiles" to "postgres";

grant update on table "public"."receiver_profiles" to "postgres";

grant delete on table "public"."receiver_profiles" to "service_role";

grant insert on table "public"."receiver_profiles" to "service_role";

grant references on table "public"."receiver_profiles" to "service_role";

grant select on table "public"."receiver_profiles" to "service_role";

grant trigger on table "public"."receiver_profiles" to "service_role";

grant truncate on table "public"."receiver_profiles" to "service_role";

grant update on table "public"."receiver_profiles" to "service_role";


  create policy "receiver_profiles_self"
  on "public"."receiver_profiles"
  as permissive
  for all
  to public
using (((((current_setting('request.jwt.claims'::text, true))::jsonb ->> 'role'::text) = 'admin'::text) OR ((user_id)::text = ((current_setting('request.jwt.claims'::text, true))::jsonb ->> 'user_id'::text))))
with check (((user_id)::text = ((current_setting('request.jwt.claims'::text, true))::jsonb ->> 'user_id'::text)));



