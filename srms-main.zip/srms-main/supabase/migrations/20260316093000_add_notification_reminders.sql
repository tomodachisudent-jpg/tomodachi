CREATE TABLE IF NOT EXISTS "public"."notification_jobs" (
    "id" bigserial NOT NULL,
    "reservation_id" bigint NOT NULL,
    "recipient_role" text NOT NULL,
    "notification_type" text DEFAULT 'reservation_reminder' NOT NULL,
    "reservation_snapshot" jsonb NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "notification_jobs_recipient_role_check" CHECK (("recipient_role" = ANY (ARRAY['provider'::text, 'receiver'::text]))),
    CONSTRAINT "notification_jobs_notification_type_check" CHECK (("notification_type" = 'reservation_reminder'::text))
);

ALTER TABLE "public"."notification_jobs" OWNER TO "postgres";

ALTER TABLE ONLY "public"."notification_jobs"
    ADD CONSTRAINT "notification_jobs_pkey" PRIMARY KEY ("id");

ALTER TABLE ONLY "public"."notification_jobs"
    ADD CONSTRAINT "notification_jobs_reservation_id_fkey" FOREIGN KEY ("reservation_id") REFERENCES "public"."reservations"("id") ON DELETE CASCADE;

CREATE INDEX "notification_jobs_reservation_active_idx"
    ON "public"."notification_jobs" USING btree ("reservation_id", "is_active", "recipient_role");

CREATE TABLE IF NOT EXISTS "public"."notification_deliveries" (
    "id" bigserial NOT NULL,
    "job_id" bigint NOT NULL,
    "channel" text NOT NULL,
    "stage" text NOT NULL,
    "reminder_offset_minutes" integer NOT NULL,
    "scheduled_for" timestamp with time zone NOT NULL,
    "status" text DEFAULT 'pending' NOT NULL,
    "attempt_count" integer DEFAULT 0 NOT NULL,
    "next_retry_at" timestamp with time zone,
    "last_error" text,
    "dedupe_key" text NOT NULL,
    "sent_at" timestamp with time zone,
    "processed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "notification_deliveries_channel_check" CHECK (("channel" = ANY (ARRAY['mail'::text, 'line'::text]))),
    CONSTRAINT "notification_deliveries_status_check" CHECK (("status" = ANY (ARRAY['pending'::text, 'processing'::text, 'sent'::text, 'failed'::text, 'skipped'::text, 'canceled'::text]))),
    CONSTRAINT "notification_deliveries_attempt_count_check" CHECK (("attempt_count" >= 0))
);

ALTER TABLE "public"."notification_deliveries" OWNER TO "postgres";

ALTER TABLE ONLY "public"."notification_deliveries"
    ADD CONSTRAINT "notification_deliveries_pkey" PRIMARY KEY ("id");

ALTER TABLE ONLY "public"."notification_deliveries"
    ADD CONSTRAINT "notification_deliveries_dedupe_key_key" UNIQUE ("dedupe_key");

ALTER TABLE ONLY "public"."notification_deliveries"
    ADD CONSTRAINT "notification_deliveries_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."notification_jobs"("id") ON DELETE CASCADE;

CREATE INDEX "notification_deliveries_job_idx"
    ON "public"."notification_deliveries" USING btree ("job_id");

CREATE INDEX "notification_deliveries_due_idx"
    ON "public"."notification_deliveries" USING btree ((COALESCE("next_retry_at", "scheduled_for")))
    WHERE ("status" = 'pending'::text);

ALTER TABLE "public"."notification_jobs" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."notification_deliveries" ENABLE ROW LEVEL SECURITY;

GRANT ALL ON TABLE "public"."notification_jobs" TO "service_role";
GRANT ALL ON TABLE "public"."notification_deliveries" TO "service_role";
GRANT ALL ON SEQUENCE "public"."notification_jobs_id_seq" TO "service_role";
GRANT ALL ON SEQUENCE "public"."notification_deliveries_id_seq" TO "service_role";
