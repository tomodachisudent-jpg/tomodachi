-- salary_transfersテーブルの作成（給与振込済み記録）
CREATE TABLE IF NOT EXISTS "public"."salary_transfers" (
    "id" bigserial NOT NULL,
    "provider_id" "uuid" NOT NULL,
    "year" integer NOT NULL,
    "month" integer NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid" NOT NULL,
    CONSTRAINT "salary_transfers_month_check" CHECK (("month" >= 1 AND "month" <= 12))
);

ALTER TABLE "public"."salary_transfers" OWNER TO "postgres";

-- 主キー
ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_pkey" PRIMARY KEY ("id");

-- ユニーク制約: 1人の先生につき同一年月のレコードは1件のみ
ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_provider_year_month_key" UNIQUE ("provider_id", "year", "month");

-- 外部キー: provider_id → providers.user_id
ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "public"."providers"("user_id") ON DELETE RESTRICT;

-- 外部キー: created_by → app_users.id
ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."app_users"("id");

-- RLS有効化
ALTER TABLE "public"."salary_transfers" ENABLE ROW LEVEL SECURITY;

-- RLSポリシー: adminロールのみ全操作（SELECT, INSERT）を許可
CREATE POLICY "salary_transfers_admin_select" ON "public"."salary_transfers"
    FOR SELECT USING ((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text");

CREATE POLICY "salary_transfers_admin_insert" ON "public"."salary_transfers"
    FOR INSERT WITH CHECK ((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text");

-- テーブル権限付与
GRANT ALL ON TABLE "public"."salary_transfers" TO "anon";
GRANT ALL ON TABLE "public"."salary_transfers" TO "authenticated";
GRANT ALL ON TABLE "public"."salary_transfers" TO "service_role";

-- シーケンス権限付与
GRANT ALL ON SEQUENCE "public"."salary_transfers_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."salary_transfers_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."salary_transfers_id_seq" TO "service_role";
