-- 生徒プロフィール拡張フィールドの追加
-- 顔写真、学習歴、資格、特技、日本語レベル

-- receiver_profiles テーブルに新規カラムを追加
ALTER TABLE "public"."receiver_profiles"
  ADD COLUMN IF NOT EXISTS "profile_photo_url" TEXT,
  ADD COLUMN IF NOT EXISTS "learning_history" TEXT,
  ADD COLUMN IF NOT EXISTS "qualifications" TEXT,
  ADD COLUMN IF NOT EXISTS "special_skills" TEXT,
  ADD COLUMN IF NOT EXISTS "japanese_level" TEXT;

-- コメント追加（ドキュメント用）
COMMENT ON COLUMN "public"."receiver_profiles"."profile_photo_url" IS '顔写真の公開URL（必須項目）';
COMMENT ON COLUMN "public"."receiver_profiles"."learning_history" IS '学習歴（任意項目）';
COMMENT ON COLUMN "public"."receiver_profiles"."qualifications" IS '資格（任意項目）';
COMMENT ON COLUMN "public"."receiver_profiles"."special_skills" IS '特技（任意項目）';
COMMENT ON COLUMN "public"."receiver_profiles"."japanese_level" IS '日本語のレベル（初心者/中級者/上級者、任意項目）';
