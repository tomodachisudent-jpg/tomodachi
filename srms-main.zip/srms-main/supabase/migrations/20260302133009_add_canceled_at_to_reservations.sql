-- reservations テーブルに canceled_at カラムを追加する
-- キャンセル実行日時を正確に記録するため（canceled_at IS NOT NULL の月次カウントに使用）
ALTER TABLE "public"."reservations"
  ADD COLUMN IF NOT EXISTS "canceled_at" TIMESTAMP WITH TIME ZONE;
