-- enum型の作成
CREATE TYPE public.payment_method_type AS ENUM ('hand', 'bank', 'paypay');

-- providersテーブルに振込方法カラムを追加
ALTER TABLE public.providers
  ADD COLUMN payment_method public.payment_method_type DEFAULT 'hand' NOT NULL,
  ADD COLUMN bank_name text,
  ADD COLUMN bank_branch text,
  ADD COLUMN bank_account_type text,
  ADD COLUMN bank_account_number text,
  ADD COLUMN bank_account_holder text,
  ADD COLUMN paypay_qr_url text;
