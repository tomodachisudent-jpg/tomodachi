alter table app_users enable row level security;
alter table providers enable row level security;
alter table receivers enable row level security;
alter table receiver_profiles enable row level security;
alter table shifts enable row level security;
alter table reservations enable row level security;
alter table service_logs enable row level security;
-- app_users
create policy app_users_select_self on app_users for
select using (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
    or id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
  );
create policy app_users_update_self on app_users for
update using (
    id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
  ) with check (
    id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
  );
-- providers
create policy providers_self on providers for all using (
  (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
  )
  or user_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
);
-- receivers
create policy receivers_self on receivers for all using (
  (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
  )
  or user_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
);
-- receiver_profiles（生徒プロフィール）
create policy receiver_profiles_select_own on receiver_profiles for
select using (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'receiver'
    and user_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
  );
create policy receiver_profiles_insert_own on receiver_profiles for
insert with check (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'receiver'
    and user_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
  );
create policy receiver_profiles_update_own on receiver_profiles for
update using (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'receiver'
    and user_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
  );
-- shifts
create policy shifts_provider_own on shifts for all using (
  (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
  )
  or provider_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
);
create policy shifts_receiver_read on shifts for
select using (
    (
      current_setting('request.jwt.claims', true)::jsonb->>'role'
    ) in ('receiver', 'admin', 'provider')
  );
-- reservations
create policy reservations_receiver_own on reservations for all using (
  (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
  )
  or receiver_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
);
create policy reservations_provider_view on reservations for
select using (
    exists(
      select 1
      from shifts s
      where s.id = reservations.shift_id
        and s.provider_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
    )
    or (
      current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
    )
  );
-- service_logs
create policy logs_provider_own on service_logs for all using (
  (
    current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
  )
  or provider_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
);
create policy logs_receiver_read on service_logs for
select using (
    receiver_id::text = current_setting('request.jwt.claims', true)::jsonb->>'user_id'
    or (
      current_setting('request.jwt.claims', true)::jsonb->>'role' = 'admin'
    )
  );
