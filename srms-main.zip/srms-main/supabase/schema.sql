

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE TYPE "public"."app_role" AS ENUM (
    'admin',
    'provider',
    'receiver'
);


ALTER TYPE "public"."app_role" OWNER TO "postgres";


CREATE TYPE "public"."payment_method_type" AS ENUM (
    'hand',
    'bank',
    'paypay'
);


ALTER TYPE "public"."payment_method_type" OWNER TO "postgres";


CREATE TYPE "public"."reservation_status" AS ENUM (
    'reserved',
    'canceled',
    'completed'
);


ALTER TYPE "public"."reservation_status" OWNER TO "postgres";


CREATE TYPE "public"."role_enum" AS ENUM (
    'provider',
    'customer',
    'admin'
);


ALTER TYPE "public"."role_enum" OWNER TO "postgres";


CREATE TYPE "public"."service_type" AS ENUM (
    'online',
    'onsite'
);


ALTER TYPE "public"."service_type" OWNER TO "postgres";


CREATE TYPE "public"."shift_type" AS ENUM (
    'offline',
    'online'
);


ALTER TYPE "public"."shift_type" OWNER TO "postgres";


CREATE TYPE "public"."userrole" AS ENUM (
    'admin',
    'provider',
    'customer'
);


ALTER TYPE "public"."userrole" OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."hours_between"("t1" timestamp with time zone, "t2" timestamp with time zone) RETURNS numeric
    LANGUAGE "sql" IMMUTABLE PARALLEL SAFE
    AS $$
  select extract(epoch from (t2 - t1)) / 3600.0;
$$;


ALTER FUNCTION "public"."hours_between"("t1" timestamp with time zone, "t2" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."prevent_last_admin_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  if old.role = 'admin' then
    perform 1 from app_users where role='admin' and id <> old.id and is_active = true;
    if not found then
      raise exception 'At least one active admin must remain.';
    end if;
  end if;
  return old;
end;
$$;


ALTER FUNCTION "public"."prevent_last_admin_delete"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."prevent_last_admin_downgrade"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare other_admin_exists boolean;
begin
  if old.role='admin' and new.role <> 'admin' then
    select exists(
      select 1 from app_users where role='admin' and id <> old.id and is_active = true
    ) into other_admin_exists;
    if not other_admin_exists then
      raise exception 'Cannot downgrade the last active admin.';
    end if;
  end if;
  return new;
end;
$$;


ALTER FUNCTION "public"."prevent_last_admin_downgrade"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."app_users" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "email" "text" NOT NULL,
    "password_hash" "text" NOT NULL,
    "role" "public"."app_role" NOT NULL,
    "display_name" "text" NOT NULL,
    "slack_webhook" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "name" "text",
    "line_user_id" "text",
    "login_fail_count" smallint
);


ALTER TABLE "public"."app_users" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."providers" (
    "user_id" "uuid" NOT NULL,
    "hourly_rate_offline" numeric(10,2) DEFAULT 2000 NOT NULL,
    "hourly_rate_online" numeric(10,2) DEFAULT 1800 NOT NULL,
    "payment_method" "public"."payment_method_type" DEFAULT 'hand'::"public"."payment_method_type" NOT NULL,
    "bank_name" "text",
    "bank_branch" "text",
    "bank_account_type" "text",
    "bank_account_number" "text",
    "bank_account_holder" "text",
    "paypay_id" "text",
    "paypay_phone_number" "text"
);


ALTER TABLE "public"."providers" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."service_logs" (
    "id" bigint NOT NULL,
    "reservation_id" bigint NOT NULL,
    "provider_id" "uuid" NOT NULL,
    "receiver_id" "uuid" NOT NULL,
    "start_at" timestamp with time zone NOT NULL,
    "end_at" timestamp with time zone NOT NULL,
    "s_type" "public"."shift_type" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "service_logs_check" CHECK (("end_at" > "start_at"))
);


ALTER TABLE "public"."service_logs" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."payroll_view" AS
 SELECT "sl"."provider_id",
    "date_trunc"('month'::"text", "sl"."start_at") AS "month",
    "sum"(
        CASE
            WHEN ("sl"."s_type" = 'offline'::"public"."shift_type") THEN ("public"."hours_between"("sl"."start_at", "sl"."end_at") * "p"."hourly_rate_offline")
            ELSE ("public"."hours_between"("sl"."start_at", "sl"."end_at") * "p"."hourly_rate_online")
        END) AS "gross_pay"
   FROM ("public"."service_logs" "sl"
     JOIN "public"."providers" "p" ON (("p"."user_id" = "sl"."provider_id")))
  GROUP BY "sl"."provider_id", ("date_trunc"('month'::"text", "sl"."start_at"));


ALTER VIEW "public"."payroll_view" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."provider_profiles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "name" "text",
    "job" "text",
    "hobbies" "text",
    "likes" "text",
    "lang_ja" boolean DEFAULT false,
    "lang_en" boolean DEFAULT false,
    "lang_other" boolean DEFAULT false,
    "in_person" boolean DEFAULT false,
    "online" boolean DEFAULT false,
    "message" "text",
    "skills" "text",
    "experience" "text",
    "lesson_style" "text",
    "photo_url" "text",
    "created_at" timestamp without time zone DEFAULT "now"(),
    "updated_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."provider_profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."receiver_profiles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "name" "text",
    "age" integer,
    "gender" "text",
    "nationality" "text",
    "self_introduction" "text",
    "learning_goals" "text",
    "created_at" timestamp without time zone DEFAULT "now"(),
    "updated_at" timestamp without time zone DEFAULT "now"(),
    "profile_photo_url" "text",
    "learning_history" "text",
    "qualifications" "text",
    "special_skills" "text",
    "japanese_level" "text"
);


ALTER TABLE "public"."receiver_profiles" OWNER TO "postgres";


COMMENT ON COLUMN "public"."receiver_profiles"."profile_photo_url" IS '顔写真の公開URL（必須項目）';



COMMENT ON COLUMN "public"."receiver_profiles"."learning_history" IS '学習歴（任意項目）';



COMMENT ON COLUMN "public"."receiver_profiles"."qualifications" IS '資格（任意項目）';



COMMENT ON COLUMN "public"."receiver_profiles"."special_skills" IS '特技（任意項目）';



COMMENT ON COLUMN "public"."receiver_profiles"."japanese_level" IS '日本語のレベル（初心者/中級者/上級者、任意項目）';



CREATE TABLE IF NOT EXISTS "public"."receivers" (
    "user_id" "uuid" NOT NULL,
    "notes" "text"
);


ALTER TABLE "public"."receivers" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."reservations" (
    "id" bigint NOT NULL,
    "shift_id" bigint NOT NULL,
    "receiver_id" "uuid" NOT NULL,
    "status" "public"."reservation_status" DEFAULT 'reserved'::"public"."reservation_status" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "canceled_at" timestamp with time zone
);


ALTER TABLE "public"."reservations" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."notification_jobs" (
    "id" bigserial NOT NULL,
    "reservation_id" bigint NOT NULL,
    "recipient_role" text NOT NULL,
    "notification_type" text DEFAULT 'reservation_reminder'::text NOT NULL,
    "reservation_snapshot" jsonb NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "notification_jobs_recipient_role_check" CHECK (("recipient_role" = ANY (ARRAY['provider'::text, 'receiver'::text]))),
    CONSTRAINT "notification_jobs_notification_type_check" CHECK (("notification_type" = 'reservation_reminder'::text))
);


ALTER TABLE "public"."notification_jobs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."notification_deliveries" (
    "id" bigserial NOT NULL,
    "job_id" bigint NOT NULL,
    "channel" text NOT NULL,
    "stage" text NOT NULL,
    "reminder_offset_minutes" integer NOT NULL,
    "scheduled_for" timestamp with time zone NOT NULL,
    "status" text DEFAULT 'pending'::text NOT NULL,
    "attempt_count" integer DEFAULT 0 NOT NULL,
    "next_retry_at" timestamp with time zone,
    "last_error" text,
    "dedupe_key" text NOT NULL,
    "sent_at" timestamp with time zone,
    "processed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "notification_deliveries_channel_check" CHECK (("channel" = ANY (ARRAY['mail'::text, 'line'::text]))),
    CONSTRAINT "notification_deliveries_status_check" CHECK (("status" = ANY (ARRAY['pending'::text, 'processing'::text, 'sent'::text, 'failed'::text, 'skipped'::text, 'canceled'::text]))),
    CONSTRAINT "notification_deliveries_attempt_count_check" CHECK (("attempt_count" >= 0))
);


ALTER TABLE "public"."notification_deliveries" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."reservations_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."reservations_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."reservations_id_seq" OWNED BY "public"."reservations"."id";



CREATE TABLE IF NOT EXISTS "public"."room_comments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "room_id" "uuid",
    "user_id" "uuid",
    "content" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."room_comments" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."rooms" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "shift_id" bigint,
    "created_by" "uuid",
    "meeting_url" "text",
    "materials" "text",
    "created_at" timestamp without time zone DEFAULT "now"(),
    "updated_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."rooms" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."salary_transfers" (
    "id" bigint NOT NULL,
    "provider_id" "uuid" NOT NULL,
    "year" integer NOT NULL,
    "month" integer NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid" NOT NULL,
    CONSTRAINT "salary_transfers_month_check" CHECK ((("month" >= 1) AND ("month" <= 12)))
);


ALTER TABLE "public"."salary_transfers" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."salary_transfers_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."salary_transfers_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."salary_transfers_id_seq" OWNED BY "public"."salary_transfers"."id";



CREATE SEQUENCE IF NOT EXISTS "public"."service_logs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."service_logs_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."service_logs_id_seq" OWNED BY "public"."service_logs"."id";



CREATE TABLE IF NOT EXISTS "public"."shifts" (
    "id" bigint NOT NULL,
    "provider_id" "uuid" NOT NULL,
    "start_at" timestamp with time zone NOT NULL,
    "end_at" timestamp with time zone NOT NULL,
    "s_type" "public"."shift_type" NOT NULL,
    "is_locked" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "shifts_check" CHECK (("end_at" > "start_at"))
);


ALTER TABLE "public"."shifts" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."shifts_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."shifts_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."shifts_id_seq" OWNED BY "public"."shifts"."id";



ALTER TABLE ONLY "public"."reservations" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."reservations_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."salary_transfers" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."salary_transfers_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."service_logs" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."service_logs_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."shifts" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."shifts_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."app_users"
    ADD CONSTRAINT "app_users_email_key" UNIQUE ("email");



ALTER TABLE ONLY "public"."app_users"
    ADD CONSTRAINT "app_users_line_user_id_key" UNIQUE ("line_user_id");



ALTER TABLE ONLY "public"."app_users"
    ADD CONSTRAINT "app_users_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."provider_profiles"
    ADD CONSTRAINT "provider_profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."notification_jobs"
    ADD CONSTRAINT "notification_jobs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."notification_deliveries"
    ADD CONSTRAINT "notification_deliveries_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."notification_deliveries"
    ADD CONSTRAINT "notification_deliveries_dedupe_key_key" UNIQUE ("dedupe_key");



ALTER TABLE ONLY "public"."providers"
    ADD CONSTRAINT "providers_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."receiver_profiles"
    ADD CONSTRAINT "receiver_profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."receivers"
    ADD CONSTRAINT "receivers_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_shift_id_key" UNIQUE ("shift_id");



ALTER TABLE ONLY "public"."room_comments"
    ADD CONSTRAINT "room_comments_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."rooms"
    ADD CONSTRAINT "rooms_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."rooms"
    ADD CONSTRAINT "rooms_shift_id_key" UNIQUE ("shift_id");



ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_provider_year_month_key" UNIQUE ("provider_id", "year", "month");



ALTER TABLE ONLY "public"."service_logs"
    ADD CONSTRAINT "service_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."service_logs"
    ADD CONSTRAINT "service_logs_reservation_id_key" UNIQUE ("reservation_id");



ALTER TABLE ONLY "public"."shifts"
    ADD CONSTRAINT "shifts_pkey" PRIMARY KEY ("id");



CREATE OR REPLACE TRIGGER "trg_prevent_last_admin_delete" BEFORE DELETE ON "public"."app_users" FOR EACH ROW EXECUTE FUNCTION "public"."prevent_last_admin_delete"();



CREATE OR REPLACE TRIGGER "trg_prevent_last_admin_downgrade" BEFORE UPDATE ON "public"."app_users" FOR EACH ROW EXECUTE FUNCTION "public"."prevent_last_admin_downgrade"();



ALTER TABLE ONLY "public"."provider_profiles"
    ADD CONSTRAINT "provider_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."app_users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."notification_deliveries"
    ADD CONSTRAINT "notification_deliveries_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."notification_jobs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."notification_jobs"
    ADD CONSTRAINT "notification_jobs_reservation_id_fkey" FOREIGN KEY ("reservation_id") REFERENCES "public"."reservations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."providers"
    ADD CONSTRAINT "providers_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."app_users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."receiver_profiles"
    ADD CONSTRAINT "receiver_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."app_users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."receivers"
    ADD CONSTRAINT "receivers_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."app_users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_receiver_id_fkey" FOREIGN KEY ("receiver_id") REFERENCES "public"."receivers"("user_id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_shift_id_fkey" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."room_comments"
    ADD CONSTRAINT "room_comments_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "public"."rooms"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."room_comments"
    ADD CONSTRAINT "room_comments_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."app_users"("id");



ALTER TABLE ONLY "public"."rooms"
    ADD CONSTRAINT "rooms_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."app_users"("id");



ALTER TABLE ONLY "public"."rooms"
    ADD CONSTRAINT "rooms_shift_id_fkey" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."app_users"("id");



ALTER TABLE ONLY "public"."salary_transfers"
    ADD CONSTRAINT "salary_transfers_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "public"."providers"("user_id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."service_logs"
    ADD CONSTRAINT "service_logs_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "public"."providers"("user_id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."service_logs"
    ADD CONSTRAINT "service_logs_receiver_id_fkey" FOREIGN KEY ("receiver_id") REFERENCES "public"."receivers"("user_id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."service_logs"
    ADD CONSTRAINT "service_logs_reservation_id_fkey" FOREIGN KEY ("reservation_id") REFERENCES "public"."reservations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."shifts"
    ADD CONSTRAINT "shifts_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "public"."providers"("user_id") ON DELETE CASCADE;



ALTER TABLE "public"."app_users" ENABLE ROW LEVEL SECURITY;


CREATE INDEX "notification_jobs_reservation_active_idx" ON "public"."notification_jobs" USING btree ("reservation_id", "is_active", "recipient_role");



CREATE INDEX "notification_deliveries_job_idx" ON "public"."notification_deliveries" USING btree ("job_id");



CREATE INDEX "notification_deliveries_due_idx" ON "public"."notification_deliveries" USING btree ((COALESCE("next_retry_at", "scheduled_for"))) WHERE ("status" = 'pending'::text);



ALTER TABLE "public"."notification_jobs" ENABLE ROW LEVEL SECURITY;



ALTER TABLE "public"."notification_deliveries" ENABLE ROW LEVEL SECURITY;



CREATE POLICY "app_users_select_self" ON "public"."app_users" FOR SELECT USING ((((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text") OR (("id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))));



CREATE POLICY "app_users_update_self" ON "public"."app_users" FOR UPDATE USING ((("id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))) WITH CHECK ((("id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text")));



CREATE POLICY "logs_provider_own" ON "public"."service_logs" USING ((((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text") OR (("provider_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))));



CREATE POLICY "logs_receiver_read" ON "public"."service_logs" FOR SELECT USING (((("receiver_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text")) OR ((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text")));



ALTER TABLE "public"."providers" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "providers_self" ON "public"."providers" USING ((((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text") OR (("user_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))));



ALTER TABLE "public"."receiver_profiles" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "receiver_profiles_self" ON "public"."receiver_profiles" USING ((((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text") OR (("user_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text")))) WITH CHECK ((("user_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text")));



ALTER TABLE "public"."receivers" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "receivers_self" ON "public"."receivers" USING ((((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text") OR (("user_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))));



ALTER TABLE "public"."reservations" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "reservations_provider_view" ON "public"."reservations" FOR SELECT USING (((EXISTS ( SELECT 1
   FROM "public"."shifts" "s"
  WHERE (("s"."id" = "reservations"."shift_id") AND (("s"."provider_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))))) OR ((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text")));



CREATE POLICY "reservations_receiver_own" ON "public"."reservations" USING ((((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text") OR (("receiver_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))));



ALTER TABLE "public"."salary_transfers" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "salary_transfers_admin_insert" ON "public"."salary_transfers" FOR INSERT WITH CHECK (((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text"));



CREATE POLICY "salary_transfers_admin_select" ON "public"."salary_transfers" FOR SELECT USING (((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text"));



ALTER TABLE "public"."service_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."shifts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "shifts_provider_own" ON "public"."shifts" USING ((((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = 'admin'::"text") OR (("provider_id")::"text" = (("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'user_id'::"text"))));



CREATE POLICY "shifts_receiver_read" ON "public"."shifts" FOR SELECT USING (((("current_setting"('request.jwt.claims'::"text", true))::"jsonb" ->> 'role'::"text") = ANY (ARRAY['receiver'::"text", 'admin'::"text", 'provider'::"text"])));





ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";

























































































































































GRANT ALL ON FUNCTION "public"."hours_between"("t1" timestamp with time zone, "t2" timestamp with time zone) TO "anon";
GRANT ALL ON FUNCTION "public"."hours_between"("t1" timestamp with time zone, "t2" timestamp with time zone) TO "authenticated";
GRANT ALL ON FUNCTION "public"."hours_between"("t1" timestamp with time zone, "t2" timestamp with time zone) TO "service_role";



GRANT ALL ON FUNCTION "public"."prevent_last_admin_delete"() TO "anon";
GRANT ALL ON FUNCTION "public"."prevent_last_admin_delete"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."prevent_last_admin_delete"() TO "service_role";



GRANT ALL ON FUNCTION "public"."prevent_last_admin_downgrade"() TO "anon";
GRANT ALL ON FUNCTION "public"."prevent_last_admin_downgrade"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."prevent_last_admin_downgrade"() TO "service_role";


















GRANT ALL ON TABLE "public"."app_users" TO "anon";
GRANT ALL ON TABLE "public"."app_users" TO "authenticated";
GRANT ALL ON TABLE "public"."app_users" TO "service_role";



GRANT ALL ON TABLE "public"."notification_jobs" TO "service_role";



GRANT ALL ON SEQUENCE "public"."notification_jobs_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."notification_deliveries" TO "service_role";



GRANT ALL ON SEQUENCE "public"."notification_deliveries_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."providers" TO "anon";
GRANT ALL ON TABLE "public"."providers" TO "authenticated";
GRANT ALL ON TABLE "public"."providers" TO "service_role";



GRANT ALL ON TABLE "public"."service_logs" TO "anon";
GRANT ALL ON TABLE "public"."service_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."service_logs" TO "service_role";



GRANT ALL ON TABLE "public"."payroll_view" TO "anon";
GRANT ALL ON TABLE "public"."payroll_view" TO "authenticated";
GRANT ALL ON TABLE "public"."payroll_view" TO "service_role";



GRANT ALL ON TABLE "public"."provider_profiles" TO "anon";
GRANT ALL ON TABLE "public"."provider_profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."provider_profiles" TO "service_role";



GRANT ALL ON TABLE "public"."receiver_profiles" TO "anon";
GRANT ALL ON TABLE "public"."receiver_profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."receiver_profiles" TO "service_role";



GRANT ALL ON TABLE "public"."receivers" TO "anon";
GRANT ALL ON TABLE "public"."receivers" TO "authenticated";
GRANT ALL ON TABLE "public"."receivers" TO "service_role";



GRANT ALL ON TABLE "public"."reservations" TO "anon";
GRANT ALL ON TABLE "public"."reservations" TO "authenticated";
GRANT ALL ON TABLE "public"."reservations" TO "service_role";



GRANT ALL ON SEQUENCE "public"."reservations_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."reservations_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."reservations_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."room_comments" TO "anon";
GRANT ALL ON TABLE "public"."room_comments" TO "authenticated";
GRANT ALL ON TABLE "public"."room_comments" TO "service_role";



GRANT ALL ON TABLE "public"."rooms" TO "anon";
GRANT ALL ON TABLE "public"."rooms" TO "authenticated";
GRANT ALL ON TABLE "public"."rooms" TO "service_role";



GRANT ALL ON TABLE "public"."salary_transfers" TO "anon";
GRANT ALL ON TABLE "public"."salary_transfers" TO "authenticated";
GRANT ALL ON TABLE "public"."salary_transfers" TO "service_role";



GRANT ALL ON SEQUENCE "public"."salary_transfers_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."salary_transfers_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."salary_transfers_id_seq" TO "service_role";



GRANT ALL ON SEQUENCE "public"."service_logs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."service_logs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."service_logs_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."shifts" TO "anon";
GRANT ALL ON TABLE "public"."shifts" TO "authenticated";
GRANT ALL ON TABLE "public"."shifts" TO "service_role";



GRANT ALL ON SEQUENCE "public"."shifts_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."shifts_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."shifts_id_seq" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";



























