# REST Client 拡張 使用ガイド

VSCode の REST Client 拡張を使って、バックエンド API を手軽に確認するための手順書です。

## 前提条件

- VSCode がインストールされていること
- バックエンドが起動していること（`http://localhost:8000`）

## 拡張機能のインストール

1. VSCode を開く
2. 拡張機能パネル（`Ctrl+Shift+X` / `Cmd+Shift+X`）を開く
3. `REST Client` で検索し、**humao.rest-client**（Huachao Mao 製）をインストール

## HTTP ファイルの場所

```
srms/
└── http/
    └── cancel.http   # キャンセル機能確認用
```

## 使い方

### 1. ファイルを開く

VSCode で `http/cancel.http` を開く。

### 2. ログインしてトークンを取得

ファイル内の **Step 1: ログイン** セクションを探し、`Send Request` をクリック。

```http
POST http://localhost:8000/api/auth/login
Content-Type: application/json

{
  "email": "your-receiver@example.com",
  "password": "your-password"
}
```

レスポンスペインが右側に開き、以下のような JSON が返る：

```json
{
  "access_token": "eyJhbGciOi...",
  "token_type": "bearer"
}
```

### 3. トークンをファイルに設定

`access_token` の値をコピーし、ファイル内の変数定義を更新する：

```http
@token = eyJhbGciOi...（コピーしたトークン）
```

### 4. reservation_id を設定

テストしたい予約の ID に変数を変更する：

```http
@reservation_id = 123
```

> **ヒント**: 予約 ID は管理画面や DB から確認する。

### 5. テストケースを実行

各リクエストブロックの上に表示される **`Send Request`** をクリックするか、カーソルをリクエスト内に置いて `Ctrl+Alt+R`（Mac: `Cmd+Alt+R`）を押す。

---

## キャンセル機能テストケース一覧

| ケース | リクエスト | 前提条件 | 期待レスポンス |
|--------|-----------|---------|--------------|
| **G-1 / G-2** キャンセル上限 | `POST /api/receiver/reservations/{id}/cancel` | 当月キャンセル済み 3 件 | HTTP 400、detail に上限メッセージ |
| 他人の予約キャンセル | `POST /api/receiver/reservations/{id}/cancel` | 別ユーザーの reservation_id を使用 | HTTP 404「予約が見つかりません」 |
| キャンセル済みを再キャンセル | `POST /api/receiver/reservations/{id}/cancel` | status='canceled' の予約 ID | HTTP 400「キャンセル可能な予約ではありません」 |
| 存在しない予約 ID | `POST /api/receiver/reservations/{id}/cancel` | 存在しない ID（例: 999999） | HTTP 404「予約が見つかりません」 |

### G-1 / G-2 テストの準備

当月キャンセル件数が 3 件に達していることを事前に確認する：

```http
GET http://localhost:8000/api/receiver/cancel-count
Authorization: Bearer {{token}}
```

レスポンス例：
```json
{ "count": 3, "limit": 3 }
```

`count` が 3 であれば、次のキャンセル API 呼び出しで HTTP 400 が返る。

---

## よく使うショートカット

| 操作 | Windows / Linux | Mac |
|------|----------------|-----|
| リクエスト送信 | `Ctrl+Alt+R` | `Cmd+Alt+R` |
| レスポンス履歴 | `Ctrl+Alt+H` | `Cmd+Alt+H` |
| 環境切り替え | `Ctrl+Alt+E` | `Cmd+Alt+E` |

## トラブルシューティング

### `Send Request` が表示されない

- ファイルの言語モードが `HTTP` になっていることを確認する（右下のステータスバーで確認・変更可能）

### `401 Unauthorized` が返る

- トークンの有効期限が切れている可能性がある。Step 1 のログインを再実行してトークンを更新する。

### 接続できない

- バックエンドが起動しているか確認する（`docker compose up` など）
- `@baseUrl` の値が正しいか確認する（デフォルト: `http://localhost:8000`）
