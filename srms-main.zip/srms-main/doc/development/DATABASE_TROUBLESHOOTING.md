# データベーストラブルシューティングガイド

このドキュメントでは、データベース操作時に発生する可能性のある問題と解決方法を説明します。

**関連ドキュメント**:
- [DATABASE_MIGRATION.md](DATABASE_MIGRATION.md) - 日常的なマイグレーション手順
- [DATABASE_SETUP.md](DATABASE_SETUP.md) - 初期セットアップ

---

## 📋 目次

- [Supabase CLI関連](#supabase-cli関連)
- [接続・認証関連](#接続認証関連)
- [マイグレーション関連](#マイグレーション関連)
- [パフォーマンス関連](#パフォーマンス関連)
- [リカバリー手順](#リカバリー手順)
- [代替方法](#代替方法)

---

## Supabase CLI関連

### 問題: `supabase: command not found`

**原因**: Supabase CLIがインストールされていない

**解決方法**:

```bash
# npm経由でインストール
npm install -g supabase

# Homebrewでインストール（macOS/Linux）
brew install supabase/tap/supabase

# 確認
supabase --version
```

---

### 問題: `supabase start` が失敗する

**原因**: Dockerが起動していない、またはポート競合

**解決方法**:

```bash
# Dockerを確認
docker ps

# ポート使用状況を確認（54322, 54323が使われていないか）
lsof -i :54322
lsof -i :54323

# 既存のSupabaseを停止
npx supabase stop

# 完全にクリーンアップ
npx supabase stop --no-backup
docker system prune -a

# 再起動
npx supabase start
```

---

### 問題: `supabase db diff` で差分が検出されない

**原因**: Supabase DBが変更されていない、またはschema.sqlと同じ状態

**解決方法**:

```bash
# ホストで実行

# 1. 現在のSupabase DBの状態を確認
npx supabase db dump -f schema

# 2. Studioで変更を適用したか確認
# → http://localhost:54323

# 3. 変更をコミット
npx supabase db reset  # 最新のschema.sqlを反映
# → Studioで変更
npx supabase db diff  # 差分確認
```

---

### 問題: マイグレーションファイルが多すぎて管理が難しい

**原因**: 小さな変更ごとにファイルを作成している

**解決方法**:

機能単位でマイグレーションをまとめてください。

```bash
# ❌ 悪い例（細かすぎる）
20260128120000_add_column_name.sql
20260128120100_add_column_email.sql
20260128120200_add_column_phone.sql

# ✅ 良い例（機能単位）
20260128120000_add_receiver_profile_fields.sql
```

**複数の変更をまとめる方法**:

```bash
# Studioで複数の変更を実施後、一度に差分を取得
npx supabase db diff -f add_receiver_profile_complete
```

---

## 接続・認証関連

### 問題: `Password for user postgres:` が表示される

**原因**: パスワード認証が要求されている

**解決方法**:

パスワードは `postgres` です（[.devcontainer/docker-compose.yml](../../.devcontainer/docker-compose.yml)で設定）。

または、環境変数 `PGPASSWORD` を設定：

```bash
# DevContainer内で実行
export PGPASSWORD=postgres
psql -h postgres -U postgres -d tomodachi_db -c "\dt"
```

永続的に設定する場合：

```bash
# DevContainer内で実行
echo "postgres:5432:tomodachi_db:postgres:postgres" >> ~/.pgpass
chmod 600 ~/.pgpass
```

---

### 問題: `Could not connect to server` エラー

**原因**: PostgreSQLコンテナが起動していない、またはネットワーク接続の問題

**解決方法**:

```bash
# コンテナのステータスを確認
docker ps | grep postgres

# ヘルスチェックを確認
docker inspect tomodachi-postgres | grep -A 5 Health

# コンテナを再起動（ホストから）
cd .devcontainer
docker-compose restart postgres

# それでも接続できない場合、完全に再起動
docker-compose down
docker-compose up -d
```

---

### 問題: `psql: command not found`

**原因**: psqlコマンドがインストールされていない

**解決方法**:

DevContainerを使用していることを確認してください。DevContainerにはpsqlが含まれています。

ホストから実行する場合は、docker execを使用：

```bash
docker exec -i $(docker ps -qf "name=postgres") psql -U postgres -d tomodachi_db < supabase/schema.sql
```

---

## マイグレーション関連

### 問題: `relation "xxx" already exists` エラー

**原因**: テーブルやインデックスが既に存在する

**解決方法**:

これは正常なメッセージです。既存のオブジェクトはスキップされ、新しいオブジェクトのみが作成されます。

**schema.sql全体を実行した場合に発生します。気になる場合は、差分マイグレーションを使用してください。**

```bash
# ✅ 推奨：差分マイグレーションのみ実行
psql -h postgres -U postgres -d tomodachi_db \
  -f /workspace/supabase/migrations/YYYYMMDDHHMMSS_xxx.sql
```

---

### 問題: `FATAL: database "tomodachi_db" does not exist`

**原因**: データベースが作成されていない

**解決方法**:

```bash
# DevContainer内で実行

# データベースを作成
psql -h postgres -U postgres -c "CREATE DATABASE tomodachi_db;"

# スキーマを適用
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/schema.sql
```

---

### 問題: Supabase拡張機能のエラー

**例**:
```
ERROR: extension "pg_graphql" is not available
ERROR: extension "supabase_vault" is not available
ERROR: role "anon" does not exist
ERROR: role "authenticated" does not exist
ERROR: publication "supabase_realtime" does not exist
```

**原因**: DevContainerのPostgreSQLにはSupabase固有の拡張機能やロールが存在しない

**解決方法**:

これらのエラーは**無視してOK**です。

- DevContainerのPostgreSQLはSupabase Cloudの完全な再現ではありません
- アプリケーションレベルで認証・認可を実装します
- RLSポリシーのエラーも開発環境では無視できます

**重要**: 本番環境ではこれらのエラーは発生しません。

---

### 問題: マイグレーション適用後にアプリケーションエラー

**原因**:
- アプリケーションコードが新しいスキーマに対応していない
- カラム名の不一致
- データ型の不一致

**解決方法**:

1. **エラーログを確認**
   ```bash
   # FastAPIのログを確認
   docker logs -f $(docker ps -qf "name=devcontainer")
   ```

2. **スキーマとコードの整合性確認**
   ```python
   # 例: FastAPIのモデルとスキーマの整合性確認
   # apis/models.py
   class ReceiverProfile(Base):
       __tablename__ = "receiver_profiles"
       email_verified = Column(Boolean, default=False)  # スキーマと一致するか確認
   ```

3. **DBスキーマを確認**
   ```bash
   psql -h postgres -U postgres -d tomodachi_db -c "\d receiver_profiles"
   ```

---

## パフォーマンス関連

### 問題: クエリが遅い

**原因**: インデックスが適切に作成されていない、またはクエリプランが最適でない

**解決方法**:

1. **クエリプランを確認**
   ```sql
   EXPLAIN (ANALYZE, BUFFERS)
   SELECT * FROM receiver_profiles WHERE email_verified = TRUE;
   ```

2. **インデックスの追加**
   ```sql
   CREATE INDEX CONCURRENTLY idx_receiver_profiles_email_verified
   ON receiver_profiles(email_verified);
   ```
   - `CONCURRENTLY`オプションでロックを回避

3. **統計情報の更新**
   ```sql
   ANALYZE receiver_profiles;
   ```

4. **インデックス使用状況の確認**
   ```sql
   SELECT
     schemaname,
     tablename,
     indexname,
     idx_scan,
     idx_tup_read,
     idx_tup_fetch
   FROM pg_stat_user_indexes
   WHERE tablename = 'receiver_profiles';
   ```

---

### 問題: マイグレーションが長時間ロックされる

**原因**: 大きなテーブルに対するALTER TABLE実行

**解決方法**:

```sql
-- インデックス作成時はCONCURRENTLYを使用
CREATE INDEX CONCURRENTLY idx_name ON table_name(column);

-- カラム追加は問題ないが、デフォルト値の設定は避ける
ALTER TABLE large_table ADD COLUMN new_col TEXT;
-- 後から更新
UPDATE large_table SET new_col = 'default' WHERE new_col IS NULL;
```

---

## リカバリー手順

### シナリオ1: マイグレーション適用後に問題発覚（DevContainer）

**手順**:

```bash
# DevContainer内で実行

# バックアップから復元
psql -h postgres -U postgres -d tomodachi_db \
  -f /workspace/supabase/backup/backup_YYYYMMDD_HHMMSS.sql

# 確認
psql -h postgres -U postgres -d tomodachi_db -c "\dt"
```

---

### シナリオ2: 本番環境のマイグレーションで問題発覚

**手順**:

```bash
# ホストで実行

# 1. バックアップから復元
psql "postgresql://postgres:[PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres" \
  < supabase/backup/schema_YYYYMMDD_HHMMSS.sql

# 2. または、Supabase Dashboard経由で復元
# Dashboard → Database → Backups → Restore
```

**ロールバックできない場合**:

```bash
# 手動で変更を取り消し
# Supabase Dashboard → SQL Editor で実行
DROP TABLE IF EXISTS receiver_profiles CASCADE;
DROP INDEX IF EXISTS idx_receiver_profiles_email_verified;
```

---

### シナリオ3: DevContainerのDBが完全に壊れた

**手順**:

```bash
# ホストで実行
cd .devcontainer

# 1. コンテナとボリュームを完全削除
docker-compose down
docker volume rm devcontainer_postgres_data

# 2. コンテナを再起動
docker-compose up -d

# 3. DevContainerを再接続
# VS Code: "Reopen in Container"

# 4. 初期化（DevContainer内）
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/schema.sql
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/seed.sql
```

---

## 代替方法

### schema.sql全体を再適用（緊急時）

差分マイグレーションが使えない場合の代替方法：

```bash
# DevContainer内で実行
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/schema.sql
```

**注意**:
- 多数のエラーメッセージが表示されます（無害）
- 新しいテーブルは正しく作成されます
- 既存テーブルの構造変更には対応しません

---

### Docker execで実行（DevContainerが使えない場合）

```bash
# ホストから実行

# コンテナ名を確認
docker ps | grep postgres

# マイグレーションを実行
docker exec -i tomodachi-postgres psql -U postgres -d tomodachi_db \
  < supabase/migrations/YYYYMMDDHHMMSS_xxx.sql

# または
docker exec -i $(docker ps -qf "name=postgres") psql -U postgres -d tomodachi_db \
  < supabase/schema.sql
```

---

### Supabase Dashboard経由（CLI が使えない場合）

1. https://supabase.com/dashboard にアクセス
2. プロジェクトを選択
3. **SQL Editor** に移動
4. マイグレーションファイルの内容をコピー&ペースト
5. **Run** をクリック
6. 実行結果を確認

---

## デバッグ用コマンド集

### アクティブな接続を確認

```sql
SELECT
  pid,
  usename,
  application_name,
  client_addr,
  state,
  query
FROM pg_stat_activity
WHERE datname = 'tomodachi_db';
```

### ロック状況を確認

```sql
SELECT
  locktype,
  relation::regclass,
  mode,
  granted,
  pid
FROM pg_locks
WHERE NOT granted;
```

### テーブルサイズを確認

```sql
SELECT
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

### 最近のクエリを確認

```sql
SELECT
  now() - query_start AS duration,
  query,
  state
FROM pg_stat_activity
WHERE state != 'idle'
ORDER BY duration DESC;
```

---

## さらなるサポート

問題が解決しない場合：

1. **ログを確認**
   - DevContainer: `docker logs $(docker ps -qf "name=devcontainer")`
   - PostgreSQL: `docker logs $(docker ps -qf "name=postgres")`
   - Supabase: Dashboard → Logs

2. **公式ドキュメント**
   - [Supabase Troubleshooting](https://supabase.com/docs/guides/platform/troubleshooting)
   - [PostgreSQL Error Codes](https://www.postgresql.org/docs/current/errcodes-appendix.html)

3. **コミュニティ**
   - [Supabase Community](https://github.com/supabase/supabase/discussions)
   - [PostgreSQL Mailing Lists](https://www.postgresql.org/list/)

---

**最終更新**: 2026-01-28
