# 初期セットアップガイド

このドキュメントは、プロジェクトに新規参画したメンバーが最初に実施すべきセットアップ手順をまとめたものです。

## 前提条件

以下がインストールされていることを確認してください：

- Docker Desktop（起動済み）
- Visual Studio Code
- VSCode拡張機能: Dev Containers (ms-vscode-remote.remote-containers)

## セットアップ手順

### 1. DevContainerの起動

1. VSCodeでプロジェクトルートを開く
   ```bash
   code /path/to/srms
   ```

2. コマンドパレット（`Cmd+Shift+P` / `Ctrl+Shift+P`）を開く

3. **「Dev Containers: Reopen in Container」** を選択

4. 初回起動時は5-10分かかります（Dockerイメージのビルド）

5. DevContainerが起動したら、VSCodeのターミナルが `/workspace` ディレクトリで開かれます

### 2. バックエンド（Python）の依存関係インストール

DevContainerのターミナルで以下を実行：

```bash
cd /workspace
pip install -r requirements.txt
```

または、VSCodeのタスク機能を使用：
- コマンドパレット → **「Tasks: Run Task」** → **「Backend: Install Python Dependencies」**

### 3. フロントエンド（Node.js）の依存関係インストール

**これが最も重要なステップです。フロントエンドが動作しない主な原因は、node_modulesがインストールされていないことです。**

DevContainerのターミナルで以下を実行：

```bash
cd /workspace/ui
npm install --legacy-peer-deps
```

または、VSCodeのタスク機能を使用：
- コマンドパレット → **「Tasks: Run Task」** → **「Frontend: Install Node Dependencies」**

> **注意**: `--legacy-peer-deps` フラグは、依存関係の競合を回避するために必要です。

### 4. データベースの初期化確認

PostgreSQLコンテナが起動しているか確認：

```bash
docker ps | grep postgres
```

起動していない場合（DevContainer外のホストで実行）：

```bash
cd /path/to/srms/.devcontainer
docker-compose up -d postgres adminer
```

### 5. サービスの起動

#### 方法A: VSCodeタスクを使用（推奨）

コマンドパレット → **「Tasks: Run Task」** → 以下のいずれかを選択：

- **「Full Stack: Start All Services」** - バックエンドとフロントエンドを同時起動
- **「Backend: Start FastAPI Dev Server」** - バックエンドのみ
- **「Frontend: Start Quasar Dev Server」** - フロントエンドのみ

#### 方法B: VSCodeデバッガーを使用

デバッグパネル（`Cmd+Shift+D` / `Ctrl+Shift+D`）から：

- **「Full Stack: Backend + Frontend」** を選択して F5 キー

#### 方法C: ターミナルから手動起動

**バックエンド:**
```bash
cd /workspace
uvicorn apis.main:app --host 0.0.0.0 --port 8000 --reload
```

**フロントエンド:**
```bash
cd /workspace/ui
npm run dev
```

### 6. 動作確認

ブラウザで以下のURLにアクセスして確認：

| サービス        | URL                        | 説明                          |
| --------------- | -------------------------- | ----------------------------- |
| FastAPI Backend | http://localhost:8000      | バックエンド API              |
| FastAPI Docs    | http://localhost:8000/docs | Swagger UI (API ドキュメント) |
| Quasar Frontend | http://localhost:9000      | フロントエンド開発サーバー    |
| Adminer         | http://localhost:8080      | SQL ブラウザ管理ツール        |

### 7. ログインテスト

フロントエンド (http://localhost:9000) にアクセスして、以下のアカウントでログインを試してください：

| メールアドレス        | パスワード | ロール         |
| --------------------- | ---------- | -------------- |
| admin@example.com     | tomodachi  | システム管理者 |
| provider1@example.com | tomodachi  | 講師           |
| receiver1@example.com | tomodachi  | 生徒           |

## トラブルシューティング

### フロントエンドが起動しない / エラーが出る

**原因**: node_modulesがインストールされていない

**解決方法**:
```bash
cd /workspace/ui
rm -rf node_modules package-lock.json
npm install --legacy-peer-deps
```

### "Cannot find module" エラー（フロントエンド）

**解決方法**:
```bash
cd /workspace/ui
npm install --legacy-peer-deps
```

### Python モジュールが見つからない

**解決方法**:
```bash
cd /workspace
pip install -r requirements.txt
```

### ポートが既に使用されている

**解決方法**:

DevContainerの外（ホスト）で実行：
```bash
cd /path/to/srms/.devcontainer
docker-compose down
docker-compose up -d
```

その後、VSCodeでDevContainerに再接続。

### データベース接続エラー

**解決方法**:

1. PostgreSQLコンテナが起動しているか確認：
   ```bash
   docker ps | grep postgres
   ```

2. 起動していない場合、ホストで実行：
   ```bash
   cd /path/to/srms/.devcontainer
   docker-compose up -d postgres
   ```

### DevContainerが起動しない

**解決方法**:

1. Docker Desktopが起動しているか確認
2. VSCodeコマンドパレット → **「Dev Containers: Rebuild Container」**
3. それでも失敗する場合 → **「Dev Containers: Rebuild Container Without Cache」**

### 古いキャッシュが残っている

**完全クリーンアップ（ホストで実行）**:
```bash
cd /path/to/srms/.devcontainer
docker-compose down -v
docker-compose up -d
```

その後、VSCodeでDevContainerに再接続し、上記のセットアップ手順を再実行。

## 開発開始前のチェックリスト

- [ ] Docker Desktopが起動している
- [ ] VSCodeでDevContainerに接続済み
- [ ] Python依存関係がインストール済み (`pip list` で確認)
- [ ] Node.js依存関係がインストール済み (`ls /workspace/ui/node_modules` で確認)
- [ ] PostgreSQLコンテナが起動している (`docker ps | grep postgres`)
- [ ] バックエンドが起動している (http://localhost:8000/docs にアクセス可能)
- [ ] フロントエンドが起動している (http://localhost:9000 にアクセス可能)
- [ ] ログインが成功する

## 次のステップ

セットアップが完了したら、以下のドキュメントを参照してください：

- [.devcontainer/README.md](../../.devcontainer/README.md) - 詳細な開発環境ガイド
- [README.md](../../README.md) - プロジェクト概要
- [CLAUDE.md](../../CLAUDE.md) - Claude AIとの開発フロー

## よく使うVSCodeコマンド

| コマンド                                   | 説明                           |
| ------------------------------------------ | ------------------------------ |
| `Cmd/Ctrl+Shift+P`                         | コマンドパレットを開く         |
| `Tasks: Run Task`                          | タスク一覧を表示               |
| `Cmd/Ctrl+Shift+D`                         | デバッグパネルを開く           |
| `Dev Containers: Reopen in Container`      | DevContainerに接続             |
| `Dev Containers: Reopen Folder Locally`    | DevContainerから切断           |
| `Dev Containers: Rebuild Container`        | DevContainerを再ビルド         |

## サポート

セットアップで問題が発生した場合は、以下を確認してください：

1. このドキュメントのトラブルシューティングセクション
2. [.devcontainer/README.md](../../.devcontainer/README.md) の詳細情報
3. チームメンバーに相談
