# データベース初期セットアップガイド

このドキュメントでは、初回のデータベース環境セットアップ方法を説明します。

**関連ドキュメント**:
- [DATABASE_MIGRATION.md](DATABASE_MIGRATION.md) - 日常的なマイグレーション手順
- [DATABASE_TROUBLESHOOTING.md](DATABASE_TROUBLESHOOTING.md) - トラブルシューティング

---

## 📋 目次

- [Supabase CLIのインストール](#supabase-cliのインストール)
- [初回セットアップ](#初回セットアップ)
- [schema.sqlの管理](#schemasqlの管理)
- [データの永続化について](#データの永続化について)

---

## Supabase CLIのインストール

### npm経由

```bash
# グローバルインストール
npm install -g supabase

# 確認
supabase --version
```

### Homebrew経由（macOS/Linux）

```bash
# インストール
brew install supabase/tap/supabase

# 確認
supabase --version
```

### npx経由（インストール不要）

```bash
# 毎回npxを使用
npx supabase --version
```

---

## 初回セットアップ

### 前提条件

- Docker Desktopがインストールされ、起動していること
- DevContainerが正常に動作していること
- 本番プロジェクトの参照ID（PROJECT-REF）を把握していること

**プロジェクトリファレンスの確認方法**:
- Supabase Dashboard URL: `https://supabase.com/dashboard/project/[YOUR-PROJECT-REF]`
- プロジェクト設定: Dashboard → Settings → General → Reference ID
- Database URL: `db.[YOUR-PROJECT-REF].supabase.co`

### ステップ1: 本番プロジェクトとの接続

```bash
# ホストで実行

# 1. Supabaseにログイン
npx supabase login

# 2. 本番プロジェクトにリンク
npx supabase link --project-ref [YOUR-PROJECT-REF]

# 3. 本番のマイグレーション履歴を取得
npx supabase migration fetch

# 4. 本番DBとの差分があれば検出
npx supabase db pull
```

これにより、`supabase/migrations/`ディレクトリに既存のマイグレーションファイルと、差分があれば新しいマイグレーションファイルがダウンロードされます。

### ステップ2: ローカルSupabase環境の初期化

```bash
# ホストで実行
cd /path/to/project

# Supabase Local Developmentを起動
npx supabase start

# schema.sqlを適用（初回のみ）
npx supabase db reset

# Supabase Studioが開く（localhost:54323）
```

### ステップ3: DevContainer内のPostgreSQLを初期化

```bash
# DevContainer内で実行

# schema.sqlを適用
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/schema.sql

# seed.sql（初期データ）を適用（オプション）
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/seed.sql

# 確認
psql -h postgres -U postgres -d tomodachi_db -c "\dt"
```

これで、ローカル開発環境が整いました。

---

## schema.sqlの管理

### 概要

`supabase/schema.sql`と`supabase/policies.sql`は以下の用途で使用されます：

- DevContainer初期化時のスキーマ適用
- 新しいチームメンバーのオンボーディング
- テスト環境の構築
- スキーマのバージョン管理

**重要**: schema.sqlは**本番環境が信頼できる唯一の真実（Single Source of Truth）**です。

**📝 注意**: `schema.sql` にはテーブル定義と RLS ポリシーの両方が含まれています。`policies.sql` は DevContainer の `docker-compose.yml` で初期化用に指定されていますが、`schema.sql` と内容が重複するため実質的に不要です。

### 日常的な更新方法

`schema.sql` の日常的な更新・マイグレーション手順については、[DATABASE_MIGRATION.md](DATABASE_MIGRATION.md) を参照してください。

---

## データの永続化について

### DevContainerのPostgreSQL

データは名前付きボリューム `postgres_data` に保存されます：

```yaml
volumes:
  - postgres_data:/var/lib/postgresql/data
```

### 重要なポイント

#### 1. DevContainer再ビルド時

- ✅ データは保持されます
- ❌ `docker-entrypoint-initdb.d` のスクリプトは実行されません（データがある場合）
- 💡 スキーマ変更を反映するには、マイグレーションを手動で適用する必要があります

#### 2. スキーマ変更を反映する方法

- **方法1**: 差分マイグレーションを実行（推奨）
  ```bash
  psql -h postgres -U postgres -d tomodachi_db \
    -f /workspace/supabase/migrations/YYYYMMDDHHMMSS_xxx.sql
  ```

- **方法2**: schema.sql全体を実行（エラーが出るが新規テーブルは作成される）
  ```bash
  psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/schema.sql
  ```

- **方法3**: ボリュームを削除して完全リセット
  ```bash
  # ホストで実行
  cd .devcontainer
  docker-compose down
  docker volume rm devcontainer_postgres_data
  docker-compose up -d
  # DevContainerを再接続
  ```

#### 3. データを完全に削除するには

```bash
# ホストで実行
docker volume rm devcontainer_postgres_data
```

### ホストのSupabase DB

- **用途**: 一時的な作業用（マイグレーションファイル生成）
- **永続化**: `supabase stop` で停止すると、次回 `supabase start` 時にリセットされる可能性あり
- **注意**: 開発データの永続化には使用しない

---

## パスワード入力を省略する方法

DevContainerでpsqlを使用する際、毎回パスワード入力を求められる場合の対処法：

### 方法1: 環境変数に設定（セッション中有効）

```bash
# DevContainer内で実行
export PGPASSWORD=postgres
psql -h postgres -U postgres -d tomodachi_db -c "\dt"
```

### 方法2: ~/.pgpass ファイルに設定（永続的）

```bash
# DevContainer内で実行
echo "postgres:5432:tomodachi_db:postgres:postgres" >> ~/.pgpass
chmod 600 ~/.pgpass
```

これで、パスワード入力なしでpsqlコマンドを実行できます。

---

## 次のステップ

初期セットアップが完了したら、以下のドキュメントを参照してください：

- [DATABASE_MIGRATION.md](DATABASE_MIGRATION.md) - 日常的なマイグレーション手順
- [DATABASE_TROUBLESHOOTING.md](DATABASE_TROUBLESHOOTING.md) - 問題が発生した場合

---

## 参考情報

- [Supabase CLI Documentation](https://supabase.com/docs/guides/cli)
- [Supabase Local Development](https://supabase.com/docs/guides/cli/local-development)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [DevContainer Documentation](https://code.visualstudio.com/docs/devcontainers/containers)

---

**最終更新**: 2026-01-28
