# データベースマイグレーションガイド

日常的なデータベーススキーマ変更の手順をまとめたドキュメントです。

**関連ドキュメント**:
- [DATABASE_SETUP.md](DATABASE_SETUP.md) - 初回セットアップ
- [DATABASE_TROUBLESHOOTING.md](DATABASE_TROUBLESHOOTING.md) - トラブルシューティング

---

## 📋 目次

- [開発ワークフロー](#開発ワークフロー)
- [マイグレーション方法](#マイグレーション方法)
- [本番デプロイメント](#本番デプロイメント)
- [バックアップ手順](#バックアップ手順)
- [ベストプラクティス](#ベストプラクティス)

---

## 開発ワークフロー

### 環境の役割

| 環境 | 用途 | 稼働期間 |
|------|------|---------|
| **ホスト (Supabase CLI)** | スキーマ設計、マイグレーションファイル生成 | 一時的 |
| **DevContainer (PostgreSQL)** | API開発、テスト、開発データ蓄積 | 永続的 |
| **本番 (Supabase Cloud)** | プロダクション環境 | 永続的 |

### 基本フロー

```
ホスト（スキーマ設計）
  ↓ 1. npx supabase start → Studio で変更
  ↓ 2. npx supabase db diff -f xxx → マイグレーションファイル生成
  ↓ 3. schema.sql 更新
  ↓ 4. npx supabase stop

DevContainer（API開発）
  ↓ 5. psql でマイグレーション適用
  ↓ 6. API実装とテスト

本番（デプロイメント）
  ↓ 7. 本番DBのバックアップ（スキーマ・ロール・データ）
  ↓ 8. npx supabase db push → 本番適用
  ↓ 9. 動作確認 & schema.sql 更新
```

**📝 注意**: `schema.sql` には RLS ポリシーも含まれています。`supabase/policies.sql` は DevContainer の初期化用に残していますが、実質的に不要です。

詳細な初期セットアップは [DATABASE_SETUP.md](DATABASE_SETUP.md) を参照してください。

---

## マイグレーション方法

### 方法1: 差分マイグレーション（推奨）

Supabase CLIで変更差分を自動生成し、精密にマイグレーションを実行します。

**メリット**: 正確、ロールバック可能、本番環境と同じワークフロー

#### ステップ1: ホストでマイグレーションファイル生成

```bash
# ホストで実行
npx supabase start
# → Supabase Studio (localhost:54323) でスキーマ変更

# 差分を確認
npx supabase db diff

# マイグレーションファイルとして保存
npx supabase db diff -f add_receiver_profile

# schema.sqlを更新（RLSポリシーも含まれます）
npx supabase db dump -f schema > supabase/schema.sql

npx supabase stop
```

#### ステップ2: DevContainerで適用

```bash
# DevContainer内で実行
psql -h postgres -U postgres -d tomodachi_db \
  -f /workspace/supabase/migrations/YYYYMMDDHHMMSS_add_receiver_profile.sql

# 確認
psql -h postgres -U postgres -d tomodachi_db -c "\dt receiver_profiles"
```

---

### 方法2: schema.sql全体を再適用（簡易版）

既存データを保持しつつ、schema.sql全体を実行します。

**メリット**: 簡単、追加のみなら安全

**注意**: 多数のエラーメッセージが表示されますが、新規テーブルは正常に作成されます。

```bash
# DevContainer内で実行
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/schema.sql
```

---

### 方法3: 完全リセット（開発環境のみ）

データをすべて削除して、クリーンな状態から開始します。

**注意**: 開発データがすべて消えます。

```bash
# ホストで実行
cd .devcontainer
docker-compose down
docker volume rm devcontainer_postgres_data
docker-compose up -d

# DevContainerを再接続後
# DevContainer内で実行
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/schema.sql
psql -h postgres -U postgres -d tomodachi_db -f /workspace/supabase/seed.sql
```

---

## 本番デプロイメント

### ⚠️ 重要: マイグレーション前の必須事項

本番環境へのマイグレーション適用前に、**必ずバックアップを取得してください**。

### 前提条件

```bash
# 本番プロジェクトにリンク済みであること
npx supabase login
npx supabase link --project-ref [YOUR-PROJECT-REF]
```

### 手順

#### ステップ1: 本番環境のバックアップ（必須）

```bash
# ホストで実行

# バックアップディレクトリを確認
mkdir -p supabase/backup

# タイムスタンプを設定
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# 1. スキーマのバックアップ
npx supabase db dump -f supabase/backup/production_schema_${TIMESTAMP}.sql

# 2. ロールのバックアップ
npx supabase db dump --role-only -f supabase/backup/production_roles_${TIMESTAMP}.sql

# 3. データのバックアップ（最重要）
npx supabase db dump --data-only -f supabase/backup/production_data_${TIMESTAMP}.sql

# バックアップファイルを確認（0バイトでないことを確認）
ls -lh supabase/backup/production_*_${TIMESTAMP}.sql
```

**チェックリスト**:
- [ ] 3種類のバックアップファイルが作成された
- [ ] ファイルサイズが0バイトでない
- [ ] ローカル環境でマイグレーションテスト済み
- [ ] ロールバック手順を確認済み
- [ ] 営業時間外での実施
- [ ] チームメンバーへの事前通知

#### ステップ2: マイグレーションの適用

```bash
# ホストで実行

# 1. マイグレーションを本番に適用
npx supabase db push

# 2. 適用状況を確認
npx supabase migration list
```

#### ステップ3: 動作確認

```bash
# Supabase Dashboardで確認
# https://supabase.com/dashboard/project/[YOUR-PROJECT-REF]/editor

# またはCLIで確認
npx supabase db dump -f schema --schema public | head -20
```

#### ステップ4: schema.sqlの更新とコミット

```bash
# ホストで実行

# schema.sqlを本番と同期（RLSポリシーも含まれます）
npx supabase db dump -f schema > supabase/schema.sql

# Git commit: "chore: Deploy migration to production"
```

#### 問題発生時のロールバック

マイグレーション適用後に問題が発覚した場合、[DATABASE_TROUBLESHOOTING.md](DATABASE_TROUBLESHOOTING.md#シナリオ2-本番環境のマイグレーションで問題発覚) を参照してバックアップから復元してください。

```bash
# クイックロールバック例
psql "postgresql://postgres:[PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres" \
  < supabase/backup/production_schema_${TIMESTAMP}.sql
```

### 本番環境での確認

```bash
# Web UIで確認
# https://supabase.com/dashboard/project/[YOUR-PROJECT-REF]/editor

# またはCLIで確認
npx supabase db dump --db-url "postgresql://postgres:[PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres" \
  -f schema --schema public
```

---

## ベストプラクティス


```bash
# ✅ 良い例（機能単位で命名）
npx supabase db diff -f add_receiver_profile
npx supabase db diff -f add_email_verification
npx supabase db diff -f update_user_role_enum
```

### 2. schema.sqlの定期同期

機能開発開始前に本番から同期：

```bash
npx supabase migration fetch
npx supabase db pull
npx supabase db dump -f schema > supabase/schema.sql
# Git commit: "chore: Sync schema from production"
```

### 3. マイグレーション確認

```bash
# 適用後の確認
npx supabase migration list  # LOCALとREMOTEの一致確認
psql -h postgres -U postgres -d tomodachi_db -c "\dt"  # テーブル確認
```

---

## よくあるコマンド集

### データベース操作

```bash
# テーブル一覧
psql -h postgres -U postgres -d tomodachi_db -c "\dt"

# テーブル構造確認
psql -h postgres -U postgres -d tomodachi_db -c "\d receiver_profiles"

# データ確認
psql -h postgres -U postgres -d tomodachi_db -c "SELECT * FROM app_users LIMIT 5;"

# インタラクティブモード
psql -h postgres -U postgres -d tomodachi_db
```

### パスワード入力の省略

```bash
# 環境変数で設定
export PGPASSWORD=postgres

# またはファイルで設定（永続）
echo "postgres:5432:tomodachi_db:postgres:postgres" >> ~/.pgpass
chmod 600 ~/.pgpass
```

---

## 参考情報

- [Supabase CLI Documentation](https://supabase.com/docs/guides/cli)
- [Supabase Migrations Guide](https://supabase.com/docs/guides/cli/local-development#database-migrations)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)

---

**最終更新**: 2026-01-28

