# ローカル開発環境での LINE 連携設定

dev container でアプリを起動し、LINE ログイン連携を動作させるための手順です。

## 前提条件

- dev container が起動済みであること
- バックエンド・フロントエンドの開発サーバーが起動済みであること
- LINE Developers コンソールへのアクセス権限を持つメンバーに連絡済みであること

## 1. 環境変数の設定

プロジェクトルートに `.env` ファイルを作成し、以下の変数を設定します。
`.env.dev` を雛形として使用できます。

```bash
cp .env.dev .env
```

### 必須の環境変数

| 変数名 | ローカル開発用の値 | 説明 |
|--------|-------------------|------|
| `LINE_LOGIN_REDIRECT_URI` | `http://localhost:9000/api/line/callback` | LINE 認証後のリダイレクト先 URL |
| `LINE_CHANNEL_ACCESS_TOKEN` | ※他メンバーに確認 | LINE Messaging API のアクセストークン（通知送信に使用） |
| `LINE_LOGIN_CHANNEL_ID` | ※他メンバーに確認 | LINE Login チャネルのチャネル ID |
| `LINE_LOGIN_CHANNEL_SECRET` | ※他メンバーに確認 | LINE Login チャネルのチャネルシークレット |

`LINE_CHANNEL_ACCESS_TOKEN`、`LINE_LOGIN_CHANNEL_ID`、`LINE_LOGIN_CHANNEL_SECRET` は
LINE Developers コンソールで確認できる値です。値が分からない場合は他の開発メンバーに確認してください。

`.env` への記載例：

```env
LINE_LOGIN_REDIRECT_URI=http://localhost:9000/api/line/callback
LINE_CHANNEL_ACCESS_TOKEN=<他メンバーに確認>
LINE_LOGIN_CHANNEL_ID=<他メンバーに確認>
LINE_LOGIN_CHANNEL_SECRET=<他メンバーに確認>
```

## 2. LINE Developers コンソールの設定

LINE Login チャネルのコールバック URL に以下を登録する必要があります。

```
http://localhost:9000/api/line/callback
```

設定場所: LINE Developers コンソール → 対象チャネル → LINE Login タブ → **コールバック URL**

この設定も他メンバーに依頼するか、コンソールへのアクセス権がある場合は自分で追加してください。

## 3. dev container の再起動

`.env` の内容は dev container 起動時に読み込まれます（`.devcontainer/docker-compose.yml` の `env_file` 設定）。
そのため、`.env` を新規作成・変更した場合は **dev container を Rebuild** する必要があります。

VS Code のコマンドパレット（`Ctrl+Shift+P` / `Cmd+Shift+P`）から以下を実行してください：

```
Dev Containers: Rebuild Container
```

> **注意**: Rebuild 後はバックエンド・フロントエンドのサーバーを再起動してください。

## 5. アプリの起動

バックエンドとフロントエンドを起動します。

```bash
# バックエンド（ポート 8000）
uvicorn apis.main:app --host 0.0.0.0 --port 8000 --reload

# フロントエンド（ポート 9000）
cd ui && npm run dev
```

VS Code のタスク「Full Stack: Start All Services」を使うと両方まとめて起動できます。

## 6. LINE 連携の手順

1. ブラウザで `http://localhost:9000` にアクセスしてログイン
2. サイドバーから **アカウント情報** 画面を開く
3. 「**LINE 連携する**」ボタンをクリック
4. LINE の認証画面にリダイレクトされるので、LINE アカウントでログインして許可
5. `http://localhost:9000/api/line/callback` にリダイレクトされ、連携完了メッセージが表示される

連携が成功すると、該当ユーザーの `app_users.line_user_id` に LINE ユーザー ID が保存されます。

## 7. トラブルシューティング

### コールバックで「LINE認証に失敗しました」と表示される

- `.env` の `LINE_LOGIN_CHANNEL_ID`、`LINE_LOGIN_CHANNEL_SECRET` が正しく設定されているか確認
- LINE Developers コンソールのコールバック URL に `http://localhost:9000/api/line/callback` が登録されているか確認

### リダイレクト後に `redirect_uri_mismatch` エラーが表示される

- `LINE_LOGIN_REDIRECT_URI` の値と LINE Developers コンソールに登録されているコールバック URL が完全一致しているか確認（末尾スラッシュの有無も含む）

### 関連コード

- バックエンドのコールバック処理: `apis/notify.py` の `GET /api/line/callback`
- フロントエンドの連携ボタン: `ui/src/pages/AccountView.vue` の `linkLine()`
- コールバック結果表示: `ui/src/pages/LineCallbackView.vue`
