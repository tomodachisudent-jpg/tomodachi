# 先生向け給与明細CSV出力機能 設計書

## 1. 概要

先生（provider）が自分自身の月次給与明細をCSV形式でダウンロードできる機能。
先生は自分の給与のみ閲覧・出力でき、他の先生の給与は参照できない。

## 2. バックエンド

### 2.1 API

**エンドポイント**: `GET /api/provider/payroll`

**認証**: provider権限が必要（adminもアクセス可能）

**パラメータ**:

| パラメータ名 | 型 | 必須 | 説明 | 例 |
|------------|------|------|------|-----|
| year | int | Yes | 対象年（クエリ、2000以上） | 2026 |
| month | int | Yes | 対象月（クエリ、1-12） | 2 |

### 2.2 処理の流れ

1. JWTトークンからログイン中の先生のuser_idを取得する
2. year, monthのバリデーションチェックを行う（admin.pyのvalidate_year_monthと同じルール）
3. 取得したuser_idをprovider_idとして、既存の`calc_monthly_payroll`を呼び出す
4. 結果をそのまま返却する

**利用するDBデータ**:
- providers: 時給情報（hourly_rate_offline, hourly_rate_online）
- app_users: 先生名（display_name）
- service_logs: 対象月の授業実施記録（start_at, end_at, s_type）

**備考**:
- 給与計算ロジック自体は既存の`apis/services/payroll.py`の`calc_monthly_payroll`を再利用する
- `validate_year_month`関数は`admin.py`から共通化するか、provider.py内で同じものを用意する

### 2.3 実装対象ファイル

| ファイル | 変更内容 |
|---------|---------|
| `apis/provider.py` | 新規エンドポイント `GET /api/provider/payroll` を追加 |

## 3. フロントエンド

### 3.1 画面

**ページ**: 新規ページ `ui/src/pages/ProviderPayroll.vue`

**ルート**: `/provider/payroll`（provider権限）

### 3.2 画面項目

- 対象年月選択
  - 年選択ドロップダウン（2000年〜現在年+1年）
  - 月選択ドロップダウン（1〜12）
  - 検索ボタン
- 給与情報表示カード
  - 先生名
  - 対象月
  - 総授業時間
  - 対面授業時間
  - 時給（対面）
  - オンライン授業時間
  - 時給（オンライン）
  - 総給与額
- CSVダウンロードボタン

### 3.3 イベント処理

- **検索ボタンクリック時**
  - `GET /api/provider/payroll?year={年}&month={月}` を呼び出す
  - 取得した給与データを画面に表示する

- **CSVダウンロードボタンクリック時**
  - 表示中の給与データからCSVを生成しダウンロードする
  - CSVはBOM付きUTF-8で出力する（Excel対応）

### 3.4 CSV出力フォーマット

**ファイル名**: `給与明細_{先生名}_{年}年{月}月.csv`

**CSV列**:

| 列名 | データ元 |
|------|---------|
| 先生名 | provider_name |
| 対象月 | month |
| 総授業時間 | total_hours |
| 対面授業時間 | offline_hours |
| 時給（対面） | hourly_rate_offline |
| オンライン授業時間 | online_hours |
| 時給（オンライン） | hourly_rate_online |
| 給与額 | total_amount |

### 3.5 APIエンドポイント

| 操作 | メソッド | エンドポイント |
|------|---------|--------------|
| 給与データ取得 | GET | `/api/provider/payroll?year={年}&month={月}` |

### 3.6 ルーター追加

`ui/src/router/routes.js` に以下を追加:
- パス: `/provider/payroll`
- 権限: provider

### 3.7 ナビゲーション

サイドメニューに「給与明細」リンクを追加する（provider権限のみ表示）。
