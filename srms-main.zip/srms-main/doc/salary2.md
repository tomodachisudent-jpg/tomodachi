# 給与計算機能 基本設計書

## 1. 概要

日本語教室の先生（provider）の給与を月次で計算する機能の基本設計書。
実際に提供された授業サービスの記録から、先生ごとの給与を算出する。

## 2. データモデル

### 2.1 関連テーブル

#### app_users
ユーザー情報を管理

| カラム名 | 型 | 説明 |
|---------|-----|------|
| id | uuid | ユーザーID（主キー） |
| email | text | メールアドレス（UNIQUE） |
| name | text | 氏名 |
| display_name | text | 表示名 |
| role | app_role | ユーザーロール（admin/provider/receiver） |
| is_active | boolean | アクティブフラグ |

#### providers
先生情報を管理

| カラム名 | 型 | 説明 |
|---------|-----|------|
| user_id | uuid | ユーザーID（主キー、FK: app_users.id） |
| hourly_rate_offline | numeric(10,2) | 対面授業の時給（デフォルト: 2000円） |
| hourly_rate_online | numeric(10,2) | オンライン授業の時給（デフォルト: 1800円） |

#### receivers
生徒情報を管理

| カラム名 | 型 | 説明 |
|---------|-----|------|
| user_id | uuid | ユーザーID（主キー、FK: app_users.id） |
| notes | text | 備考 |

#### shifts
授業枠（シフト）情報を管理

| カラム名 | 型 | 説明 |
|---------|-----|------|
| id | bigserial | シフトID（主キー） |
| provider_id | uuid | 先生ID（FK: providers.user_id） |
| start_at | timestamptz | 開始日時 |
| end_at | timestamptz | 終了日時 |
| s_type | shift_type | 授業形態（offline/online） |
| is_locked | boolean | ロックフラグ |

#### reservations
予約情報を管理

| カラム名 | 型 | 説明 |
|---------|-----|------|
| id | bigserial | 予約ID（主キー） |
| shift_id | bigint | シフトID（FK: shifts.id、UNIQUE） |
| receiver_id | uuid | 生徒ID（FK: receivers.user_id） |
| status | reservation_status | 予約ステータス（reserved/canceled/completed） |

#### service_logs
サービス実施記録を管理（給与計算の基礎データ）

| カラム名 | 型 | 説明 |
|---------|-----|------|
| id | bigserial | ログID（主キー） |
| reservation_id | bigint | 予約ID（FK: reservations.id、UNIQUE） |
| provider_id | uuid | 先生ID（FK: providers.user_id） |
| receiver_id | uuid | 生徒ID（FK: receivers.user_id） |
| start_at | timestamptz | 実施開始日時 |
| end_at | timestamptz | 実施終了日時 |
| s_type | shift_type | 授業形態（offline/online） |
| created_at | timestamptz | 作成日時 |

## 3. 給与計算ロジック

### 3.1 計算式

**月次給与 = Σ(授業時間 × 形態別時給)**

- 対面授業（offline）: 授業時間 × hourly_rate_offline
- オンライン授業（online）: 授業時間 × hourly_rate_online

### 3.2 授業時間の計算

授業時間は、service_logsテーブルのstart_atとend_atの差分から算出する。
差分は秒単位で計算されるため、3600で除算し時間単位に変換する。

### 3.3 処理フロー

#### 個別先生の月次給与計算処理

**入力**:
- provider_id（先生ID）
- year（対象年）
- month（対象月）

**処理手順**:

1. **時給情報の取得**
   - providersテーブルから該当先生の時給を取得
   - hourly_rate_offline（対面授業の時給、デフォルト2000円）
   - hourly_rate_online（オンライン授業の時給、デフォルト1800円）

2. **対象月のサービス実施記録の取得**
   - service_logsテーブルから以下の条件でレコードを取得：
     - provider_idが指定の先生IDと一致
     - start_atの年が指定年と一致
     - start_atの月が指定月と一致

3. **各サービス実施記録の処理**
   - 取得した各レコードについて以下を実施：
     - start_atとend_atの差分を秒単位で計算し、3600で除算して時間単位に変換
     - s_type（授業形態）が'offline'の場合：授業時間×hourly_rate_offlineで給与額を算出
     - s_type（授業形態）が'online'の場合：授業時間×hourly_rate_onlineで給与額を算出
     - 授業形態別の合計時間を集計（offline_hours, online_hours）
     - 総授業時間（total_hours）と総給与額（total_amount）を加算

4. **結果の返却**
   - provider_id: 先生ID
   - month: 対象月（YYYY-MM形式）
   - total_hours: 総授業時間（小数点以下2桁で四捨五入）
   - offline_hours: 対面授業時間（小数点以下2桁で四捨五入）
   - online_hours: オンライン授業時間（小数点以下2桁で四捨五入）
   - total_amount: 総給与額（整数値）

#### 全先生の月次給与計算処理

**入力**:
- month（対象月、YYYY-MM形式）

**処理手順**:

1. **アクティブな全先生の取得**
   - app_usersテーブルとprovidersテーブルから、roleが'provider'でis_activeがtrueの先生を取得

2. **各先生の給与計算**
   - 取得した先生それぞれに対して、上記の個別先生の月次給与計算処理を実行

3. **結果の集約と返却**
   - 各先生の計算結果をリスト形式で返却

## 4. API設計

### 4.1 月次給与計算（個別先生）

**エンドポイント**: `GET /api/admin/payroll/{provider_id}`

**認証**: admin権限が必要

**パラメータ**:
| パラメータ名 | 型 | 必須 | 説明 | 例 |
|------------|------|------|------|-----|
| provider_id | uuid | Yes | 先生ID（パス） | - |
| year | int | Yes | 対象年（クエリ） | 2026 |
| month | int | Yes | 対象月（クエリ） | 1 |

**レスポンス**:
```json
{
  "provider_id": "uuid-string",
  "provider_name": "山田太郎",
  "month": "2026-01",
  "total_hours": 22.5,
  "offline_hours": 15.0,
  "online_hours": 7.5,
  "total_amount": 43500,
  "hourly_rate_offline": 2000.00,
  "hourly_rate_online": 1800.00
}
```

### 4.2 全先生の月次給与計算

**エンドポイント**: `GET /api/admin/payroll`

**認証**: admin権限が必要

**パラメータ**:
| パラメータ名 | 型 | 必須 | 説明 | 例 |
|------------|------|------|------|-----|
| month | string | Yes | 対象月（YYYY-MM形式） | 2026-01 |

**レスポンス**:
```json
[
  {
    "provider_id": "uuid-string",
    "month": "2026-01-01T00:00:00+09:00",
    "gross_pay": 43500.00
  },
  {
    "provider_id": "uuid-string",
    "month": "2026-01-01T00:00:00+09:00",
    "gross_pay": 52000.00
  }
]
```

## 5. 実装方針

### 5.1 データベース

既存のテーブルをそのまま利用:
- **app_users**: ユーザー情報
- **providers**: 先生情報（時給データを含む）
- **receivers**: 生徒情報
- **shifts**: 授業枠情報
- **reservations**: 予約情報
- **service_logs**: サービス実施記録（給与計算の基礎データ）

※マイグレーションは不要

### 5.2 バックエンド実装

**担当ファイル**: `apis/services/payroll.py`, `apis/main.py`

**サービス層**:
- 個別先生の月次給与計算処理を実装
  - 入力: provider_id, year, month
  - 処理: providersテーブルから時給を取得し、service_logsテーブルから対象月のレコードを取得して集計
  - 出力: provider_id, month, total_hours, offline_hours, online_hours, total_amount

- 全先生の月次給与計算処理を実装
  - 入力: month（YYYY-MM形式）
  - 処理: アクティブな全先生を取得し、各先生の月次給与計算を実行
  - 出力: 各先生の計算結果のリスト

**API層**:
- 認証: admin権限が必要
- エンドポイント1: `GET /api/admin/payroll/{provider_id}` - 個別先生の給与計算
  - パスパラメータ: provider_id
  - クエリパラメータ: year, month
- エンドポイント2: `GET /api/admin/payroll` - 全先生の給与計算
  - クエリパラメータ: month（YYYY-MM形式）

### 5.3 フロントエンド実装

**想定ページ**: `ui/src/pages/PayrollPage.vue`

**画面項目**:
- 対象年月選択
  - 年選択ドロップダウン
  - 月選択ドロップダウン
  - 検索実行ボタン
- 先生一覧テーブル
  - 先生名
  - 総授業時間
  - 対面授業時間
  - オンライン授業時間
  - 給与額
- CSVエクスポートボタン

**イベント処理**:
- 検索実行ボタンクリック時
  - 選択された年月をもとに `GET /api/admin/payroll` エンドポイントを呼び出し
  - 取得結果を一覧テーブルに表示
- 先生名クリック時
  - 選択された先生のprovider_idと年月をもとに `GET /api/admin/payroll/{provider_id}` エンドポイントを呼び出し
  - 詳細情報をダイアログまたは別ページで表示
- CSVエクスポートボタンクリック時
  - 表示中のデータをCSV形式でダウンロード

## 6. データフロー

```
1. Shift作成（先生が授業枠を登録）
   ↓
2. Reservation作成（生徒が予約）
   ↓
3. 授業実施
   ↓
4. ServiceLog作成（実施記録を登録）
   - reservation_id
   - provider_id, receiver_id
   - start_at, end_at（実際の実施時間）
   - s_type（授業形態）
   ↓
5. 給与計算（月次でServiceLogを集計）
   - 対象月のservice_logsを抽出
   - 授業時間を計算: (end_at - start_at) / 3600
   - s_typeに応じた時給で給与を計算
```

## 7. 今後の拡張

- 交通費の追加
- 税金・控除の計算
- 給与明細PDFの生成
- 先生自身が自分の給与を確認できる画面
- 給与支払い履歴の管理
- 給与データのエクスポート機能（Excel, PDF）

## 8. 注意事項

- service_logsテーブルは既に実装済み
- providersテーブルには時給データ（hourly_rate_offline, hourly_rate_online）が既に存在
- s_typeはshift_type型（'offline'または'online'）
- 授業時間の計算は秒単位から時間単位に変換が必要
- タイムゾーンは日本時間（JST/UTC+9）を想定
- service_logsのstart_atとend_atは実際の実施時間を記録（shiftsのstart_atとは異なる場合がある）

## 9. 参考資料

- 詳細設計書: `doc/salary.md`
- 既存実装: `apis/services/payroll.py`
- データベーススキーマ: `supabase/schema.sql`
