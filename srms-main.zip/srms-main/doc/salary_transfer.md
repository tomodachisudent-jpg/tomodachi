# 給与振込結果登録機能 設計書

## 1. 概要

管理者が先生（provider）への給与振込完了を年月・先生単位で登録する機能。
既存の給与計算画面（PayrollPage）に振込済みステータスを追加し、管理者が振込完了を記録できるようにする。

## 2. データモデル

### 2.1 新規テーブル

#### salary_transfers

給与振込済み記録を管理する。

| カラム名 | 型 | 制約 | 説明 |
|---------|-----|------|------|
| id | bigserial | 主キー | レコードID |
| provider_id | uuid | NOT NULL, FK: providers.user_id | 先生ID |
| year | int | NOT NULL | 対象年 |
| month | int | NOT NULL, CHECK(1-12) | 対象月 |
| created_at | timestamptz | NOT NULL, DEFAULT now() | 登録日時 |
| created_by | uuid | NOT NULL, FK: app_users.id | 登録した管理者のID |

**ユニーク制約**: (provider_id, year, month)
1人の先生につき、同一年月のレコードは1件のみ。

### 2.2 RLSポリシー

- adminロールのみ全操作（SELECT, INSERT）を許可する

## 3. バックエンド

### 3.1 振込結果登録API

**エンドポイント**: `POST /api/admin/payroll/{provider_id}/transfer`

**認証**: admin権限が必要

**パラメータ**:

| パラメータ名 | 型 | 必須 | 説明 |
|------------|------|------|------|
| provider_id | uuid | Yes | 先生ID（パス） |
| year | int | Yes | 対象年（ボディ、2000以上） |
| month | int | Yes | 対象月（ボディ、1-12） |

**処理の流れ**:

1. year, monthのバリデーションチェックを行う（既存の`validate_year_month`を利用）
2. provider_idに該当する先生がprovidersテーブルに存在するか確認する。存在しなければ404エラーを返す
3. salary_transfersテーブルに同一provider_id・year・monthのレコードが既に存在するか確認する。存在する場合は409エラーを返す
4. salary_transfersテーブルにレコードを挿入する。created_byにはJWTトークンから取得した管理者のuser_idを設定する

**利用するDBデータ**:
- providers: 先生の存在確認（user_id）
- salary_transfers: 重複チェック・レコード挿入（provider_id, year, month, created_by）

### 3.2 振込済み状態取得

既存の全先生月次給与計算API（`GET /api/admin/payroll`）のレスポンスに、振込済みフラグを追加する。

**処理の流れ**:

1. 既存の給与計算処理を実行する
2. salary_transfersテーブルから、対象年月の全レコードを取得する
3. 各先生の給与計算結果に`is_transferred`（振込済みかどうか）を付与して返却する

**利用するDBデータ**:
- salary_transfers: 対象年月の振込済みレコード（provider_id, year, month）

### 3.3 実装対象ファイル

| ファイル | 変更内容 |
|---------|---------|
| `apis/crud/salary_transfer.py` | 新規作成。salary_transfersテーブルのCRUD操作 |
| `apis/services/payroll.py` | `calc_all_providers_payroll`に振込済みフラグの付与処理を追加 |
| `apis/admin.py` | 振込結果登録エンドポイントを追加 |
| `supabase/schema.sql` | salary_transfersテーブル定義を追加 |
| `supabase/policies.sql` | RLSポリシーを追加 |

## 4. フロントエンド

### 4.1 画面

**ページ**: 既存の `ui/src/pages/PayrollPage.vue` に追加

### 4.2 画面項目の変更

給与一覧テーブルに以下のカラムを追加する:

- **振込状態**: 振込済み / 未振込 のステータス表示
- **振込操作**: 「振込済みにする」ボタン

### 4.3 イベント処理

- **「振込済みにする」ボタンクリック時**
  - 確認ダイアログを表示する（「{先生名}の{年}年{月}月の給与を振込済みにしますか？」）
  - ユーザーが確認したら `POST /api/admin/payroll/{provider_id}/transfer` を呼び出す
  - 成功したら給与データを再取得して画面を更新する

- **検索実行時**（既存処理の変更）
  - `GET /api/admin/payroll` のレスポンスに含まれる`is_transferred`フラグを反映して、振込状態カラムに表示する

### 4.4 APIエンドポイント

| 操作 | メソッド | エンドポイント |
|------|---------|--------------|
| 振込結果登録 | POST | `/api/admin/payroll/{provider_id}/transfer` |
| 給与データ取得（振込状態込み） | GET | `/api/admin/payroll?year={年}&month={月}` |
