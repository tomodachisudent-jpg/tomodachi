from fastapi import APIRouter, Depends, HTTPException, Body, Path, UploadFile, File
from .deps import get_db, get_current_user, require_role
from .schemas import ProviderProfile, PaymentMethod
from .services import payment_method as payment_method_service
from .services.notification_planner import complete_reservation_reminders
from .utils import create_supabase_client_from_env, get_storage_url
import psycopg2
import psycopg2.extras
from datetime import datetime, timedelta
import time

router = APIRouter()

# Supabaseクライアント（Service Roleキー使用）
supabase = create_supabase_client_from_env()


def run_notification_hook(db, func, *args, **kwargs):
    cur = db.cursor()
    cur.execute("SAVEPOINT reservation_notification_hook")
    try:
        result = func(db, *args, **kwargs)
    except (psycopg2.Error, ValueError):
        cur.execute("ROLLBACK TO SAVEPOINT reservation_notification_hook")
        return None

    cur.execute("RELEASE SAVEPOINT reservation_notification_hook")
    return result


@router.get(
    "/api/provider/shifts", dependencies=[Depends(require_role("provider", "admin"))]
)
def get_provider_shifts(user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
		SELECT
			s.id,
			s.start_at,
			s.end_at,
			s.s_type,
			s.is_locked,
			r.id AS reservation_id,
			r.receiver_id AS reserved_by,
			r.status AS reservation_status,
			u.display_name AS reserved_by_name,
			EXISTS (
				SELECT 1 FROM service_logs sl
				WHERE sl.reservation_id = r.id
			) AS is_completed
		FROM shifts s
		LEFT JOIN (
			SELECT DISTINCT ON (shift_id) *
			FROM reservations
			ORDER BY shift_id, updated_at DESC
		) r ON r.shift_id = s.id
		LEFT JOIN app_users u ON u.id = r.receiver_id
		WHERE s.provider_id = %s
		ORDER BY s.start_at
	""",
        (user.user_id,),
    )
    return cur.fetchall()


@router.post(
    "/api/provider/shifts", dependencies=[Depends(require_role("provider", "admin"))]
)
def create_shift(
    body: dict = Body(...), user=Depends(get_current_user), db=Depends(get_db)
):
    provider_id = body.get("provider_id") if user.role == "admin" else user.user_id
    start = body["start_at"]
    end = body["end_at"]

    # バリデーション: 1時間単位、00分開始
    start_dt = datetime.fromisoformat(str(start))
    end_dt = datetime.fromisoformat(str(end))
    if start_dt.minute != 0 or end_dt.minute != 0:
        raise HTTPException(400, "シフト開始・終了は00分である必要があります")
    if (end_dt - start_dt) != timedelta(hours=1):
        raise HTTPException(400, "シフトは1時間単位で登録してください")

    cur = db.cursor()

    # シフト登録
    cur.execute(
        """
		INSERT INTO shifts (provider_id, start_at, end_at, s_type)
		VALUES (%s, %s, %s, %s) RETURNING id
	""",
        (provider_id, start, end, body["s_type"]),
    )
    shift_id = cur.fetchone()[0]

    # ROOM自動作成（mode問わず）
    cur.execute(
        """
		INSERT INTO rooms (shift_id, created_by)
		VALUES (%s, %s)
	""",
        (shift_id, provider_id),
    )

    db.commit()
    return {"id": shift_id}


@router.patch(
    "/api/provider/shifts/{shift_id}",
    dependencies=[Depends(require_role("provider", "admin"))],
)
def update_shift(
    shift_id: int = Path(...),
    body: dict = Body(...),
    user=Depends(get_current_user),
    db=Depends(get_db),
):
    provider_id = user.user_id
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cur.execute(
        """
		SELECT s.provider_id, s.is_locked,
			EXISTS (
				SELECT 1 FROM reservations r
				WHERE r.shift_id = s.id AND r.status = 'reserved'
			) AS has_reservation
		FROM shifts s
		WHERE s.id = %s
	""",
        (shift_id,),
    )
    row = cur.fetchone()

    if not row or row["provider_id"] != provider_id:
        raise HTTPException(403, "操作権限がありません")

    if row["is_locked"] or row["has_reservation"]:
        raise HTTPException(400, "予約済みのシフトは操作できません")

    # バリデーション: 1時間単位、00分開始
    start = body["start_at"]
    end = body["end_at"]
    start_dt = datetime.fromisoformat(str(start))
    end_dt = datetime.fromisoformat(str(end))
    if start_dt.minute != 0 or end_dt.minute != 0:
        raise HTTPException(400, "シフト開始・終了は00分である必要があります")
    if (end_dt - start_dt) != timedelta(hours=1):
        raise HTTPException(400, "シフトは1時間単位で登録してください")

    cur.execute(
        """
		UPDATE shifts
		SET start_at = %s, end_at = %s, s_type = %s
		WHERE id = %s
	""",
        (start, end, body["s_type"], shift_id),
    )

    db.commit()
    return {"ok": True}


@router.delete(
    "/api/provider/shifts/{shift_id}",
    dependencies=[Depends(require_role("provider", "admin"))],
)
def delete_shift(
    shift_id: int = Path(...), user=Depends(get_current_user), db=Depends(get_db)
):
    provider_id = user.user_id
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cur.execute(
        """
		SELECT s.provider_id, s.is_locked,
			EXISTS (
				SELECT 1 FROM reservations r
				WHERE r.shift_id = s.id AND r.status = 'reserved'
			) AS has_reservation
		FROM shifts s
		WHERE s.id = %s
	""",
        (shift_id,),
    )
    row = cur.fetchone()

    if not row or row["provider_id"] != provider_id:
        raise HTTPException(403, "操作権限がありません")

    if row["is_locked"] or row["has_reservation"]:
        raise HTTPException(400, "予約済みのシフトは削除できません")

    cur.execute("DELETE FROM shifts WHERE id=%s", (shift_id,))
    db.commit()
    return {"ok": True}


@router.post(
    "/api/provider/complete/{reservation_id}",
    dependencies=[Depends(require_role("provider", "admin"))],
)
def complete_service(
    reservation_id: int, user=Depends(get_current_user), db=Depends(get_db)
):
    cur = db.cursor()

    # 予約情報取得
    cur.execute(
        """
		SELECT r.receiver_id, s.provider_id, s.start_at, s.end_at, s.s_type
		FROM reservations r
		JOIN shifts s ON r.shift_id = s.id
		WHERE r.id = %s AND r.status = 'reserved'
	""",
        (reservation_id,),
    )
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "有効な予約が見つかりません")

    # 実績登録
    cur.execute(
        """
		INSERT INTO service_logs (reservation_id, provider_id, receiver_id, start_at, end_at, s_type)
		VALUES (%s, %s, %s, %s, %s, %s)
	""",
        (reservation_id, row[1], row[0], row[2], row[3], row[4]),
    )

    # 予約ステータス更新
    cur.execute(
        "UPDATE reservations SET status = 'completed' WHERE id = %s", (reservation_id,)
    )
    run_notification_hook(db, complete_reservation_reminders, reservation_id)
    db.commit()
    return {"ok": True}


@router.get(
    "/api/provider/history", dependencies=[Depends(require_role("provider", "admin"))]
)
def get_provider_history(user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor()
    cur.execute(
        """
		SELECT sl.id, sl.start_at, sl.end_at, sl.s_type, au.display_name
		FROM service_logs sl
		JOIN app_users au ON sl.receiver_id = au.id
		WHERE sl.provider_id = %s
		ORDER BY sl.start_at DESC
	""",
        (user.user_id,),
    )
    rows = cur.fetchall()
    return [
        {
            "id": r[0],
            "date": r[1].isoformat(),
            "duration": f"{(r[2] - r[1]).total_seconds() / 3600:.1f}時間",
            "service": "オンライン" if r[3] == "online" else "対面",
            "receiver": r[4],
        }
        for r in rows
    ]


@router.post(
    "/api/provider/service-logs",
    dependencies=[Depends(require_role("provider", "admin"))],
)
def create_log(
    body: dict = Body(...), user=Depends(get_current_user), db=Depends(get_db)
):
    provider_id = (
        body.get("provider_id")
        if (user.role == "admin" and body.get("provider_id"))
        else user.user_id
    )
    cur = db.cursor()
    cur.execute(
        """
	  insert into service_logs (reservation_id, provider_id, receiver_id, start_at, end_at, s_type)
	  values (%s,%s,%s,%s,%s,%s)
	  returning id
	""",
        (
            body["reservation_id"],
            provider_id,
            body["receiver_id"],
            body["start_at"],
            body["end_at"],
            body["s_type"],
        ),
    )
    lid = cur.fetchone()[0]
    db.commit()
    return {"id": lid}


@router.get("/api/provider/profile")
def get_profile(user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM provider_profiles WHERE user_id = %s", (user.user_id,))
    profile = cur.fetchone()
    return profile or {}


@router.get("/api/provider/profile/{provider_id}")
def get_provider_profile(provider_id: str, db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM provider_profiles WHERE user_id = %s", (provider_id,))
    profile = cur.fetchone()
    return profile or {}


@router.post("/api/provider/profile")
def save_profile(
    profile: ProviderProfile, user=Depends(get_current_user), db=Depends(get_db)
):
    cur = db.cursor()
    cur.execute("SELECT id FROM provider_profiles WHERE user_id = %s", (user.user_id,))
    existing = cur.fetchone()

    if existing:
        cur.execute(
            """
            UPDATE provider_profiles SET
              name = %s, job = %s, hobbies = %s, likes = %s,
              lang_ja = %s, lang_en = %s, lang_other = %s,
              in_person = %s, online = %s,
              message = %s, skills = %s, experience = %s, lesson_style = %s,
              photo_url = %s, updated_at = now()
            WHERE user_id = %s
        """,
            (
                profile.name,
                profile.job,
                profile.hobbies,
                profile.likes,
                profile.lang_ja,
                profile.lang_en,
                profile.lang_other,
                profile.in_person,
                profile.online,
                profile.message,
                profile.skills,
                profile.experience,
                profile.lesson_style,
                profile.photo_url,
                user.user_id,
            ),
        )
    else:
        cur.execute(
            """
            INSERT INTO provider_profiles (
              user_id, name, job, hobbies, likes,
              lang_ja, lang_en, lang_other,
              in_person, online,
              message, skills, experience, lesson_style,
              photo_url
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
            (
                user.user_id,
                profile.name,
                profile.job,
                profile.hobbies,
                profile.likes,
                profile.lang_ja,
                profile.lang_en,
                profile.lang_other,
                profile.in_person,
                profile.online,
                profile.message,
                profile.skills,
                profile.experience,
                profile.lesson_style,
                profile.photo_url,
            ),
        )

    db.commit()
    return {"status": "success", "message": "プロフィールを保存しました"}


@router.post("/api/provider/photo-upload")
async def upload_profile_photo(file: UploadFile = File(...)):
    if not supabase:
        raise HTTPException(status_code=500, detail="Supabase が設定されていません")

    contents = await file.read()
    ext = file.filename.split(".")[-1]
    timestamp = int(time.time())
    file_name = f"profile_{timestamp}.{ext}"

    try:
        res = supabase.storage.from_("profile-photos").upload(file_name, contents)
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"ファイルアップロードに失敗しました: {str(e)}"
        )
    # print(type(res))  # → <class 'storage3.responses.UploadResponse'>
    # print(res.error)  # → None または Errorオブジェクト

    if not res or not getattr(res, "path", None):
        raise HTTPException(
            status_code=500,
            detail="ファイルアップロードに失敗しました（レスポンス異常）",
        )

    # 環境に応じたURLを生成（ローカル:相対パス、本番:絶対URL）
    photo_url = get_storage_url("profile-photos", file_name)
    return {"status": "success", "url": photo_url}


@router.get(
    "/api/provider/payment-method",
    dependencies=[Depends(require_role("provider", "admin"))],
)
def get_payment_method(user=Depends(get_current_user), db=Depends(get_db)):
    """自分の振込方法設定を取得"""
    try:
        return payment_method_service.get_payment_method(db, user.user_id)
    except ValueError:
        raise HTTPException(404, "プロバイダー情報が見つかりません")


@router.post(
    "/api/provider/payment-method",
    dependencies=[Depends(require_role("provider", "admin"))],
)
def save_payment_method(
    body: PaymentMethod, user=Depends(get_current_user), db=Depends(get_db)
):
    """振込方法設定を保存/更新"""
    payment_method_service.save_payment_method(db, user.user_id, body)
    return {"status": "success", "message": "振込方法を保存しました"}
