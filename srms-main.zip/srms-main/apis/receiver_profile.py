from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
import psycopg2.extras
import time

from .deps import get_db, get_current_user, require_role
from .schemas import ReceiverProfile
from .utils import create_supabase_client_from_env, get_storage_url

router = APIRouter()

# Supabase クライアント初期化
supabase = create_supabase_client_from_env()


@router.get("/api/receiver/profile", dependencies=[Depends(require_role("receiver"))])
def get_receiver_profile(user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM receiver_profiles WHERE user_id = %s", (user.user_id,))
    profile = cur.fetchone()
    return profile or {}


@router.get(
    "/api/receiver/profile/{receiver_id}",
    dependencies=[Depends(require_role("provider", "admin"))],
)
def get_receiver_profile_by_id(
    receiver_id: str, user=Depends(get_current_user), db=Depends(get_db)
):
    """
    生徒（receiver）のプロフィール情報をreceiver_idで取得するエンドポイント。
    JWT認証を必須化。Provider ロールのユーザーが生徒のプロフィール情報を閲覧する際に使用。

    Args:
        receiver_id: 生徒のユーザーID（UUID）
        user: JWT認証済みユーザー（自動注入）
        db: データベース接続（自動注入）

    Returns:
        ReceiverProfile のデータをJSON形式で返す。存在しない場合は空オブジェクト {}。
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        "SELECT * FROM receiver_profiles WHERE user_id = %s",
        (receiver_id,),
    )
    profile = cur.fetchone()
    return profile or {}


@router.post("/api/receiver/profile", dependencies=[Depends(require_role("receiver"))])
def save_receiver_profile(
    profile: ReceiverProfile, user=Depends(get_current_user), db=Depends(get_db)
):
    cur = db.cursor()
    cur.execute("SELECT id FROM receiver_profiles WHERE user_id = %s", (user.user_id,))
    existing = cur.fetchone()

    if existing:
        cur.execute(
            """
            UPDATE receiver_profiles SET
              name = %s,
              age = %s,
              gender = %s,
              nationality = %s,
              self_introduction = %s,
              learning_goals = %s,
              profile_photo_url = %s,
              learning_history = %s,
              qualifications = %s,
              special_skills = %s,
              japanese_level = %s,
              updated_at = now()
            WHERE user_id = %s
            """,
            (
                profile.name,
                profile.age,
                profile.gender,
                profile.nationality,
                profile.self_introduction,
                profile.learning_goals,
                profile.profile_photo_url,
                profile.learning_history,
                profile.qualifications,
                profile.special_skills,
                profile.japanese_level,
                user.user_id,
            ),
        )
    else:
        cur.execute(
            """
            INSERT INTO receiver_profiles (
              user_id,
              name,
              age,
              gender,
              nationality,
              self_introduction,
              learning_goals,
              profile_photo_url,
              learning_history,
              qualifications,
              special_skills,
              japanese_level
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                user.user_id,
                profile.name,
                profile.age,
                profile.gender,
                profile.nationality,
                profile.self_introduction,
                profile.learning_goals,
                profile.profile_photo_url,
                profile.learning_history,
                profile.qualifications,
                profile.special_skills,
                profile.japanese_level,
            ),
        )

    db.commit()
    return {"status": "success", "message": "プロフィールを保存しました"}


@router.post(
    "/api/receiver/profile-photo", dependencies=[Depends(require_role("receiver"))]
)
async def upload_receiver_profile_photo(
    file: UploadFile = File(...), user=Depends(get_current_user)
):
    """生徒プロフィール用の顔写真をアップロード"""

    if not supabase:
        raise HTTPException(status_code=500, detail="Supabase が設定されていません")

    # ファイル形式検証
    allowed_extensions = ["jpg", "jpeg", "png", "gif"]
    ext = file.filename.split(".")[-1].lower() if file.filename else ""

    if ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"対応している画像形式（JPG、PNG、GIF）を選択してください。現在の形式: {ext}",
        )

    # ファイル読み込み
    contents = await file.read()

    # ファイルサイズ検証（5MB = 5 * 1024 * 1024 bytes）
    max_size = 5 * 1024 * 1024
    if len(contents) > max_size:
        raise HTTPException(
            status_code=400,
            detail=f"ファイルサイズは5MB以下にしてください。現在のサイズ: {len(contents) / (1024 * 1024):.2f}MB",
        )

    # ファイル名生成（receiver_{user_id}_{timestamp}.{ext}）
    timestamp = int(time.time())
    file_name = f"receiver_{user.user_id}_{timestamp}.{ext}"

    # Supabase Storage にアップロード
    try:
        res = supabase.storage.from_("receiver-profile-photos").upload(
            file_name, contents
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"ファイルアップロードに失敗しました: {str(e)}"
        )

    # アップロード結果の検証
    if not res or not getattr(res, "path", None):
        raise HTTPException(
            status_code=500,
            detail="ファイルアップロードに失敗しました（レスポンス異常）",
        )

    # 環境に応じたURLを生成（ローカル:相対パス、本番:絶対URL）
    profile_photo_url = get_storage_url("receiver-profile-photos", file_name)

    return {"status": "success", "url": profile_photo_url}
