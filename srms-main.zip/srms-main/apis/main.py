from fastapi import FastAPI, Depends, HTTPException, Body, Path, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from .deps import get_db, get_current_user, require_role
from .auth import hash_password, create_access_token, verify_password, TokenData
from .security import ensure_not_self_demotion, generate_password
from .services.slack import notify
from .services.line import send_line_notification
from pydantic import BaseModel, EmailStr
from .services.mail import send_mailjet_email
import psycopg2.extras
from uuid import UUID
from datetime import datetime, timedelta, timezone
from .schemas import MailRequest
from .notification_runtime import notification_worker_lifespan
import logging

# 環境変数を .env ファイルから自動読み込み
from dotenv import load_dotenv

# override=True: .env ファイルの値でシステム環境変数を上書き
# 開発環境では .env を優先、本番環境では .env がないのでシステム環境変数を使用
load_dotenv(override=True)

# ロギング設定（DEBUG レベルで全ログを出力）
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


from .login import router as login_router
from .admin import router as admin_router
from .provider import router as provider_router
from .receiver_profile import router as receiver_profile_router
from .receiver import router as receiver_router

from .notify import router as notify_router
from .room import router as room_router

app = FastAPI(title="Shift Reservation API", lifespan=notification_worker_lifespan)


# 開発用：環境変数確認エンドポイント
import os


@app.get("/api/debug/env")
def debug_env():
    """開発用：環境変数の確認（本番では削除すること）"""
    return {
        "SUPABASE_URL": os.getenv("SUPABASE_URL", "(not set)"),
        "SUPABASE_KEY": os.getenv("SUPABASE_KEY", "(not set)")[:20] + "..."
        if os.getenv("SUPABASE_KEY")
        else "(not set)",
    }


# 必要なルーターのみ登録
app.include_router(login_router)
app.include_router(admin_router)
app.include_router(provider_router)
app.include_router(receiver_router)
app.include_router(receiver_profile_router)

app.include_router(notify_router)
app.include_router(room_router)

# CORS設定（必要に応じて調整）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
