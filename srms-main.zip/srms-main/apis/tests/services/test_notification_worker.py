import asyncio
from datetime import datetime, timedelta, timezone

from apis.services.notification_delivery import NotificationSendResult
from apis.services.notification_worker import (
    MAX_RETRY_ATTEMPTS,
    RETRY_DELAYS,
    process_due_notification_deliveries,
    process_notification_delivery,
)


def test_process_notification_delivery_marks_sent(monkeypatch):
    recorded_updates = []

    def fake_update(db, **kwargs):
        recorded_updates.append(kwargs)

    async def sender(delivery):
        return NotificationSendResult("sent", "ok")

    monkeypatch.setattr(
        "apis.services.notification_worker._update_delivery_status", fake_update
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._has_prior_provider_guard",
        lambda db, delivery: False,
    )

    result = asyncio.run(
        process_notification_delivery(
            object(),
            {"id": 101, "attempt_count": 0},
            sender=sender,
            now=datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc),
        )
    )

    assert result == {"delivery_id": 101, "status": "sent"}
    assert recorded_updates == [
        {"delivery_id": 101, "status": "sent", "attempt_count": 1}
    ]


def test_process_notification_delivery_retries_after_failure(monkeypatch):
    recorded_updates = []

    def fake_update(db, **kwargs):
        recorded_updates.append(kwargs)

    async def sender(delivery):
        raise RuntimeError("temporary outage")

    now = datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc)
    monkeypatch.setattr(
        "apis.services.notification_worker._update_delivery_status", fake_update
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._has_prior_provider_guard",
        lambda db, delivery: False,
    )

    result = asyncio.run(
        process_notification_delivery(
            object(),
            {"id": 202, "attempt_count": 0},
            sender=sender,
            now=now,
        )
    )

    assert result == {
        "delivery_id": 202,
        "status": "pending",
        "reason": "temporary outage",
        "next_retry_at": now + timedelta(minutes=RETRY_DELAYS[0]),
    }
    assert recorded_updates == [
        {
            "delivery_id": 202,
            "status": "pending",
            "attempt_count": 1,
            "last_error": "temporary outage",
            "next_retry_at": now + timedelta(minutes=RETRY_DELAYS[0]),
        }
    ]


def test_process_notification_delivery_marks_failed_at_retry_limit(monkeypatch):
    recorded_updates = []

    def fake_update(db, **kwargs):
        recorded_updates.append(kwargs)

    async def sender(delivery):
        raise RuntimeError("provider rejected request")

    monkeypatch.setattr(
        "apis.services.notification_worker._update_delivery_status", fake_update
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._has_prior_provider_guard",
        lambda db, delivery: False,
    )

    result = asyncio.run(
        process_notification_delivery(
            object(),
            {"id": 303, "attempt_count": MAX_RETRY_ATTEMPTS - 1},
            sender=sender,
            now=datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc),
        )
    )

    assert result == {
        "delivery_id": 303,
        "status": "failed",
        "reason": "provider rejected request",
    }
    assert recorded_updates == [
        {
            "delivery_id": 303,
            "status": "failed",
            "attempt_count": MAX_RETRY_ATTEMPTS,
            "last_error": "provider rejected request",
        }
    ]


def test_process_due_notification_deliveries_processes_claimed_batch(monkeypatch):
    claimed = [
        {"id": 1, "attempt_count": 0},
        {"id": 2, "attempt_count": 1},
    ]
    recorded_updates = []

    def fake_claim(db, *, limit, now):
        assert limit == 5
        assert now == datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc)
        return claimed

    def fake_update(db, **kwargs):
        recorded_updates.append(kwargs)

    async def sender(delivery):
        return NotificationSendResult("sent", f"sent-{delivery['id']}")

    monkeypatch.setattr(
        "apis.services.notification_worker.claim_due_notification_deliveries",
        fake_claim,
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._update_delivery_status", fake_update
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._has_prior_provider_guard",
        lambda db, delivery: False,
    )

    results = asyncio.run(
        process_due_notification_deliveries(
            object(),
            limit=5,
            sender=sender,
            now=datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc),
        )
    )

    assert results == [
        {"delivery_id": 1, "status": "sent"},
        {"delivery_id": 2, "status": "sent"},
    ]
    assert recorded_updates == [
        {"delivery_id": 1, "status": "sent", "attempt_count": 1},
        {"delivery_id": 2, "status": "sent", "attempt_count": 2},
    ]


def test_process_notification_delivery_skips_provider_duplicate(monkeypatch):
    recorded_updates = []
    sender_called = {"value": False}

    def fake_update(db, **kwargs):
        recorded_updates.append(kwargs)

    async def sender(delivery):
        sender_called["value"] = True
        return NotificationSendResult("sent", "ok")

    monkeypatch.setattr(
        "apis.services.notification_worker._update_delivery_status", fake_update
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._has_prior_provider_guard",
        lambda db, delivery: True,
    )

    result = asyncio.run(
        process_notification_delivery(
            object(),
            {
                "id": 404,
                "attempt_count": 0,
                "recipient_role": "provider",
                "reservation_snapshot": {"shift_id": 99},
                "channel": "mail",
                "stage": "1_day",
                "scheduled_for": datetime(2026, 3, 20, 9, 0, tzinfo=timezone.utc),
                "notification_type": "reservation_reminder",
            },
            sender=sender,
        )
    )

    assert result == {
        "delivery_id": 404,
        "status": "skipped",
        "reason": "Skipped duplicate provider reminder for same shift",
    }
    assert sender_called["value"] is False
    assert recorded_updates == [
        {
            "delivery_id": 404,
            "status": "skipped",
            "attempt_count": 0,
            "last_error": "Skipped duplicate provider reminder for same shift",
        }
    ]


def test_process_due_notification_deliveries_skips_duplicate_provider_in_batch(
    monkeypatch,
):
    scheduled_for = datetime(2026, 3, 16, 10, 0, tzinfo=timezone.utc)
    claimed = [
        {
            "id": 10,
            "attempt_count": 0,
            "recipient_role": "provider",
            "reservation_snapshot": {"shift_id": 50},
            "channel": "mail",
            "stage": "1_day",
            "scheduled_for": scheduled_for,
            "notification_type": "reservation_reminder",
        },
        {
            "id": 11,
            "attempt_count": 0,
            "recipient_role": "provider",
            "reservation_snapshot": {"shift_id": 50},
            "channel": "mail",
            "stage": "1_day",
            "scheduled_for": scheduled_for,
            "notification_type": "reservation_reminder",
        },
        {
            "id": 12,
            "attempt_count": 0,
            "recipient_role": "receiver",
            "reservation_snapshot": {"shift_id": 50},
            "channel": "mail",
            "stage": "1_day",
            "scheduled_for": scheduled_for,
            "notification_type": "reservation_reminder",
        },
    ]
    recorded_updates = []
    sent_ids = []

    def fake_claim(db, *, limit, now):
        return claimed

    def fake_update(db, **kwargs):
        recorded_updates.append(kwargs)

    async def sender(delivery):
        sent_ids.append(delivery["id"])
        return NotificationSendResult("sent", f"sent-{delivery['id']}")

    monkeypatch.setattr(
        "apis.services.notification_worker.claim_due_notification_deliveries",
        fake_claim,
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._update_delivery_status", fake_update
    )
    monkeypatch.setattr(
        "apis.services.notification_worker._has_prior_provider_guard",
        lambda db, delivery: False,
    )

    results = asyncio.run(
        process_due_notification_deliveries(
            object(),
            limit=10,
            sender=sender,
            now=datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc),
        )
    )

    assert results == [
        {
            "delivery_id": 11,
            "status": "skipped",
            "reason": "Skipped duplicate provider reminder for same shift",
        },
        {"delivery_id": 10, "status": "sent"},
        {"delivery_id": 12, "status": "sent"},
    ]
    assert sent_ids == [10, 12]
    assert recorded_updates == [
        {
            "delivery_id": 11,
            "status": "skipped",
            "attempt_count": 0,
            "last_error": "Skipped duplicate provider reminder for same shift",
        },
        {"delivery_id": 10, "status": "sent", "attempt_count": 1},
        {"delivery_id": 12, "status": "sent", "attempt_count": 1},
    ]
