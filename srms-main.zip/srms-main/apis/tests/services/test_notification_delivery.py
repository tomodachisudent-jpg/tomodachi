import asyncio

import pytest

from apis.services.notification_delivery import (
    NotificationDeliveryError,
    build_reminder_content,
    send_reminder_notification,
)


def sample_delivery(**overrides):
    delivery = {
        "reservation_id": 55,
        "recipient_role": "receiver",
        "channel": "mail",
        "stage": "30_minutes",
        "reservation_snapshot": {
            "start_at": "2026-03-16T10:00:00+00:00",
            "end_at": "2026-03-16T11:00:00+00:00",
            "service_type": "online",
            "provider": {
                "display_name": "Provider One",
                "email": "provider@example.com",
                "line_user_id": "provider-line",
            },
            "receiver": {
                "display_name": "Receiver One",
                "email": "receiver@example.com",
                "line_user_id": "receiver-line",
            },
        },
    }
    delivery.update(overrides)
    return delivery


def test_build_reminder_content_formats_receiver_message():
    content = build_reminder_content(sample_delivery())

    assert content["subject"] == "【授業リマインド】30分前のご案内"
    assert "Receiver One 様" in content["text_body"]
    assert "Provider One" in content["text_body"]
    assert "形式: オンライン" in content["text_body"]
    assert "2026/03/16 19:00" in content["line_message"]


def test_build_reminder_content_supports_legacy_snapshot_keys():
    content = build_reminder_content(
        sample_delivery(
            reservation_snapshot={
                "start_at": "2026-03-16T10:00:00+00:00",
                "end_at": "2026-03-16T11:00:00+00:00",
                "lesson_type": "offline",
                "provider": {
                    "name": "Provider Legacy",
                    "email": "provider@example.com",
                    "line_user_id": "provider-line",
                },
                "receiver": {
                    "name": "Receiver Legacy",
                    "email": "receiver@example.com",
                    "line_user_id": "receiver-line",
                },
            }
        )
    )

    assert "Receiver Legacy 様" in content["text_body"]
    assert "Provider Legacy" in content["line_message"]
    assert "形式: 対面" in content["line_message"]


def test_send_reminder_notification_skips_when_contact_missing():
    base_snapshot = sample_delivery()["reservation_snapshot"]
    delivery = sample_delivery(
        reservation_snapshot={
            **base_snapshot,
            "receiver": {
                "name": "Receiver One",
                "email": "",
                "line_user_id": "receiver-line",
            },
        }
    )

    async def line_sender(*args, **kwargs):
        raise AssertionError("line sender should not be called")

    async def mail_sender(*args, **kwargs):
        raise AssertionError("mail sender should not be called")

    result = asyncio.run(
        send_reminder_notification(
            delivery, line_sender=line_sender, mail_sender=mail_sender
        )
    )

    assert result.status == "skipped"
    assert result.message == "メールアドレス未設定"


def test_send_reminder_notification_raises_on_sender_error():
    async def line_sender(*args, **kwargs):
        raise AssertionError("line sender should not be called")

    async def mail_sender(*args, **kwargs):
        return {"status": "error", "detail": "mail provider timeout"}

    with pytest.raises(NotificationDeliveryError, match="mail provider timeout"):
        asyncio.run(
            send_reminder_notification(
                sample_delivery(), line_sender=line_sender, mail_sender=mail_sender
            )
        )


def test_send_reminder_notification_uses_line_channel_when_requested():
    calls = []

    async def line_sender(line_user_id, message):
        calls.append((line_user_id, message))
        return {"status": "sent", "message": "ok"}

    async def mail_sender(*args, **kwargs):
        raise AssertionError("mail sender should not be called")

    result = asyncio.run(
        send_reminder_notification(
            sample_delivery(channel="line"),
            line_sender=line_sender,
            mail_sender=mail_sender,
        )
    )

    assert result.status == "sent"
    assert calls == [
        (
            "receiver-line",
            (
                "【授業リマインド】30分前\n"
                "日時: 2026/03/16 19:00 ～ 2026/03/16 20:00\n"
                "形式: オンライン\n"
                "相手: Provider One\n"
                "予約ID: 55"
            ),
        )
    ]
