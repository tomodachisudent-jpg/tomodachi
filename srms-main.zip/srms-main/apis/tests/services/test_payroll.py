"""
給与計算 サービス層テスト（振込方法情報の返却）
"""
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock
from uuid import UUID

from apis.services.payroll import calc_monthly_payroll


class TestCalcMonthlyPayrollPaymentMethod:
    """calc_monthly_payroll の振込方法情報返却テスト"""

    @patch("apis.services.payroll.payroll_crud")
    def test_includes_bank_payment_method(self, mock_crud):
        """銀行振込の振込方法情報がレスポンスに含まれる"""
        mock_crud.get_provider_hourly_rates.return_value = {
            "hourly_rate_offline": 2000,
            "hourly_rate_online": 1800,
            "display_name": "テスト先生",
            "payment_method": "bank",
            "bank_name": "テスト銀行",
            "bank_branch": "テスト支店",
            "bank_account_type": "普通",
            "bank_account_number": "1234567",
            "bank_account_holder": "テスト太郎",
            "paypay_id": None,
            "paypay_phone_number": None,
        }
        mock_crud.get_monthly_service_logs.return_value = []
        db = MagicMock()

        result = calc_monthly_payroll(
            db, UUID("00000000-0000-0000-0000-000000000001"), 2026, 1
        )

        assert result["payment_method"] == "bank"
        assert result["bank_name"] == "テスト銀行"
        assert result["bank_branch"] == "テスト支店"
        assert result["bank_account_type"] == "普通"
        assert result["bank_account_number"] == "1234567"
        assert result["bank_account_holder"] == "テスト太郎"
        assert result["paypay_id"] is None
        assert result["paypay_phone_number"] is None

    @patch("apis.services.payroll.payroll_crud")
    def test_includes_paypay_payment_method(self, mock_crud):
        """PayPayの振込方法情報がレスポンスに含まれる"""
        mock_crud.get_provider_hourly_rates.return_value = {
            "hourly_rate_offline": 2000,
            "hourly_rate_online": 1800,
            "display_name": "テスト先生",
            "payment_method": "paypay",
            "bank_name": None,
            "bank_branch": None,
            "bank_account_type": None,
            "bank_account_number": None,
            "bank_account_holder": None,
            "paypay_id": "test_id_123",
            "paypay_phone_number": "09012345678",
        }
        mock_crud.get_monthly_service_logs.return_value = []
        db = MagicMock()

        result = calc_monthly_payroll(
            db, UUID("00000000-0000-0000-0000-000000000001"), 2026, 1
        )

        assert result["payment_method"] == "paypay"
        assert result["bank_name"] is None
        assert result["paypay_id"] == "test_id_123"
        assert result["paypay_phone_number"] == "09012345678"

    @patch("apis.services.payroll.payroll_crud")
    def test_includes_hand_payment_method(self, mock_crud):
        """手渡しの振込方法情報がレスポンスに含まれる"""
        mock_crud.get_provider_hourly_rates.return_value = {
            "hourly_rate_offline": 2000,
            "hourly_rate_online": 1800,
            "display_name": "テスト先生",
            "payment_method": "hand",
            "bank_name": None,
            "bank_branch": None,
            "bank_account_type": None,
            "bank_account_number": None,
            "bank_account_holder": None,
            "paypay_id": None,
            "paypay_phone_number": None,
        }
        mock_crud.get_monthly_service_logs.return_value = []
        db = MagicMock()

        result = calc_monthly_payroll(
            db, UUID("00000000-0000-0000-0000-000000000001"), 2026, 1
        )

        assert result["payment_method"] == "hand"
        assert result["bank_name"] is None
        assert result["paypay_id"] is None
        assert result["paypay_phone_number"] is None

    @patch("apis.services.payroll.payroll_crud")
    def test_default_payment_method_when_null(self, mock_crud):
        """payment_methodがNullの場合、デフォルトでhandが返る"""
        provider_data = {
            "hourly_rate_offline": 2000,
            "hourly_rate_online": 1800,
            "display_name": "テスト先生",
        }
        # payment_method キーが存在しない場合
        mock_crud.get_provider_hourly_rates.return_value = provider_data
        mock_crud.get_monthly_service_logs.return_value = []
        db = MagicMock()

        result = calc_monthly_payroll(
            db, UUID("00000000-0000-0000-0000-000000000001"), 2026, 1
        )

        assert result["payment_method"] == "hand"
