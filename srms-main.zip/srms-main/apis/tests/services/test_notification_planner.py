from datetime import datetime, timezone

from apis.services.notification_planner import (
    build_reservation_notification_snapshot,
    cancel_reservation_reminders,
    complete_reservation_reminders,
    list_planned_reminder_deliveries,
    plan_reservation_reminders,
)


class RecordingCursor:
    def __init__(
        self, fetchone_values=None, default_rowcount=1, rowcount_by_prefix=None
    ):
        self.statements = []
        self.fetchone_values = iter(fetchone_values or [])
        self.default_rowcount = default_rowcount
        self.rowcount_by_prefix = rowcount_by_prefix or {}
        self.rowcount = 0

    def execute(self, sql, params=None):
        normalized_sql = " ".join(sql.split())
        self.statements.append((normalized_sql, params))
        self.rowcount = self.default_rowcount
        for prefix, count in self.rowcount_by_prefix.items():
            if normalized_sql.startswith(prefix):
                self.rowcount = count
                break

    def fetchone(self):
        return next(self.fetchone_values)


class RecordingDB:
    def __init__(self, cursor):
        self._cursor = cursor

    def cursor(self):
        return self._cursor


def sample_snapshot(start_at: datetime) -> dict:
    return build_reservation_notification_snapshot(
        {
            "reservation_id": 10,
            "shift_id": 20,
            "status": "reserved",
            "start_at": start_at,
            "end_at": start_at.replace(hour=start_at.hour + 1),
            "service_type": "online",
            "provider_id": "provider-1",
            "provider_name": "Provider One",
            "provider_email": "provider@example.com",
            "provider_line_user_id": "line-provider",
            "receiver_id": "receiver-1",
            "receiver_name": "Receiver One",
            "receiver_email": "receiver@example.com",
            "receiver_line_user_id": "line-receiver",
        }
    )


def test_list_planned_reminder_deliveries_skips_elapsed_stages():
    planned_at = datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc)
    snapshot = sample_snapshot(datetime(2026, 3, 16, 11, 30, tzinfo=timezone.utc))

    deliveries = list_planned_reminder_deliveries(snapshot, planned_at=planned_at)

    assert len(deliveries) == 16
    assert {delivery["stage"] for delivery in deliveries} == {
        "2_hours",
        "30_minutes",
        "5_minutes",
        "1_minute",
    }


def test_plan_reservation_reminders_creates_jobs_and_deliveries():
    planned_at = datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc)
    snapshot = sample_snapshot(datetime(2026, 3, 20, 9, 0, tzinfo=timezone.utc))
    cursor = RecordingCursor(fetchone_values=[(1001,), (1002,)])
    db = RecordingDB(cursor)

    result = plan_reservation_reminders(db, snapshot, planned_at=planned_at)

    assert result == {"jobs": 2, "deliveries": 28}
    delivery_statements = [
        statement
        for statement, _ in cursor.statements
        if statement.startswith("INSERT INTO notification_deliveries")
    ]
    assert len(delivery_statements) == 28


def test_cancel_reservation_reminders_marks_pending_rows_canceled():
    canceled_at = datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc)
    cursor = RecordingCursor(
        rowcount_by_prefix={
            "UPDATE notification_deliveries AS deliveries": 8,
            "UPDATE notification_jobs SET is_active = FALSE": 2,
        }
    )
    db = RecordingDB(cursor)

    result = cancel_reservation_reminders(
        db, reservation_id=10, canceled_at=canceled_at
    )

    assert result == {"jobs": 2, "deliveries": 8}
    delivery_update_statement = cursor.statements[0][0]
    assert "jobs.id = deliveries.job_id" in delivery_update_statement
    assert "notification_job_id" not in delivery_update_statement


def test_complete_reservation_reminders_marks_pending_rows_skipped():
    completed_at = datetime(2026, 3, 16, 9, 0, tzinfo=timezone.utc)
    cursor = RecordingCursor(
        rowcount_by_prefix={
            "UPDATE notification_deliveries AS deliveries": 6,
            "UPDATE notification_jobs SET is_active = FALSE": 2,
        }
    )
    db = RecordingDB(cursor)

    result = complete_reservation_reminders(
        db, reservation_id=10, completed_at=completed_at
    )

    assert result == {"jobs": 2, "deliveries": 6}
    delivery_update_statement = cursor.statements[0][0]
    assert "jobs.id = deliveries.job_id" in delivery_update_statement
    assert "notification_job_id" not in delivery_update_statement
