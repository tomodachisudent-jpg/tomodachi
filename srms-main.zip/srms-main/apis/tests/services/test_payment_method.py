"""
振込方法 サービス層テスト
"""
import pytest
from unittest.mock import patch, MagicMock
from pydantic import ValidationError

from apis.services.payment_method import get_payment_method, save_payment_method
from apis.schemas import PaymentMethod, PaymentMethodType


class TestGetPaymentMethod:
    """get_payment_method のテスト"""

    @patch("apis.services.payment_method.payment_method_crud")
    def test_get_payment_method_found(self, mock_crud):
        """CRUD層の返却値がそのまま返る"""
        expected = {
            "payment_method": "bank",
            "bank_name": "テスト銀行",
        }
        mock_crud.get_payment_method.return_value = expected
        db = MagicMock()

        result = get_payment_method(db, "provider-123")

        mock_crud.get_payment_method.assert_called_once_with(db, "provider-123")
        assert result == expected

    @patch("apis.services.payment_method.payment_method_crud")
    def test_get_payment_method_not_found(self, mock_crud):
        """CRUD層がNone返却時にValueErrorが送出される"""
        mock_crud.get_payment_method.return_value = None
        db = MagicMock()

        with pytest.raises(ValueError, match="Provider not found"):
            get_payment_method(db, "nonexistent-id")


class TestSavePaymentMethod:
    """save_payment_method のテスト"""

    @patch("apis.services.payment_method.payment_method_crud")
    def test_save_bank(self, mock_crud):
        """bank選択時: bank_*フィールドが保持され、paypay_id/paypay_phone_numberがNullでCRUDに渡る"""
        db = MagicMock()
        data = PaymentMethod(
            payment_method=PaymentMethodType.bank,
            bank_name="テスト銀行",
            bank_branch="テスト支店",
            bank_account_type="普通",
            bank_account_number="1234567",
            bank_account_holder="テスト太郎",
        )

        save_payment_method(db, "provider-123", data)

        mock_crud.update_payment_method.assert_called_once_with(
            db,
            "provider-123",
            "bank",
            "テスト銀行",
            "テスト支店",
            "普通",
            "1234567",
            "テスト太郎",
            None,  # paypay_id
            None,  # paypay_phone_number
        )

    @patch("apis.services.payment_method.payment_method_crud")
    def test_save_paypay(self, mock_crud):
        """paypay選択時: paypay_idが保持され、bank_*がNullでCRUDに渡る"""
        db = MagicMock()
        data = PaymentMethod(
            payment_method=PaymentMethodType.paypay,
            paypay_id="test_id_123",
        )

        save_payment_method(db, "provider-123", data)

        mock_crud.update_payment_method.assert_called_once_with(
            db,
            "provider-123",
            "paypay",
            None,  # bank_name
            None,  # bank_branch
            None,  # bank_account_type
            None,  # bank_account_number
            None,  # bank_account_holder
            "test_id_123",  # paypay_id
            None,  # paypay_phone_number
        )

    @patch("apis.services.payment_method.payment_method_crud")
    def test_save_hand(self, mock_crud):
        """hand選択時: 全フィールドがNullでCRUDに渡る"""
        db = MagicMock()
        data = PaymentMethod(
            payment_method=PaymentMethodType.hand,
        )

        save_payment_method(db, "provider-123", data)

        mock_crud.update_payment_method.assert_called_once_with(
            db,
            "provider-123",
            "hand",
            None,  # bank_name
            None,  # bank_branch
            None,  # bank_account_type
            None,  # bank_account_number
            None,  # bank_account_holder
            None,  # paypay_id
            None,  # paypay_phone_number
        )


class TestPaymentMethodValidation:
    """PaymentMethodスキーマのバリデーションテスト"""

    def test_paypay_requires_id_or_phone(self):
        """paypay選択時にpaypay_idもpaypay_phone_numberも未指定だとValidationError"""
        with pytest.raises(ValidationError):
            PaymentMethod(
                payment_method=PaymentMethodType.paypay,
            )

    def test_paypay_with_only_id(self):
        """paypay選択時にpaypay_idのみ指定で正常"""
        data = PaymentMethod(
            payment_method=PaymentMethodType.paypay,
            paypay_id="valid_id_123",
        )
        assert data.paypay_id == "valid_id_123"
        assert data.paypay_phone_number is None

    def test_paypay_with_only_phone(self):
        """paypay選択時にpaypay_phone_numberのみ指定で正常"""
        data = PaymentMethod(
            payment_method=PaymentMethodType.paypay,
            paypay_phone_number="09012345678",
        )
        assert data.paypay_id is None
        assert data.paypay_phone_number == "09012345678"

    def test_paypay_phone_normalization(self):
        """ハイフン付き電話番号が正規化される"""
        data = PaymentMethod(
            payment_method=PaymentMethodType.paypay,
            paypay_phone_number="090-1234-5678",
        )
        assert data.paypay_phone_number == "09012345678"

    def test_paypay_phone_invalid_short(self):
        """5桁の電話番号はValidationError"""
        with pytest.raises(ValidationError):
            PaymentMethod(
                payment_method=PaymentMethodType.paypay,
                paypay_phone_number="12345",
            )

    def test_paypay_id_empty_string(self):
        """空文字のPayPay IDはValidationError"""
        with pytest.raises(ValidationError):
            PaymentMethod(
                payment_method=PaymentMethodType.paypay,
                paypay_id="",
            )

    def test_paypay_id_format_invalid(self):
        """不正な文字（@含む等）を含むPayPay IDはValidationError"""
        with pytest.raises(ValidationError):
            PaymentMethod(
                payment_method=PaymentMethodType.paypay,
                paypay_id="invalid@id",
            )

    def test_paypay_id_too_short(self):
        """2文字のPayPay IDはValidationError"""
        with pytest.raises(ValidationError):
            PaymentMethod(
                payment_method=PaymentMethodType.paypay,
                paypay_id="ab",
            )

    def test_paypay_id_too_long(self):
        """16文字のPayPay IDはValidationError"""
        with pytest.raises(ValidationError):
            PaymentMethod(
                payment_method=PaymentMethodType.paypay,
                paypay_id="a" * 16,
            )
