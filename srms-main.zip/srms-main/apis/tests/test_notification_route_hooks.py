from datetime import datetime, timezone
from unittest.mock import ANY
from unittest.mock import MagicMock

from apis import admin, provider, receiver


def test_run_notification_hook_returns_result(mock_db):
    result = receiver.run_notification_hook(mock_db, lambda db, value: value, 123)

    assert result == 123


def test_run_notification_hook_rolls_back_on_value_error(mock_db):
    result = receiver.run_notification_hook(
        mock_db, lambda db: (_ for _ in ()).throw(ValueError("boom"))
    )

    assert result is None


def test_plan_reservation_notifications_for_reservation_builds_snapshot(
    monkeypatch, mock_db
):
    reservation_row = {
        "reservation_id": 9,
        "shift_id": 10,
        "status": "reserved",
        "start_at": datetime(2026, 3, 20, 1, 0, tzinfo=timezone.utc),
        "end_at": datetime(2026, 3, 20, 2, 0, tzinfo=timezone.utc),
        "service_type": "online",
        "provider_id": "provider-1",
        "provider_name": "Provider",
        "provider_email": "provider@example.com",
        "provider_line_user_id": "line-provider",
        "receiver_id": "receiver-1",
        "receiver_name": "Receiver",
        "receiver_email": "receiver@example.com",
        "receiver_line_user_id": "line-receiver",
    }
    snapshot = {"reservation_id": 9}
    captured = {}

    monkeypatch.setattr(
        receiver,
        "get_reservation_notification_row",
        lambda db, reservation_id: reservation_row,
    )
    monkeypatch.setattr(
        receiver,
        "build_reservation_notification_snapshot",
        lambda row: snapshot if row == reservation_row else None,
    )

    def fake_plan(db, planned_snapshot):
        captured["snapshot"] = planned_snapshot
        return {"jobs": 2, "deliveries": 28}

    monkeypatch.setattr(receiver, "plan_reservation_reminders", fake_plan)

    result = receiver.plan_reservation_notifications_for_reservation(mock_db, 9)

    assert result == {"jobs": 2, "deliveries": 28}
    assert captured["snapshot"] == snapshot


def test_provider_complete_service_calls_completion_hook(monkeypatch):
    mock_db = MagicMock()
    cursor = MagicMock()
    cursor.fetchone.return_value = (
        "receiver-1",
        "provider-1",
        datetime.now(),
        datetime.now(),
        "online",
    )
    mock_db.cursor.return_value = cursor

    captured = {}
    monkeypatch.setattr(
        provider,
        "run_notification_hook",
        lambda db, func, reservation_id: captured.setdefault(
            "reservation_id", reservation_id
        ),
    )

    result = provider.complete_service(7, user=MagicMock(), db=mock_db)

    assert result == {"ok": True}
    assert captured["reservation_id"] == 7


def test_admin_force_cancel_calls_cancellation_hook(monkeypatch):
    mock_db = MagicMock()
    cursor = MagicMock()
    cursor.fetchone.return_value = {"id": 11}
    mock_db.cursor.return_value = cursor

    captured = {}
    monkeypatch.setattr(
        admin,
        "run_notification_hook",
        lambda db, func, reservation_id, **kwargs: captured.update(
            {"reservation_id": reservation_id, **kwargs}
        ),
    )

    result = admin.admin_force_cancel(5, db=mock_db)

    assert result == {"ok": True, "admin": True}
    cursor.execute.assert_any_call(
        "UPDATE reservations SET status = 'canceled', canceled_at = %s WHERE id = %s",
        (ANY, 11),
    )
    assert captured["reservation_id"] == 11
    assert captured["canceled_at"].tzinfo == timezone.utc
