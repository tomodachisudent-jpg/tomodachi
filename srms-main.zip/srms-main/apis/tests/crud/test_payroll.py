"""
給与計算 CRUD層テスト
"""
from uuid import UUID
from apis.crud.payroll import get_provider_hourly_rates


class TestGetProviderHourlyRates:
    """get_provider_hourly_rates のテスト"""

    def test_returns_payment_method_fields(self, mock_db, mock_cursor):
        """振込方法カラムがSELECTに含まれている"""
        expected = {
            "hourly_rate_offline": 2000,
            "hourly_rate_online": 1800,
            "display_name": "テスト先生",
            "payment_method": "bank",
            "bank_name": "テスト銀行",
            "bank_branch": "テスト支店",
            "bank_account_type": "普通",
            "bank_account_number": "1234567",
            "bank_account_holder": "テスト太郎",
            "paypay_id": None,
            "paypay_phone_number": None,
        }
        mock_cursor.fetchone.return_value = expected

        result = get_provider_hourly_rates(
            mock_db, UUID("00000000-0000-0000-0000-000000000001")
        )

        assert result["payment_method"] == "bank"
        assert result["bank_name"] == "テスト銀行"
        assert result["bank_branch"] == "テスト支店"
        assert result["bank_account_type"] == "普通"
        assert result["bank_account_number"] == "1234567"
        assert result["bank_account_holder"] == "テスト太郎"
        assert result["paypay_id"] is None
        assert result["paypay_phone_number"] is None

    def test_sql_contains_payment_method_columns(self, mock_db, mock_cursor):
        """SQLに振込方法カラムが含まれている"""
        mock_cursor.fetchone.return_value = {
            "hourly_rate_offline": 2000,
            "hourly_rate_online": 1800,
            "display_name": "先生",
            "payment_method": "hand",
            "bank_name": None,
            "bank_branch": None,
            "bank_account_type": None,
            "bank_account_number": None,
            "bank_account_holder": None,
            "paypay_id": None,
            "paypay_phone_number": None,
        }

        get_provider_hourly_rates(
            mock_db, UUID("00000000-0000-0000-0000-000000000001")
        )

        sql = mock_cursor.execute.call_args[0][0]
        assert "payment_method" in sql
        assert "bank_name" in sql
        assert "bank_branch" in sql
        assert "bank_account_type" in sql
        assert "bank_account_number" in sql
        assert "bank_account_holder" in sql
        assert "paypay_id" in sql
        assert "paypay_phone_number" in sql
