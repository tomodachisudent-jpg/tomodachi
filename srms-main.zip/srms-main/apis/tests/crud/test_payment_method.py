"""
振込方法 CRUD層テスト
"""
from apis.crud.payment_method import get_payment_method, update_payment_method


class TestGetPaymentMethod:
    """get_payment_method のテスト"""

    def test_get_payment_method_found(self, mock_db, mock_cursor):
        """データあり時に正しいdictが返る"""
        expected = {
            "payment_method": "bank",
            "bank_name": "テスト銀行",
            "bank_branch": "テスト支店",
            "bank_account_type": "普通",
            "bank_account_number": "1234567",
            "bank_account_holder": "テスト太郎",
            "paypay_id": None,
            "paypay_phone_number": None,
        }
        mock_cursor.fetchone.return_value = expected

        result = get_payment_method(mock_db, "provider-123")

        mock_db.cursor.assert_called_once()
        mock_cursor.execute.assert_called_once()
        assert result == expected

    def test_get_payment_method_not_found(self, mock_db, mock_cursor):
        """データなし時にNoneが返る"""
        mock_cursor.fetchone.return_value = None

        result = get_payment_method(mock_db, "nonexistent-id")

        assert result is None


class TestUpdatePaymentMethod:
    """update_payment_method のテスト"""

    def test_update_payment_method(self, mock_db, mock_cursor):
        """UPDATE SQLが正しいパラメータで実行される・commitが呼ばれる"""
        update_payment_method(
            mock_db,
            provider_id="provider-123",
            payment_method="bank",
            bank_name="テスト銀行",
            bank_branch="テスト支店",
            bank_account_type="普通",
            bank_account_number="1234567",
            bank_account_holder="テスト太郎",
            paypay_id=None,
            paypay_phone_number=None,
        )

        mock_cursor.execute.assert_called_once()
        call_args = mock_cursor.execute.call_args
        sql = call_args[0][0]
        params = call_args[0][1]

        assert "UPDATE providers" in sql
        assert params == (
            "bank",
            "テスト銀行",
            "テスト支店",
            "普通",
            "1234567",
            "テスト太郎",
            None,
            None,
            "provider-123",
        )
        mock_db.commit.assert_called_once()
