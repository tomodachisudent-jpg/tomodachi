from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException
from fastapi.routing import APIRoute

from apis.admin import (
    get_failed_notifications,
    notification_tables_ready,
    router,
)


def test_notification_tables_ready_returns_true_when_both_tables_exist(
    mock_db, mock_cursor
):
    mock_cursor.fetchone.return_value = (True,)

    result = notification_tables_ready(mock_db)

    assert result is True
    mock_cursor.execute.assert_called_once()


def test_get_failed_notifications_returns_serialized_rows(mock_db):
    table_cursor = MagicMock()
    table_cursor.fetchone.return_value = (True,)

    data_cursor = MagicMock()
    data_cursor.fetchall.return_value = [
        {
            "reservation_id": 12,
            "recipient_type": "receiver",
            "channel": "mail",
            "scheduled_for": None,
            "attempt_count": 3,
            "last_error": "timeout",
            "next_retry_at": None,
        }
    ]

    mock_db.cursor.side_effect = [table_cursor, data_cursor]

    result = get_failed_notifications(mock_db)

    assert result == [
        {
            "reservation_id": 12,
            "recipient_type": "receiver",
            "channel": "mail",
            "scheduled_for": None,
            "attempt_count": 3,
            "last_error": "timeout",
            "next_retry_at": None,
        }
    ]


def test_get_failed_notifications_raises_503_when_tables_missing(mock_db, mock_cursor):
    mock_cursor.fetchone.return_value = (False,)

    with pytest.raises(HTTPException) as exc_info:
        get_failed_notifications(mock_db)

    assert exc_info.value.status_code == 503
    assert "テーブル" in exc_info.value.detail


def test_failed_notifications_route_is_registered_with_dependency():
    route = next(
        route
        for route in router.routes
        if isinstance(route, APIRoute)
        and route.path == "/api/admin/notifications/failed"
        and "GET" in route.methods
    )

    assert route.dependencies
