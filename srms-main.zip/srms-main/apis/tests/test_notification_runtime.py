import asyncio
from types import SimpleNamespace

from apis import notification_runtime


def make_app():
    return SimpleNamespace(state=SimpleNamespace())


class TestNotificationWorkerEnabled:
    def test_returns_true_by_default(self, monkeypatch):
        monkeypatch.delenv("NOTIFICATION_WORKER_ENABLED", raising=False)

        assert notification_runtime.notification_worker_enabled() is True

    def test_returns_true_for_truthy_values(self, monkeypatch):
        monkeypatch.setenv("NOTIFICATION_WORKER_ENABLED", "true")

        assert notification_runtime.notification_worker_enabled() is True

    def test_returns_false_for_falsy_values(self, monkeypatch):
        monkeypatch.setenv("NOTIFICATION_WORKER_ENABLED", "false")

        assert notification_runtime.notification_worker_enabled() is False


class TestNotificationWorkerLifespan:
    def test_skips_worker_when_disabled(self, monkeypatch):
        monkeypatch.setenv("NOTIFICATION_WORKER_ENABLED", "false")
        app = make_app()

        async def exercise():
            async with notification_runtime.notification_worker_lifespan(app):
                assert app.state.notification_worker_task is None
                assert app.state.notification_worker_stop_event is None

        asyncio.run(exercise())

    def test_starts_and_stops_worker_when_enabled(self, monkeypatch):
        monkeypatch.delenv("NOTIFICATION_WORKER_ENABLED", raising=False)
        monkeypatch.setenv("DATABASE_URL", "postgresql://example")
        app = make_app()
        observed = {}

        async def fake_worker(connection_factory, stop_event):
            observed["factory"] = connection_factory
            observed["stop_event"] = stop_event
            await stop_event.wait()

        monkeypatch.setattr(
            notification_runtime,
            "run_notification_worker_loop",
            fake_worker,
        )

        async def exercise():
            async with notification_runtime.notification_worker_lifespan(app):
                await asyncio.sleep(0)
                assert app.state.notification_worker_task is not None
                assert (
                    app.state.notification_worker_stop_event is observed["stop_event"]
                )
                assert (
                    observed["factory"]
                    is notification_runtime.create_notification_worker_connection
                )

            assert observed["stop_event"].is_set() is True
            assert app.state.notification_worker_task is None
            assert app.state.notification_worker_stop_event is None

        asyncio.run(exercise())
