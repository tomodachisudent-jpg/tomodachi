"""receiver 通知日時整形のテスト"""

from datetime import datetime, timezone

from apis.receiver import (
    format_notification_datetime,
    format_notification_datetime_range,
)


class TestFormatNotificationDatetime:
    """通知用日時整形のテスト"""

    def test_utc_datetime_is_converted_to_jst(self):
        """UTC aware datetime を JST 表記へ変換する"""
        dt = datetime(2026, 3, 10, 1, 0, tzinfo=timezone.utc)

        result = format_notification_datetime(dt)

        assert result == "2026/03/10 10:00"

    def test_naive_datetime_is_treated_as_utc(self):
        """naive datetime は UTC とみなして JST 表記へ変換する"""
        dt = datetime(2026, 3, 10, 1, 0)

        result = format_notification_datetime(dt)

        assert result == "2026/03/10 10:00"


class TestFormatNotificationDatetimeRange:
    """通知用日時範囲整形のテスト"""

    def test_datetime_range_is_converted_to_jst(self):
        """開始・終了日時の両方を JST 表記へ変換する"""
        start_at = datetime(2026, 3, 10, 1, 0, tzinfo=timezone.utc)
        end_at = datetime(2026, 3, 10, 2, 30, tzinfo=timezone.utc)

        start_str, end_str = format_notification_datetime_range(start_at, end_at)

        assert start_str == "2026/03/10 10:00"
        assert end_str == "2026/03/10 11:30"
