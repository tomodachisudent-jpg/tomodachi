"""
テスト共通フィクスチャ
"""
import pytest
from unittest.mock import MagicMock


@pytest.fixture
def mock_cursor():
    """RealDictCursor相当のモックカーソル"""
    cursor = MagicMock()
    cursor.execute = MagicMock()
    cursor.fetchone = MagicMock(return_value=None)
    cursor.fetchall = MagicMock(return_value=[])
    return cursor


@pytest.fixture
def mock_db(mock_cursor):
    """DB接続モック"""
    db = MagicMock()
    db.cursor.return_value = mock_cursor
    db.commit = MagicMock()
    return db
