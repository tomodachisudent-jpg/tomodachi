from fastapi import APIRouter, Depends, HTTPException, Body
from uuid import UUID
from .deps import get_db, get_current_user, require_role
import psycopg2.extras
import logging
from datetime import datetime, timezone

router = APIRouter()
logger = logging.getLogger("uvicorn")

@router.get("/api/rooms/{shift_id}", dependencies=[Depends(require_role("provider", "receiver", "admin"))])
def get_room(shift_id: int, user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT s.provider_id, r.receiver_id
        FROM shifts s
        LEFT JOIN reservations r ON s.id = r.shift_id AND r.status IN ('reserved', 'completed')
        WHERE s.id = %s
    """, (shift_id,))
    access = cur.fetchone()
    if not access:
        raise HTTPException(404, f"シフトが存在しません（shift_id={shift_id}）")
    provider_id = access["provider_id"]
    receiver_id = access["receiver_id"]
    if user.role != 'admin' and user.user_id not in [provider_id, receiver_id]:
        logger.warning("ROOMアクセス拒否: 権限なしアクセス")
        raise HTTPException(403, "このROOMにはアクセスできません")
    cur.execute("SELECT * FROM rooms WHERE shift_id = %s", (shift_id,))
    room = cur.fetchone()
    if not room:
        raise HTTPException(404, f"ROOMが存在しません（shift_id={shift_id}）")
    return room

@router.put("/api/rooms/{shift_id}", dependencies=[Depends(require_role("provider", "admin"))])
def update_room(shift_id: int, body: dict = Body(...), user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor()
    cur.execute("""
        UPDATE rooms
        SET meeting_url = %s,
            materials = %s,
            updated_at = now()
        WHERE shift_id = %s AND created_by = %s
    """, (body.get("meeting_url"), body.get("materials"), shift_id, user.user_id))
    db.commit()
    return {"status": "success"}

@router.post("/api/rooms/{room_id}/comments")
def post_comment(room_id: UUID, body: dict = Body(...), user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor()
    cur.execute("""
        INSERT INTO room_comments (room_id, user_id, content)
        VALUES (%s, %s, %s)
    """, (str(room_id), user.user_id, body["content"]))
    db.commit()
    return {"status": "success"}

@router.get("/api/rooms/{room_id}/comments")
def get_comments(room_id: UUID, db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT c.content, c.created_at, u.display_name
        FROM room_comments c
        JOIN app_users u ON c.user_id = u.id
        WHERE c.room_id = %s
        ORDER BY c.created_at ASC
    """, (str(room_id),))
    return cur.fetchall()

@router.get("/api/debug-index")
def debug_index():
    try:
        with open("/usr/share/nginx/html/index.html", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return {"error": str(e)}
