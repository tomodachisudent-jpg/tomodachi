

from fastapi import APIRouter, Depends, HTTPException, Body
from .deps import get_db, get_current_user
from .auth import create_access_token, verify_password, TokenData
import psycopg2.extras

router = APIRouter()

@router.post("/api/auth/login")
def login(email: str = Body(...), password: str = Body(...), db=Depends(get_db)):
	cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

	# 失敗回数・ロック状態も取得
	cur.execute("""
		SELECT id, name, email, password_hash, role, is_active, line_user_id, login_fail_count
		FROM app_users
		WHERE email = %s
	""", (email,))
	row = cur.fetchone()

	if not row or not row["is_active"]:
		raise HTTPException(403, "このアカウントは無効化されています。管理者に連絡してください。")

	if not verify_password(password, row["password_hash"]):
		# 失敗回数を+1
		cur2 = db.cursor()
		cur2.execute("UPDATE app_users SET login_fail_count = COALESCE(login_fail_count,0) + 1 WHERE id = %s", (row["id"],))
		# 5回以上でロック（is_activeをFALSEに）
		cur2.execute("UPDATE app_users SET is_active = FALSE WHERE id = %s AND login_fail_count >= 5", (row["id"],))
		db.commit()
		raise HTTPException(401, "Invalid credentials")

	# 成功時は失敗回数リセット・有効化
	cur2 = db.cursor()
	cur2.execute("UPDATE app_users SET login_fail_count = 0, is_active = TRUE WHERE id = %s", (row["id"],))
	db.commit()

	token = create_access_token(str(row["id"]), row["role"], row["email"],row.get("line_user_id"))

	return {
		"id": row["id"],
		"name": row.get("name", ""),
		"email": row["email"],
		"role": row["role"],
		"line_user_id": row.get("line_user_id"),  # ✅ 追加
		"access_token": token,
		"token_type": "bearer"
	}

@router.get("/api/me")
def get_me(user: TokenData = Depends(get_current_user)):
	return {
		"user_id": user.user_id,
		"email": user.email,
		"role": user.role,
		"line_user_id": user.line_user_id
	}
