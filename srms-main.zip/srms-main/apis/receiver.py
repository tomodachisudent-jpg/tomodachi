from fastapi import APIRouter, Depends, HTTPException, Body, Path, Query
import logging
from .deps import get_db, get_current_user, require_role

logger = logging.getLogger(__name__)
from .crud.reservations import (
    get_reservations_by_receiver,
    get_monthly_cancel_count,
    get_reservation_by_id,
)
import psycopg2
import psycopg2.extras
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from typing import Optional
from .services.line import send_line_notification
from .services.mail import send_mailjet_email
from .services.notification_planner import (
    build_reservation_notification_snapshot,
    plan_reservation_reminders,
    cancel_reservation_reminders,
)
import os

router = APIRouter()

# 月次キャンセル上限
CANCEL_LIMIT = 3
JST = ZoneInfo("Asia/Tokyo")


def format_notification_datetime(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(JST).strftime("%Y/%m/%d %H:%M")


def format_notification_datetime_range(
    start_at: datetime, end_at: datetime
) -> tuple[str, str]:
    return format_notification_datetime(start_at), format_notification_datetime(end_at)


def get_reservation_notification_row(db, reservation_id: int) -> dict:
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT
            r.id AS reservation_id,
            r.shift_id,
            r.status,
            s.start_at,
            s.end_at,
            s.s_type AS service_type,
            s.provider_id,
            p.display_name AS provider_name,
            p.email AS provider_email,
            p.line_user_id AS provider_line_user_id,
            r.receiver_id,
            rc.display_name AS receiver_name,
            rc.email AS receiver_email,
            rc.line_user_id AS receiver_line_user_id
        FROM reservations r
        JOIN shifts s ON s.id = r.shift_id
        JOIN app_users p ON p.id = s.provider_id
        JOIN app_users rc ON rc.id = r.receiver_id
        WHERE r.id = %s
        """,
        (reservation_id,),
    )
    row = cur.fetchone()
    if not row:
        raise HTTPException(500, "通知用の予約情報取得に失敗しました")
    return row


def plan_reservation_notifications_for_reservation(db, reservation_id: int):
    reservation_snapshot = build_reservation_notification_snapshot(
        get_reservation_notification_row(db, reservation_id)
    )
    return plan_reservation_reminders(db, reservation_snapshot)


def run_notification_hook(db, func, *args, **kwargs):
    cur = db.cursor()
    cur.execute("SAVEPOINT reservation_notification_hook")
    try:
        result = func(db, *args, **kwargs)
    except (psycopg2.Error, ValueError) as exc:
        cur.execute("ROLLBACK TO SAVEPOINT reservation_notification_hook")
        logger.warning("reservation notification hook skipped: %s", exc)
        return None

    cur.execute("RELEASE SAVEPOINT reservation_notification_hook")
    return result


@router.get(
    "/api/receiver/shifts", dependencies=[Depends(require_role("receiver", "admin"))]
)
def get_receiver_shifts(user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT
            s.id,
            s.start_at,
            s.end_at,
            s.s_type,
            s.is_locked,
            s.provider_id,
            p.display_name AS provider_name,
            r.receiver_id AS reserved_by,
            u.display_name AS reserved_by_name,
            r.id AS reservation_id,
            EXISTS (
                SELECT 1 FROM service_logs sl
                WHERE sl.reservation_id = r.id
            ) AS is_completed
        FROM shifts s
        LEFT JOIN (
            SELECT DISTINCT ON (shift_id) *
            FROM reservations
            WHERE status IN ('reserved', 'completed')
            ORDER BY shift_id, updated_at DESC
        ) r ON r.shift_id = s.id
        LEFT JOIN app_users u ON u.id = r.receiver_id
        LEFT JOIN app_users p ON p.id = s.provider_id
        ORDER BY s.start_at
    """)
    return cur.fetchall()


@router.get(
    "/api/receiver/reservations",
    dependencies=[Depends(require_role("receiver", "admin"))],
)
def list_reservations(user=Depends(get_current_user), db=Depends(get_db)):
    rows = get_reservations_by_receiver(db, user.user_id)
    result = []
    for r in rows:
        result.append(
            {
                "id": r["id"],
                "start_at": r["start_at"].isoformat() if r["start_at"] else None,
                "end_at": r["end_at"].isoformat() if r["end_at"] else None,
                "s_type": r["s_type"],
                "status": r["status"],
                "provider_name": r["provider_name"],
            }
        )
    return result


@router.post(
    "/api/receiver/shifts/{shift_id}/reserve",
    dependencies=[Depends(require_role("receiver", "admin"))],
)
async def reserve_shift(
    shift_id: int, user=Depends(get_current_user), db=Depends(get_db)
):
    BASE_URL = os.getenv("FRONTEND_BASE_URL", "https://example.com")
    cur = db.cursor()
    # シフトのロック状態確認
    cur.execute("SELECT is_locked FROM shifts WHERE id = %s", (shift_id,))
    row = cur.fetchone()
    if not row or row[0]:
        raise HTTPException(400, "Shift not available")

    # 既存予約の復元または新規作成
    cur.execute(
        """
        SELECT id FROM reservations
        WHERE shift_id = %s AND receiver_id = %s AND status = 'canceled'
    """,
        (shift_id, user.user_id),
    )
    existing = cur.fetchone()
    if existing:
        cur.execute(
            "UPDATE reservations SET status = 'reserved' WHERE id = %s", (existing[0],)
        )
        reservation_id = existing[0]
    else:
        cur.execute(
            """
            INSERT INTO reservations (shift_id, receiver_id, status)
            VALUES (%s, %s, 'reserved')
            RETURNING id
        """,
            (shift_id, user.user_id),
        )
        reservation_id = cur.fetchone()[0]

    cur.execute("UPDATE shifts SET is_locked = true WHERE id = %s", (shift_id,))

    run_notification_hook(
        db, plan_reservation_notifications_for_reservation, reservation_id
    )
    db.commit()

    # 通知用情報取得
    cur.execute(
        """
        SELECT s.start_at, s.end_at, s.s_type,
               p.display_name AS provider_name, p.line_user_id AS provider_line, p.email AS provider_email,
               r.display_name AS receiver_name, r.line_user_id AS receiver_line, r.email AS receiver_email
        FROM shifts s
        JOIN app_users p ON s.provider_id = p.id
        JOIN app_users r ON %s = r.id
        WHERE s.id = %s
    """,
        (user.user_id, shift_id),
    )
    info = cur.fetchone()
    if not info:
        raise HTTPException(500, "通知用の予約情報取得に失敗しました")

    # 日時・形式の整形
    start_str, end_str = format_notification_datetime_range(info[0], info[1])
    type_str = "オンライン" if info[2] == "online" else "対面"

    # 仮のURL（必要に応じて動的生成）
    room_url = f"{BASE_URL}/room/{shift_id}"
    provider_profile_url = f"https://example.com/profile/{info[3]}"
    receiver_profile_url = f"https://example.com/profile/{info[6]}"
    Official_Line_Account_URL = os.getenv(
        "OFFICIAL_ACCOUNT_REDIRECT_URI", "https://lin.ee/86J9msY"
    )
    wechat_id = os.getenv("Wechat_CompanyID", "Tomodachi2023")

    # LINE通知文
    provider_msg = f"{info[6]}が、{start_str}～{end_str}に{type_str}で予約しました。"
    receiver_msg = (
        f"{info[3]}の{start_str}～{end_str}に{type_str}で予約を登録しました。"
    )

    # メール件名
    subject = "【予約通知】友達日本語会話教室からのご連絡"

    # Provider向けメール本文
    provider_body = f"""
{info[3]} 様<br><br>

{info[6]} が以下の内容で予約しました：<br><br>

日時：{start_str} ～ {end_str}<br>
形式：{type_str}<br><br>

授業URL、授業資料はこちらのROOMからご登録<br>
<a href="{room_url}">{room_url}</a><br><br>

{info[6]}さんのプロフィールです。<br>
<a href="{receiver_profile_url}">{receiver_profile_url}</a><br><br>

お問い合わせはこちらの公式ラインからご連絡ください。<br>
<a href="{Official_Line_Account_URL}">{Official_Line_Account_URL}</a><br><br>

授業後修正シートの提出をお願いいたします。<br>

LINEで通知済みです。
"""

    # Receiver向けメール本文
    receiver_body = f"""
{info[6]} 様<br><br>

{info[6]} が以下の内容で予約しました：<br><br>

日時：{start_str} ～ {end_str}<br>
形式：{type_str}<br><br>

授業URLはこちらのROOMからお入りください。<br>
<a href="{room_url}">{room_url}</a><br><br>

{info[3]}のプロフィールです。<br>
<a href="{provider_profile_url}">{provider_profile_url}</a><br><br>

お問い合わせはこちらのwechatからご連絡ください。<br>
We Chat ID : {wechat_id}<br><br>

キャンセルは前日まで可能です。<br><br>

LINEで通知済みです。<br>
キャンセルは前日まで可能です。
"""

    # HTMLラップ関数
    def format_html(text: str) -> str:
        return f"""
        <div style="font-family: 'Meiryo', 'Hiragino Kaku Gothic ProN', 'Segoe UI', sans-serif; font-size: 14px; line-height: 1.6;">
        {text}
        </div>
        """

    # LINE・メール通知（失敗しても予約本体には影響させない）
    try:
        await send_line_notification(info[4], provider_msg)
        await send_line_notification(info[7], receiver_msg)
        await send_mailjet_email(
            info[5], subject, provider_body, html_body=format_html(provider_body)
        )
        await send_mailjet_email(
            info[8], subject, receiver_body, html_body=format_html(receiver_body)
        )
    except Exception as e:
        print(f"通知送信エラー（予約は成功）: {e}")

    return {"ok": True}


@router.post(
    "/api/receiver/reservations",
    dependencies=[Depends(require_role("receiver", "admin"))],
)
def create_reservation(
    body: dict = Body(...), user=Depends(get_current_user), db=Depends(get_db)
):
    receiver_id = body.get("receiver_id") if user.role == "admin" else user.user_id
    cur = db.cursor()
    cur.execute(
        "select id,is_locked from shifts where id=%s for update", (body["shift_id"],)
    )
    row = cur.fetchone()
    if not row or row[1]:
        raise HTTPException(400, "Shift not available")
    cur.execute(
        """
      insert into reservations (shift_id, receiver_id)
      values (%s,%s) returning id
    """,
        (body["shift_id"], receiver_id),
    )
    rid = cur.fetchone()[0]
    cur.execute("update shifts set is_locked=true where id=%s", (body["shift_id"],))

    run_notification_hook(db, plan_reservation_notifications_for_reservation, rid)
    db.commit()
    return {"id": rid}


@router.post(
    "/api/receiver/shifts/{shift_id}/cancel",
    dependencies=[Depends(require_role("receiver"))],
)
def cancel_shift(shift_id: int, user=Depends(get_current_user), db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT r.id, s.start_at
        FROM reservations r
        JOIN shifts s ON s.id = r.shift_id
        WHERE r.shift_id = %s AND r.receiver_id = %s AND r.status = 'reserved'
    """,
        (shift_id, user.user_id),
    )
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "予約が見つかりません")
    now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
    start_at_utc = row["start_at"].astimezone(timezone.utc)
    if now_utc > start_at_utc - timedelta(days=1):
        raise HTTPException(400, "キャンセル可能期間を過ぎています")
    cur.execute(
        "UPDATE reservations SET status = 'canceled' WHERE id = %s", (row["id"],)
    )
    cur.execute("UPDATE shifts SET is_locked = false WHERE id = %s", (shift_id,))
    run_notification_hook(
        db, cancel_reservation_reminders, row["id"], canceled_at=now_utc
    )
    db.commit()
    return {"message": "予約をキャンセルしました"}


@router.post(
    "/api/receiver/reservations/{reservation_id}/cancel",
    dependencies=[Depends(require_role("receiver"))],
)
async def cancel_reservation(
    reservation_id: int = Path(...),
    user=Depends(get_current_user),
    db=Depends(get_db),
):
    """予約キャンセルエンドポイント

    reservation_id ベースでキャンセルを実行する。
    - 月次上限（3回）チェック
     - reservations.status = 'canceled' / canceled_at = 現在UTC にセット
    - shifts.is_locked = false にセット
    - 受講者・講師へ LINE / メール通知
    """
    now_utc = datetime.now(timezone.utc)

    # --- 対象予約の取得と本人確認 ---
    reservation = get_reservation_by_id(db, reservation_id, user.user_id)
    if not reservation:
        raise HTTPException(status_code=404, detail="予約が見つかりません")

    if reservation["status"] != "reserved":
        raise HTTPException(
            status_code=400, detail="キャンセル可能な予約ではありません"
        )

    # --- 授業開始日時チェック ---
    start_at_utc = reservation["start_at"].astimezone(timezone.utc)
    if now_utc >= start_at_utc:
        raise HTTPException(
            status_code=400,
            detail="授業の開始時刻を過ぎているため、キャンセルできません。",
        )

    # --- 月次キャンセル上限チェック ---
    cancel_count = get_monthly_cancel_count(db, user.user_id, now_utc)
    if cancel_count >= CANCEL_LIMIT:
        raise HTTPException(
            status_code=400,
            detail=(
                f"今月のキャンセル上限（{CANCEL_LIMIT}回）に達しています。"
                "キャンセルをご希望の場合は、運営にお問い合わせください。"
            ),
        )

    # --- キャンセル処理（DB更新）---
    cur = db.cursor()
    cur.execute(
        "UPDATE reservations SET status = 'canceled', canceled_at = %s WHERE id = %s",
        (now_utc, reservation_id),
    )
    cur.execute(
        "UPDATE shifts SET is_locked = false WHERE id = %s",
        (reservation["shift_id"],),
    )
    run_notification_hook(
        db, cancel_reservation_reminders, reservation_id, canceled_at=now_utc
    )
    db.commit()

    # --- 通知用情報取得 ---
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT
            s.start_at,
            s.end_at,
            s.s_type,
            p.display_name  AS provider_name,
            p.line_user_id  AS provider_line,
            p.email         AS provider_email,
            rc.display_name AS receiver_name,
            rc.line_user_id AS receiver_line,
            rc.email        AS receiver_email
        FROM shifts s
        JOIN app_users p  ON p.id  = s.provider_id
        JOIN app_users rc ON rc.id = %s
        WHERE s.id = %s
        """,
        (user.user_id, reservation["shift_id"]),
    )
    info = cur.fetchone()
    logger.debug("[cancel] 通知用情報取得結果: info=%s", info)

    # --- 通知送信（失敗してもキャンセル本体には影響させない）---
    if info:
        logger.info(
            "[cancel] 通知送信開始: receiver_email=%s, provider_email=%s, "
            "receiver_line=%s, provider_line=%s",
            info.get("receiver_email"),
            info.get("provider_email"),
            "設定済み" if info.get("receiver_line") else "未設定",
            "設定済み" if info.get("provider_line") else "未設定",
        )

        start_str, end_str = format_notification_datetime_range(
            info["start_at"], info["end_at"]
        )
        type_str = "オンライン" if info["s_type"] == "online" else "対面"
        official_line_url = os.getenv(
            "OFFICIAL_ACCOUNT_REDIRECT_URI", "https://lin.ee/86J9msY"
        )

        cancel_subject = "【キャンセル通知】友達日本語会話教室からのご連絡"

        # 受講者（生徒）向けLINEメッセージ
        receiver_line_msg = (
            f"{info['provider_name']}との {start_str}～{end_str} の{type_str}授業を"
            "キャンセルしました。"
        )

        # 受講者（生徒）向けメール本文
        receiver_body = f"""
{info["receiver_name"]} 様<br><br>

以下の授業をキャンセルしました：<br><br>

日時：{start_str} ～ {end_str}<br>
形式：{type_str}<br>
講師：{info["provider_name"]}<br><br>

キャンセルに関するご不明点はこちらの公式LINEからお問い合わせください。<br>
<a href="{official_line_url}">{official_line_url}</a><br><br>

LINEで通知済みです。
"""

        # 講師向けLINEメッセージ
        provider_line_msg = (
            f"{info['receiver_name']} が {start_str}～{end_str} の{type_str}授業を"
            "キャンセルしました。"
        )

        # 講師向けメール本文
        provider_body = f"""
{info["provider_name"]} 様<br><br>

{info["receiver_name"]} が以下の授業をキャンセルしました：<br><br>

日時：{start_str} ～ {end_str}<br>
形式：{type_str}<br><br>

お問い合わせはこちらの公式LINEからご連絡ください。<br>
<a href="{official_line_url}">{official_line_url}</a><br><br>

LINEで通知済みです。
"""

        def format_html(text: str) -> str:
            return (
                "<div style=\"font-family: 'Meiryo', 'Hiragino Kaku Gothic ProN', "
                "'Segoe UI', sans-serif; font-size: 14px; line-height: 1.6;\">"
                f"{text}</div>"
            )

        # 受講者（生徒）へのLINE通知
        logger.info(
            "[cancel] 受講者LINE通知送信: line_user_id=%s", info.get("receiver_line")
        )
        try:
            result = await send_line_notification(
                info["receiver_line"], receiver_line_msg
            )
            logger.info("[cancel] 受講者LINE通知結果: %s", result)
        except Exception as e:
            logger.error("[cancel] 受講者LINE送信エラー: %s", e, exc_info=True)

        # 受講者（生徒）へのメール通知
        logger.info(
            "[cancel] 受講者メール通知送信: email=%s", info.get("receiver_email")
        )
        try:
            result = await send_mailjet_email(
                info["receiver_email"],
                cancel_subject,
                receiver_body,
                html_body=format_html(receiver_body),
            )
            logger.info("[cancel] 受講者メール通知結果: %s", result)
        except Exception as e:
            logger.error("[cancel] 受講者メール送信エラー: %s", e, exc_info=True)

        # 講師へのLINE通知
        logger.info(
            "[cancel] 講師LINE通知送信: line_user_id=%s", info.get("provider_line")
        )
        try:
            result = await send_line_notification(
                info["provider_line"], provider_line_msg
            )
            logger.info("[cancel] 講師LINE通知結果: %s", result)
        except Exception as e:
            logger.error("[cancel] 講師LINE送信エラー: %s", e, exc_info=True)

        # 講師へのメール通知
        logger.info("[cancel] 講師メール通知送信: email=%s", info.get("provider_email"))
        try:
            result = await send_mailjet_email(
                info["provider_email"],
                cancel_subject,
                provider_body,
                html_body=format_html(provider_body),
            )
            logger.info("[cancel] 講師メール通知結果: %s", result)
        except Exception as e:
            logger.error("[cancel] 講師メール送信エラー: %s", e, exc_info=True)
    else:
        logger.warning(
            "[cancel] 通知用情報が取得できませんでした（info is None）: shift_id=%s, user_id=%s",
            reservation["shift_id"],
            user.user_id,
        )

    return {"message": "予約をキャンセルしました"}


@router.get(
    "/api/receiver/cancel-count",
    dependencies=[Depends(require_role("receiver", "admin"))],
)
async def get_cancel_count(
    month: Optional[str] = Query(
        None, description="対象月 YYYY-MM 形式（省略時は当月）"
    ),
    user=Depends(get_current_user),
    db=Depends(get_db),
):
    """
    当月（または指定月）のキャンセル回数を返す。

    レスポンス: { "count": N, "limit": 3 }
    """
    now_utc = datetime.now(timezone.utc)

    if month:
        try:
            target_month = datetime.strptime(month, "%Y-%m").replace(
                tzinfo=timezone.utc
            )
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail="month パラメータは YYYY-MM 形式で指定してください。",
            )
    else:
        target_month = now_utc

    count = get_monthly_cancel_count(db, user.user_id, target_month)
    return {"count": count, "limit": CANCEL_LIMIT}
