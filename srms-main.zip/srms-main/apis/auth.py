from datetime import datetime, timedelta, timezone
from jose import jwt
from pydantic import BaseModel
import bcrypt
import os

JWT_SECRET = os.getenv("JWT_SECRET", "change-me")
JWT_ALG = "HS256"
ACCESS_TTL_MIN = int(os.getenv("ACCESS_TTL_MIN", "120"))

class TokenData(BaseModel):
    user_id: str
    role: str
    email: str
    line_user_id: str | None = None

def hash_password(p: str) -> str:
    # bcrypt returns bytes; decode to UTF-8 string for storage
    return bcrypt.hashpw(p.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def verify_password(p: str, hashed: str) -> bool:
    # both inputs must be bytes
    return bcrypt.checkpw(p.encode("utf-8"), hashed.encode("utf-8"))

def create_access_token(user_id: str, role: str, email: str, line_user_id: str | None = None) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "user_id": user_id,
        "role": role,
        "email": email,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ACCESS_TTL_MIN)).timestamp()),
        "line_user_id": line_user_id
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

def parse_token(token: str) -> TokenData:
    data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    return TokenData(user_id=data["user_id"], role=data["role"], email=data["email"],line_user_id=data.get("line_user_id"))