from fastapi import Header, HTTPException, Depends
from .auth import parse_token, TokenData
import os, psycopg2

def get_db():
    conn = psycopg2.connect(os.getenv("DATABASE_URL"))
    try:
        yield conn
    finally:
        conn.close()

def get_current_user(authorization: str = Header(...)) -> TokenData:
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Invalid auth header")
    token = authorization.split(" ", 1)[1]
    try:
        return parse_token(token)
    except Exception:
        raise HTTPException(401, "Invalid token")

def require_role(*roles):
    def inner(user: TokenData = Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(403, "Forbidden")
        return user
    return inner
