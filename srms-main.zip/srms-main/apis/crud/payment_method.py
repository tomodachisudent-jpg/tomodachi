"""
振込方法に関するデータベース操作を提供するリポジトリ層
"""
import psycopg2.extras


def get_payment_method(db, provider_id: str):
    """
    先生の振込方法設定を取得

    Args:
        db: データベース接続
        provider_id: 先生のユーザーID

    Returns:
        dict | None: 振込方法情報
            - payment_method: 振込方法（hand/bank/paypay）
            - bank_name: 銀行名
            - bank_branch: 支店名
            - bank_account_type: 口座種別
            - bank_account_number: 口座番号
            - bank_account_holder: 口座名義
            - paypay_id: PayPay ID
            - paypay_phone_number: PayPayに紐づく電話番号
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT payment_method, bank_name, bank_branch,
               bank_account_type, bank_account_number, bank_account_holder,
               paypay_id, paypay_phone_number
        FROM providers
        WHERE user_id = %s
        """,
        (provider_id,),
    )
    return cur.fetchone()


def update_payment_method(
    db,
    provider_id: str,
    payment_method: str,
    bank_name,
    bank_branch,
    bank_account_type,
    bank_account_number,
    bank_account_holder,
    paypay_id,
    paypay_phone_number,
):
    """
    先生の振込方法設定を更新

    Args:
        db: データベース接続
        provider_id: 先生のユーザーID
        payment_method: 振込方法（hand/bank/paypay）
        bank_name: 銀行名（bankの場合のみ）
        bank_branch: 支店名（bankの場合のみ）
        bank_account_type: 口座種別（bankの場合のみ）
        bank_account_number: 口座番号（bankの場合のみ）
        bank_account_holder: 口座名義（bankの場合のみ）
        paypay_id: PayPay ID（paypayの場合のみ）
        paypay_phone_number: PayPayに紐づく電話番号（paypayの場合のみ）
    """
    cur = db.cursor()
    cur.execute(
        """
        UPDATE providers
        SET payment_method = %s,
            bank_name = %s,
            bank_branch = %s,
            bank_account_type = %s,
            bank_account_number = %s,
            bank_account_holder = %s,
            paypay_id = %s,
            paypay_phone_number = %s
        WHERE user_id = %s
        """,
        (
            payment_method,
            bank_name,
            bank_branch,
            bank_account_type,
            bank_account_number,
            bank_account_holder,
            paypay_id,
            paypay_phone_number,
            provider_id,
        ),
    )
    db.commit()
