"""
給与計算に関するデータベース操作を提供するリポジトリ層
"""
import psycopg2.extras
from uuid import UUID


def get_provider_hourly_rates(db, provider_id: UUID):
    """
    先生の時給情報を取得

    Args:
        db: データベース接続
        provider_id: 先生ID

    Returns:
        dict: 時給情報・振込方法情報
            - hourly_rate_offline: 対面授業時給
            - hourly_rate_online: オンライン授業時給
            - display_name: 先生の表示名
            - payment_method: 振込方法（hand/bank/paypay）
            - bank_name: 銀行名
            - bank_branch: 支店名
            - bank_account_type: 口座種別
            - bank_account_number: 口座番号
            - bank_account_holder: 口座名義
            - paypay_id: PayPay ID
            - paypay_phone_number: PayPayに紐づく電話番号

    Raises:
        ValueError: 先生が見つからない場合
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT
            p.hourly_rate_offline,
            p.hourly_rate_online,
            u.display_name,
            p.payment_method,
            p.bank_name,
            p.bank_branch,
            p.bank_account_type,
            p.bank_account_number,
            p.bank_account_holder,
            p.paypay_id,
            p.paypay_phone_number
        FROM providers p
        JOIN app_users u ON u.id = p.user_id
        WHERE p.user_id = %s
    """, (str(provider_id),))

    provider = cur.fetchone()
    if not provider:
        raise ValueError(f"Provider not found: {provider_id}")

    return provider


def get_monthly_service_logs(db, provider_id: UUID, year: int, month: int):
    """
    対象月のサービス実施記録を取得

    Args:
        db: データベース接続
        provider_id: 先生ID
        year: 対象年
        month: 対象月

    Returns:
        list[dict]: サービス実施記録のリスト
            - start_at: 開始日時
            - end_at: 終了日時
            - s_type: 授業形態（offline/online）
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT
            start_at,
            end_at,
            s_type
        FROM service_logs
        WHERE provider_id = %s
            AND EXTRACT(year FROM start_at) = %s
            AND EXTRACT(month FROM start_at) = %s
        ORDER BY start_at
    """, (str(provider_id), year, month))

    return cur.fetchall()


def get_active_providers(db):
    """
    アクティブな全先生のIDを取得

    Args:
        db: データベース接続

    Returns:
        list[dict]: 先生情報のリスト
            - user_id: 先生のユーザーID
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT p.user_id
        FROM providers p
        JOIN app_users u ON u.id = p.user_id
        WHERE u.role = 'provider' AND u.is_active = true
        ORDER BY u.display_name
    """)

    return cur.fetchall()
