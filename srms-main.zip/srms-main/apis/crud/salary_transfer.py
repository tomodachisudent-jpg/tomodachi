"""
給与振込済み記録に関するデータベース操作を提供するリポジトリ層
"""
import psycopg2.extras


def check_provider_exists(db, provider_id: str) -> bool:
    """
    先生の存在確認

    Args:
        db: データベース接続
        provider_id: 先生のユーザーID

    Returns:
        bool: 先生が存在する場合True
    """
    cur = db.cursor()
    cur.execute(
        "SELECT 1 FROM providers WHERE user_id = %s",
        (provider_id,),
    )
    return cur.fetchone() is not None


def get_salary_transfer(db, provider_id: str, year: int, month: int):
    """
    指定された先生・年月の振込済み記録を取得

    Args:
        db: データベース接続
        provider_id: 先生のユーザーID
        year: 対象年
        month: 対象月

    Returns:
        dict | None: 振込済み記録
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT id, provider_id, year, month, created_at, created_by
        FROM salary_transfers
        WHERE provider_id = %s AND year = %s AND month = %s
        """,
        (provider_id, year, month),
    )
    return cur.fetchone()


def get_salary_transfers_by_month(db, year: int, month: int) -> list:
    """
    指定年月の全振込済み記録を取得

    Args:
        db: データベース接続
        year: 対象年
        month: 対象月

    Returns:
        list[dict]: 振込済み記録のリスト
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT provider_id
        FROM salary_transfers
        WHERE year = %s AND month = %s
        """,
        (year, month),
    )
    return cur.fetchall()


def insert_salary_transfer(db, provider_id: str, year: int, month: int, created_by: str):
    """
    振込済み記録を登録

    Args:
        db: データベース接続
        provider_id: 先生のユーザーID
        year: 対象年
        month: 対象月
        created_by: 登録した管理者のユーザーID
    """
    cur = db.cursor()
    cur.execute(
        """
        INSERT INTO salary_transfers (provider_id, year, month, created_by)
        VALUES (%s, %s, %s, %s)
        """,
        (provider_id, year, month, created_by),
    )
    db.commit()
