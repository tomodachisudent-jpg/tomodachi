import psycopg2.extras
from datetime import datetime


def get_reservations_by_receiver(db, receiver_id: int):
    """ログイン中の生徒の予約一覧を取得する"""
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT
            r.id,
            s.start_at,
            s.end_at,
            s.s_type,
            r.status,
            p.display_name AS provider_name
        FROM reservations r
        JOIN shifts s ON s.id = r.shift_id
        JOIN app_users p ON p.id = s.provider_id
        WHERE r.receiver_id = %s
        ORDER BY s.start_at ASC
    """,
        (receiver_id,),
    )
    return cur.fetchall()


def get_monthly_cancel_count(db, receiver_id: str, month: datetime) -> int:
    """指定月の生徒のキャンセル回数を取得する

    canceled_at の暦月（JST）でカウントする。

    Args:
        db: データベース接続
        receiver_id: 生徒のUUID
        month: カウント対象の月（任意の日時。その月の1日〜末日を計算）

    Returns:
        指定月のキャンセル回数
    """
    cur = db.cursor()
    # 暦月の範囲をUTCで計算（JSTとの差異を吸収するためタイムゾーン付きで比較）
    month_start = month.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if month.month == 12:
        month_end = month_start.replace(year=month.year + 1, month=1)
    else:
        month_end = month_start.replace(month=month.month + 1)

    cur.execute(
        """
        SELECT COUNT(*)
        FROM reservations
        WHERE receiver_id = %s
          AND canceled_at IS NOT NULL
          AND canceled_at >= %s
          AND canceled_at < %s
    """,
        (receiver_id, month_start, month_end),
    )
    row = cur.fetchone()
    return row[0] if row else 0


def get_reservation_by_id(db, reservation_id: int, receiver_id: str):
    """reservation_id と receiver_id でキャンセル対象の予約を取得する

    Args:
        db: データベース接続
        reservation_id: 予約ID
        receiver_id: 生徒のUUID（本人確認用）

    Returns:
        予約情報のdict（見つからない場合はNone）
    """
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT
            r.id,
            r.shift_id,
            r.receiver_id,
            r.status,
            r.canceled_at,
            s.start_at,
            s.end_at,
            s.s_type,
            s.provider_id
        FROM reservations r
        JOIN shifts s ON s.id = r.shift_id
        WHERE r.id = %s
          AND r.receiver_id = %s
    """,
        (reservation_id, receiver_id),
    )
    return cur.fetchone()
