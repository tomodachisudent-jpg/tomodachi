from pydantic import BaseModel, EmailStr, validator, root_validator
from datetime import datetime
from enum import Enum
from typing import Optional


class UserBase(BaseModel):
    email: str
    name: str


class UserCreate(UserBase):
    role: str


class User(UserBase):
    id: int
    role: str

    class Config:
        orm_mode = True


class ShiftBase(BaseModel):
    start_time: datetime
    end_time: datetime
    is_online: bool = False


class Shift(ShiftBase):
    id: int
    provider_id: int

    class Config:
        orm_mode = True


class ReservationBase(BaseModel):
    shift_id: int


class Reservation(ReservationBase):
    id: int
    customer_id: int
    status: str

    class Config:
        orm_mode = True


class MailRequest(BaseModel):
    to: EmailStr
    subject: str
    body: str


class ProviderProfile(BaseModel):
    name: Optional[str]
    job: Optional[str]
    hobbies: Optional[str]
    likes: Optional[str]
    lang_ja: Optional[bool]
    lang_en: Optional[bool]
    lang_other: Optional[bool]
    in_person: Optional[bool]
    online: Optional[bool]
    message: Optional[str]
    skills: Optional[str]
    experience: Optional[str]
    lesson_style: Optional[str]
    photo_url: Optional[str]


class ReceiverProfile(BaseModel):
    name: str
    age: Optional[int] = None
    gender: Optional[str] = None
    nationality: Optional[str] = None
    self_introduction: Optional[str] = None
    learning_goals: Optional[str] = None
    profile_photo_url: Optional[str] = None
    learning_history: Optional[str] = None
    qualifications: Optional[str] = None
    special_skills: Optional[str] = None
    japanese_level: Optional[str] = None

    @validator("name")
    def validate_name(cls, value):
        if value is None or value.strip() == "":
            raise ValueError("名前 or ニックネームを入力してください")
        return value

    @validator("age", pre=True)
    def validate_age(cls, value):
        if value is None or value == "":
            return None
        try:
            numeric = int(value)
        except (TypeError, ValueError):
            raise ValueError("年齢は数値で入力してください")
        if numeric <= 0:
            raise ValueError("正の数値を入力してください")
        return numeric

    @validator("profile_photo_url")
    def validate_profile_photo_url(cls, value):
        # 既存データとの互換性のため、None は許可するが空文字はエラー
        if value is not None and value.strip() == "":
            raise ValueError("顔写真をアップロードしてください")
        return value


class PaymentMethodType(str, Enum):
    """振込方法の種別"""
    hand = "hand"       # 手渡し
    bank = "bank"       # 銀行振込
    paypay = "paypay"   # PayPay


class PaymentMethod(BaseModel):
    """振込方法設定（GET/POSTで共用）"""
    payment_method: PaymentMethodType = PaymentMethodType.hand
    # 銀行振込時の口座情報
    bank_name: Optional[str] = None
    bank_branch: Optional[str] = None
    bank_account_type: Optional[str] = None       # 普通 / 当座
    bank_account_number: Optional[str] = None
    bank_account_holder: Optional[str] = None
    # PayPay受取情報
    paypay_id: Optional[str] = None
    paypay_phone_number: Optional[str] = None

    @validator("paypay_id")
    def validate_paypay_id(cls, value):
        if value is None:
            return None
        normalized = value.strip()
        if normalized == "":
            raise ValueError("PayPay IDは空文字にできません")
        import re
        if not re.fullmatch(r'[a-zA-Z0-9_]{3,15}', normalized):
            raise ValueError("PayPay IDは半角英数字とアンダーバーで3〜15文字で入力してください")
        return normalized

    @validator("paypay_phone_number")
    def validate_paypay_phone_number(cls, value):
        if value is None:
            return None

        normalized = value.replace("-", "").replace(" ", "").replace("　", "")
        if normalized == "":
            return None
        if not normalized.isdigit() or len(normalized) not in (10, 11):
            raise ValueError("電話番号は10桁または11桁の数字で入力してください")
        return normalized

    @root_validator(skip_on_failure=True)
    def validate_paypay_required_fields(cls, values):
        if values.get("payment_method") == PaymentMethodType.paypay:
            if not values.get("paypay_id") and not values.get("paypay_phone_number"):
                raise ValueError("PayPay IDまたは電話番号のいずれかを入力してください")
        return values
