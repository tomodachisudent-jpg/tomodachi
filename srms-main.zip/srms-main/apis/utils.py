"""
共通ユーティリティ関数
"""

import os

from supabase import create_client


def is_local_environment() -> bool:
    """
    ローカル開発環境かどうかを判定（SUPABASE_URLに基づく）

    Returns:
        bool: ローカル環境ならTrue、本番環境ならFalse
    """
    supabase_url = os.getenv("SUPABASE_URL", "")
    return any(x in supabase_url for x in ["localhost", "172.17.0.1", "127.0.0.1"])


def get_storage_url(bucket_name: str, file_name: str) -> str:
    """
    環境に応じたStorage URLを生成

    ローカル環境では相対パスを返し（quasar.config.jsのプロキシ経由でアクセス）、
    本番環境では絶対URLを返す（ブラウザから直接アクセス可能）

    Args:
        bucket_name: Supabase Storageのバケット名（例: "profile-photos"）
        file_name: アップロードされたファイル名

    Returns:
        str: 環境に応じた画像URL
        - ローカル: /storage/v1/object/public/{bucket}/{file}
        - 本番: https://xxx.supabase.co/storage/v1/object/public/{bucket}/{file}
    """
    if is_local_environment():
        # ローカル: 相対パス（開発サーバーのプロキシ経由でアクセス）
        return f"/storage/v1/object/public/{bucket_name}/{file_name}"
    else:
        # 本番: 絶対URL（ブラウザから直接アクセス可能）
        supabase_url = os.getenv("SUPABASE_URL", "").rstrip("/")
        return f"{supabase_url}/storage/v1/object/public/{bucket_name}/{file_name}"


def create_supabase_client_from_env():
    """
    環境変数が揃っている場合のみ Supabase クライアントを生成

    Returns:
        Client | None: 必須環境変数が未設定なら None
    """
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

    if not supabase_url or not supabase_key:
        return None

    return create_client(supabase_url, supabase_key)
