from __future__ import annotations

import asyncio
import json
from importlib import import_module
import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable

from .notification_delivery import (
    NotificationDeliveryError,
    NotificationSendResult,
    send_reminder_notification,
)

logger = logging.getLogger(__name__)

DEFAULT_BATCH_SIZE = int(os.getenv("NOTIFICATION_WORKER_BATCH_SIZE", "20"))
MAX_RETRY_ATTEMPTS = int(os.getenv("NOTIFICATION_MAX_RETRY_ATTEMPTS", "3"))
WORKER_POLL_SECONDS = int(os.getenv("NOTIFICATION_WORKER_POLL_SECONDS", "30"))
_retry_schedule = os.getenv("NOTIFICATION_RETRY_DELAYS_MINUTES", "5,30,120")
RETRY_DELAYS = tuple(
    int(value.strip()) for value in _retry_schedule.split(",") if value.strip()
)
PROVIDER_DUPLICATE_GUARD_STATUSES = ("processing", "sent", "skipped")
PROVIDER_DUPLICATE_SKIP_REASON = "Skipped duplicate provider reminder for same shift"

NotificationSender = Callable[[dict[str, Any]], Awaitable[NotificationSendResult]]
ConnectionFactory = Callable[[], Any]


def _utc_now(now: datetime | None = None) -> datetime:
    base = now or datetime.now(timezone.utc)
    if base.tzinfo is None:
        return base.replace(tzinfo=timezone.utc)
    return base.astimezone(timezone.utc)


def _next_attempt_count(delivery: dict[str, Any]) -> int:
    return int(delivery.get("attempt_count") or 0) + 1


def _retry_at(attempt_count: int, now: datetime) -> datetime:
    index = min(max(attempt_count - 1, 0), max(len(RETRY_DELAYS) - 1, 0))
    delay_minutes = RETRY_DELAYS[index] if RETRY_DELAYS else 5
    return now + timedelta(minutes=delay_minutes)


def _normalize_snapshot(snapshot: Any) -> dict[str, Any]:
    if snapshot is None:
        return {}
    if isinstance(snapshot, dict):
        return snapshot
    if isinstance(snapshot, str):
        try:
            loaded = json.loads(snapshot)
        except json.JSONDecodeError:
            return {}
        return loaded if isinstance(loaded, dict) else {}
    return {}


def _provider_duplicate_guard_key(delivery: dict[str, Any]) -> tuple[str, ...] | None:
    if delivery.get("recipient_role") != "provider":
        return None

    snapshot = _normalize_snapshot(delivery.get("reservation_snapshot"))
    shift_id = snapshot.get("shift_id")
    if shift_id in (None, ""):
        return None

    scheduled_for = delivery.get("scheduled_for")
    if isinstance(scheduled_for, datetime):
        scheduled_for_value = _utc_now(scheduled_for).isoformat()
    else:
        scheduled_for_value = str(scheduled_for)

    return (
        str(shift_id),
        str(delivery.get("channel") or ""),
        str(delivery.get("stage") or ""),
        scheduled_for_value,
        str(delivery.get("notification_type") or ""),
    )


def _mark_delivery_skipped(
    db: Any,
    delivery: dict[str, Any],
    *,
    reason: str = PROVIDER_DUPLICATE_SKIP_REASON,
) -> dict[str, Any]:
    _update_delivery_status(
        db,
        delivery_id=delivery["id"],
        status="skipped",
        attempt_count=int(delivery.get("attempt_count") or 0),
        last_error=reason,
    )
    return {
        "delivery_id": delivery["id"],
        "status": "skipped",
        "reason": reason,
    }


def _split_batch_provider_duplicates(
    db: Any,
    deliveries: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    seen_keys: set[tuple[str, ...]] = set()
    filtered_deliveries: list[dict[str, Any]] = []
    skipped_results: list[dict[str, Any]] = []

    for delivery in deliveries:
        guard_key = _provider_duplicate_guard_key(delivery)
        if guard_key is None:
            filtered_deliveries.append(delivery)
            continue

        if guard_key in seen_keys:
            skipped_results.append(_mark_delivery_skipped(db, delivery))
            continue

        seen_keys.add(guard_key)
        filtered_deliveries.append(delivery)

    return filtered_deliveries, skipped_results


def _has_prior_provider_guard(db: Any, delivery: dict[str, Any]) -> bool:
    guard_key = _provider_duplicate_guard_key(delivery)
    if guard_key is None:
        return False

    shift_id, channel, stage, _scheduled_for, notification_type = guard_key
    cursor = db.cursor()
    cursor.execute(
        """
        SELECT 1
        FROM notification_deliveries AS deliveries
        JOIN notification_jobs AS jobs
          ON jobs.id = deliveries.job_id
        WHERE deliveries.id < %s
          AND deliveries.status = ANY(%s)
          AND deliveries.channel = %s
          AND deliveries.stage = %s
          AND deliveries.scheduled_for = %s
          AND jobs.recipient_role = 'provider'
          AND jobs.notification_type = %s
          AND COALESCE(jobs.reservation_snapshot->>'shift_id', '') = %s
        LIMIT 1
        """,
        (
            delivery["id"],
            list(PROVIDER_DUPLICATE_GUARD_STATUSES),
            channel,
            stage,
            delivery.get("scheduled_for"),
            notification_type,
            shift_id,
        ),
    )
    return cursor.fetchone() is not None


def claim_due_notification_deliveries(
    db: Any,
    *,
    limit: int = DEFAULT_BATCH_SIZE,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    current_time = _utc_now(now)
    real_dict_cursor = getattr(
        import_module("psycopg2.extras"),
        "RealDictCursor",
    )
    cursor = db.cursor(cursor_factory=real_dict_cursor)

    try:
        cursor.execute(
            """
            WITH due AS (
                SELECT nd.id
                FROM notification_deliveries nd
                JOIN notification_jobs nj ON nj.id = nd.job_id
                WHERE nd.status = 'pending'
                  AND nj.is_active = TRUE
                  AND nd.scheduled_for <= %s
                  AND (nd.next_retry_at IS NULL OR nd.next_retry_at <= %s)
                ORDER BY nd.scheduled_for, nd.id
                FOR UPDATE SKIP LOCKED
                LIMIT %s
            )
            UPDATE notification_deliveries nd
            SET status = 'processing'
            FROM due, notification_jobs nj
            WHERE nd.id = due.id
              AND nj.id = nd.job_id
            RETURNING
                nd.id,
                nd.job_id,
                nd.channel,
                nd.stage,
                nd.scheduled_for,
                nd.status,
                nd.attempt_count,
                nd.next_retry_at,
                nd.last_error,
                nd.dedupe_key,
                nj.reservation_id,
                nj.recipient_role,
                nj.notification_type,
                nj.reservation_snapshot
            """,
            (current_time, current_time, limit),
        )
        rows = list(cursor.fetchall())
        db.commit()
        return rows
    except Exception:
        db.rollback()
        raise


def _update_delivery_status(
    db: Any,
    *,
    delivery_id: Any,
    status: str,
    attempt_count: int,
    last_error: str | None = None,
    next_retry_at: datetime | None = None,
) -> None:
    cursor = db.cursor()
    try:
        cursor.execute(
            """
            UPDATE notification_deliveries
            SET status = %s,
                attempt_count = %s,
                last_error = %s,
                next_retry_at = %s
            WHERE id = %s
            """,
            (status, attempt_count, last_error, next_retry_at, delivery_id),
        )
        db.commit()
    except Exception:
        db.rollback()
        raise


async def process_notification_delivery(
    db: Any,
    delivery: dict[str, Any],
    *,
    sender: NotificationSender = send_reminder_notification,
    now: datetime | None = None,
) -> dict[str, Any]:
    current_time = _utc_now(now)
    attempt_count = _next_attempt_count(delivery)

    if _has_prior_provider_guard(db, delivery):
        return _mark_delivery_skipped(db, delivery)

    try:
        result = await sender(delivery)
        if result.status == "sent":
            _update_delivery_status(
                db,
                delivery_id=delivery["id"],
                status="sent",
                attempt_count=attempt_count,
            )
            return {"delivery_id": delivery["id"], "status": "sent"}

        if result.status == "skipped":
            _update_delivery_status(
                db,
                delivery_id=delivery["id"],
                status="skipped",
                attempt_count=attempt_count,
                last_error=result.message,
            )
            return {
                "delivery_id": delivery["id"],
                "status": "skipped",
                "reason": result.message,
            }

        raise NotificationDeliveryError(result.message)
    except Exception as exc:
        error_message = str(exc)
        if attempt_count >= MAX_RETRY_ATTEMPTS:
            _update_delivery_status(
                db,
                delivery_id=delivery["id"],
                status="failed",
                attempt_count=attempt_count,
                last_error=error_message,
            )
            return {
                "delivery_id": delivery["id"],
                "status": "failed",
                "reason": error_message,
            }

        retry_at = _retry_at(attempt_count, current_time)
        _update_delivery_status(
            db,
            delivery_id=delivery["id"],
            status="pending",
            attempt_count=attempt_count,
            last_error=error_message,
            next_retry_at=retry_at,
        )
        return {
            "delivery_id": delivery["id"],
            "status": "pending",
            "reason": error_message,
            "next_retry_at": retry_at,
        }


async def process_due_notification_deliveries(
    db: Any,
    *,
    limit: int = DEFAULT_BATCH_SIZE,
    sender: NotificationSender = send_reminder_notification,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    deliveries = claim_due_notification_deliveries(db, limit=limit, now=now)
    deliveries, results = _split_batch_provider_duplicates(db, deliveries)
    for delivery in deliveries:
        results.append(
            await process_notification_delivery(db, delivery, sender=sender, now=now)
        )
    return results


async def run_notification_worker_loop(
    connection_factory: ConnectionFactory,
    *,
    batch_size: int = DEFAULT_BATCH_SIZE,
    poll_seconds: int = WORKER_POLL_SECONDS,
    sender: NotificationSender = send_reminder_notification,
    stop_event: asyncio.Event | None = None,
    sleep_func: Callable[[float], Awaitable[None]] = asyncio.sleep,
) -> None:
    while True:
        if stop_event and stop_event.is_set():
            logger.info("notification worker stop requested before iteration")
            return

        db = connection_factory()
        try:
            results = await process_due_notification_deliveries(
                db,
                limit=batch_size,
                sender=sender,
            )
            if results:
                logger.info("notification worker processed %s deliveries", len(results))
        finally:
            if hasattr(db, "close"):
                db.close()

        if stop_event and stop_event.is_set():
            logger.info("notification worker stop requested after iteration")
            return

        await sleep_func(poll_seconds)
