import os, httpx

DEFAULT_WEBHOOK = os.getenv("SLACK_DEFAULT_WEBHOOK")

def _send(webhook: str, text: str):
    wh = webhook or DEFAULT_WEBHOOK
    if not wh:
        return
    try:
        httpx.post(wh, json={"text": text}, timeout=5)
    except Exception:
        pass

def notify(db, reservation_id: int, event: str):
    cur = db.cursor()
    cur.execute("""
      select r.id, r.status, s.id as shift_id, s.s_type, s.start_at, s.end_at,
             p.user_id as provider_id, ap.display_name as provider_name, ap.slack_webhook as provider_wh,
             r.receiver_id, ar.display_name as receiver_name, ar.slack_webhook as receiver_wh
      from reservations r
      join shifts s on s.id=r.shift_id
      join providers p on p.user_id=s.provider_id
      join app_users ap on ap.id=p.user_id
      join app_users ar on ar.id=r.receiver_id
      where r.id=%s
    """, (reservation_id,))
    row = cur.fetchone()
    if not row:
        return

    (rid, status, sid, s_type, st, et, provider_id, provider_name, p_wh, receiver_id, receiver_name, r_wh) = row

    msg = {
      "created": f"新規予約: #{rid} {s_type} {st} - {et} / 提供者:{provider_name} / 受給者:{receiver_name}",
      "canceled": f"予約キャンセル: #{rid} / 提供者:{provider_name} / 受給者:{receiver_name}",
      "updated":  f"予約更新: #{rid} / 提供者:{provider_name} / 受給者:{receiver_name}",
    }.get(event, f"予約通知: #{rid}")

    _send(p_wh, msg)
    _send(r_wh, msg)
