from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import json
from typing import Any, Mapping

NOTIFICATION_TYPE = "reservation_reminder"
CHANNELS = ("line", "mail")
PENDING_DELIVERY_STATUSES = ("pending", "processing")


@dataclass(frozen=True)
class ReminderStage:
    name: str
    offset: timedelta

    @property
    def offset_minutes(self) -> int:
        return int(self.offset.total_seconds() // 60)


REMINDER_STAGES = (
    ReminderStage("3_days", timedelta(days=3)),
    ReminderStage("1_day", timedelta(days=1)),
    ReminderStage("6_hours", timedelta(hours=6)),
    ReminderStage("2_hours", timedelta(hours=2)),
    ReminderStage("30_minutes", timedelta(minutes=30)),
    ReminderStage("5_minutes", timedelta(minutes=5)),
    ReminderStage("1_minute", timedelta(minutes=1)),
)


def _ensure_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _isoformat_or_none(value: datetime | None) -> str | None:
    if value is None:
        return None
    return _ensure_utc(value).isoformat()


def build_reservation_notification_snapshot(
    reservation_row: Mapping[str, Any],
) -> dict[str, Any]:
    required_keys = (
        "reservation_id",
        "shift_id",
        "start_at",
        "end_at",
        "service_type",
        "provider_id",
        "provider_name",
        "receiver_id",
        "receiver_name",
    )
    missing_keys = [key for key in required_keys if reservation_row.get(key) is None]
    if missing_keys:
        raise ValueError(
            f"Missing reservation snapshot fields: {', '.join(missing_keys)}"
        )

    return {
        "reservation_id": int(reservation_row["reservation_id"]),
        "shift_id": int(reservation_row["shift_id"]),
        "status": reservation_row.get("status", "reserved"),
        "service_type": reservation_row["service_type"],
        "start_at": _isoformat_or_none(reservation_row["start_at"]),
        "end_at": _isoformat_or_none(reservation_row["end_at"]),
        "provider": {
            "user_id": str(reservation_row["provider_id"]),
            "display_name": reservation_row["provider_name"],
            "email": reservation_row.get("provider_email"),
            "line_user_id": reservation_row.get("provider_line_user_id"),
        },
        "receiver": {
            "user_id": str(reservation_row["receiver_id"]),
            "display_name": reservation_row["receiver_name"],
            "email": reservation_row.get("receiver_email"),
            "line_user_id": reservation_row.get("receiver_line_user_id"),
        },
    }


def list_planned_reminder_deliveries(
    reservation_snapshot: Mapping[str, Any],
    planned_at: datetime | None = None,
) -> list[dict[str, Any]]:
    reference_time = _ensure_utc(planned_at or datetime.now(timezone.utc))
    start_at = _ensure_utc(
        datetime.fromisoformat(str(reservation_snapshot["start_at"]))
    )
    reservation_id = int(reservation_snapshot["reservation_id"])

    deliveries: list[dict[str, Any]] = []
    for recipient_role in ("provider", "receiver"):
        for stage in REMINDER_STAGES:
            scheduled_for = start_at - stage.offset
            if scheduled_for < reference_time:
                continue

            for channel in CHANNELS:
                deliveries.append(
                    {
                        "recipient_role": recipient_role,
                        "channel": channel,
                        "stage": stage.name,
                        "reminder_offset_minutes": stage.offset_minutes,
                        "scheduled_for": scheduled_for,
                        "dedupe_key": (
                            f"{NOTIFICATION_TYPE}:{reservation_id}:{recipient_role}:"
                            f"{channel}:{stage.name}:{scheduled_for.isoformat()}"
                        ),
                    }
                )

    return deliveries


def plan_reservation_reminders(
    db,
    reservation_snapshot: Mapping[str, Any],
    planned_at: datetime | None = None,
) -> dict[str, int]:
    deliveries = list_planned_reminder_deliveries(reservation_snapshot, planned_at)
    deliveries_by_recipient: dict[str, list[dict[str, Any]]] = {
        "provider": [],
        "receiver": [],
    }
    for delivery in deliveries:
        deliveries_by_recipient[delivery["recipient_role"]].append(delivery)

    cur = db.cursor()
    inserted_jobs = 0
    inserted_deliveries = 0
    now_utc = _ensure_utc(planned_at or datetime.now(timezone.utc))

    for recipient_role, recipient_deliveries in deliveries_by_recipient.items():
        if not recipient_deliveries:
            continue

        cur.execute(
            """
            INSERT INTO notification_jobs (
                reservation_id,
                recipient_role,
                notification_type,
                reservation_snapshot,
                is_active,
                created_at,
                updated_at
            )
            VALUES (%s, %s, %s, %s, TRUE, %s, %s)
            RETURNING id
            """,
            (
                reservation_snapshot["reservation_id"],
                recipient_role,
                NOTIFICATION_TYPE,
                json.dumps(dict(reservation_snapshot)),
                now_utc,
                now_utc,
            ),
        )
        job_id = cur.fetchone()[0]
        inserted_jobs += 1

        for delivery in recipient_deliveries:
            cur.execute(
                """
                INSERT INTO notification_deliveries (
                    job_id,
                    channel,
                    stage,
                    reminder_offset_minutes,
                    scheduled_for,
                    status,
                    attempt_count,
                    next_retry_at,
                    last_error,
                    dedupe_key,
                    sent_at,
                    processed_at,
                    created_at,
                    updated_at
                )
                VALUES (%s, %s, %s, %s, %s, 'pending', 0, NULL, NULL, %s, NULL, NULL, %s, %s)
                ON CONFLICT (dedupe_key) DO NOTHING
                """,
                (
                    job_id,
                    delivery["channel"],
                    delivery["stage"],
                    delivery["reminder_offset_minutes"],
                    delivery["scheduled_for"],
                    delivery["dedupe_key"],
                    now_utc,
                    now_utc,
                ),
            )
            inserted_deliveries += cur.rowcount

    return {"jobs": inserted_jobs, "deliveries": inserted_deliveries}


def _stop_pending_reminders(
    db,
    reservation_id: int,
    stop_status: str,
    stopped_at: datetime | None = None,
) -> dict[str, int]:
    if stop_status not in {"canceled", "skipped"}:
        raise ValueError("stop_status must be canceled or skipped")

    stop_time = _ensure_utc(stopped_at or datetime.now(timezone.utc))
    cur = db.cursor()
    cur.execute(
        """
        UPDATE notification_deliveries AS deliveries
        SET
            status = %s,
            processed_at = COALESCE(deliveries.processed_at, %s),
            updated_at = %s
        FROM notification_jobs AS jobs
                WHERE jobs.id = deliveries.job_id
          AND jobs.reservation_id = %s
          AND deliveries.status = ANY(%s)
        """,
        (
            stop_status,
            stop_time,
            stop_time,
            reservation_id,
            list(PENDING_DELIVERY_STATUSES),
        ),
    )
    updated_deliveries = cur.rowcount

    cur.execute(
        """
        UPDATE notification_jobs
        SET is_active = FALSE, updated_at = %s
        WHERE reservation_id = %s AND is_active = TRUE
        """,
        (stop_time, reservation_id),
    )
    updated_jobs = cur.rowcount

    return {"jobs": updated_jobs, "deliveries": updated_deliveries}


def cancel_reservation_reminders(
    db,
    reservation_id: int,
    canceled_at: datetime | None = None,
) -> dict[str, int]:
    return _stop_pending_reminders(
        db,
        reservation_id=reservation_id,
        stop_status="canceled",
        stopped_at=canceled_at,
    )


def complete_reservation_reminders(
    db,
    reservation_id: int,
    completed_at: datetime | None = None,
) -> dict[str, int]:
    return _stop_pending_reminders(
        db,
        reservation_id=reservation_id,
        stop_status="skipped",
        stopped_at=completed_at,
    )
