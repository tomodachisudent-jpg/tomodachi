"""
給与計算のビジネスロジックを提供するサービス層
"""
from uuid import UUID
from ..crud import payroll as payroll_crud
from ..crud import salary_transfer as salary_transfer_crud


def calc_monthly_payroll(db, provider_id: UUID, year: int, month: int):
    """
    個別先生の月次給与計算

    Args:
        db: データベース接続
        provider_id: 先生ID
        year: 対象年
        month: 対象月

    Returns:
        dict: 給与計算結果
            - provider_id: 先生ID
            - provider_name: 先生名
            - month: 対象月（YYYY-MM形式）
            - total_hours: 総授業時間
            - offline_hours: 対面授業時間
            - online_hours: オンライン授業時間
            - total_amount: 総給与額
            - hourly_rate_offline: 対面授業時給
            - hourly_rate_online: オンライン授業時給
            - payment_method: 振込方法（hand/bank/paypay）
            - bank_name: 銀行名
            - bank_branch: 支店名
            - bank_account_type: 口座種別
            - bank_account_number: 口座番号
            - bank_account_holder: 口座名義
            - paypay_id: PayPay ID
            - paypay_phone_number: PayPayに紐づく電話番号
    """
    # 1. 先生の時給情報を取得（crud層）
    provider = payroll_crud.get_provider_hourly_rates(db, provider_id)

    hourly_rate_offline = float(provider['hourly_rate_offline']) if provider['hourly_rate_offline'] else 2000.0
    hourly_rate_online = float(provider['hourly_rate_online']) if provider['hourly_rate_online'] else 1800.0
    provider_name = provider['display_name']

    # 2. 対象月のservice_logsを取得（crud層）
    service_logs = payroll_crud.get_monthly_service_logs(db, provider_id, year, month)

    # 3. 各サービス実施記録を処理（ビジネスロジック）
    total_hours = 0.0
    total_amount = 0.0
    offline_hours = 0.0
    online_hours = 0.0

    for log in service_logs:
        # 授業時間を計算（秒単位から時間単位に変換）
        duration = log['end_at'] - log['start_at']
        hours = duration.total_seconds() / 3600.0

        # 授業形態に応じた給与計算
        if log['s_type'] == 'offline':
            amount = hours * hourly_rate_offline
            offline_hours += hours
        else:  # online
            amount = hours * hourly_rate_online
            online_hours += hours

        total_hours += hours
        total_amount += amount

    # 4. 結果を返却（振込方法情報を含む）
    return {
        "provider_id": str(provider_id),
        "provider_name": provider_name,
        "month": f"{year:04d}-{month:02d}",
        "total_hours": round(total_hours, 2),
        "offline_hours": round(offline_hours, 2),
        "online_hours": round(online_hours, 2),
        "total_amount": int(total_amount),
        "hourly_rate_offline": float(hourly_rate_offline),
        "hourly_rate_online": float(hourly_rate_online),
        "payment_method": provider.get('payment_method', 'hand'),
        "bank_name": provider.get('bank_name'),
        "bank_branch": provider.get('bank_branch'),
        "bank_account_type": provider.get('bank_account_type'),
        "bank_account_number": provider.get('bank_account_number'),
        "bank_account_holder": provider.get('bank_account_holder'),
        "paypay_id": provider.get('paypay_id'),
        "paypay_phone_number": provider.get('paypay_phone_number'),
    }


def calc_all_providers_payroll(db, year: int, month: int):
    """
    全先生の月次給与計算

    Args:
        db: データベース接続
        year: 対象年
        month: 対象月

    Returns:
        list[dict]: 各先生の給与計算結果のリスト
    """
    # アクティブな全先生を取得（crud層）
    providers = payroll_crud.get_active_providers(db)

    # 対象年月の振込済み記録を取得
    transfers = salary_transfer_crud.get_salary_transfers_by_month(db, year, month)
    transferred_ids = {str(t['provider_id']) for t in transfers}

    # 各先生の給与を計算（ビジネスロジック）
    results = []
    for provider in providers:
        try:
            result = calc_monthly_payroll(db, UUID(provider['user_id']), year, month)
            result['is_transferred'] = result['provider_id'] in transferred_ids
            results.append(result)
        except ValueError:
            # 先生が見つからない場合はスキップ
            continue

    return results
