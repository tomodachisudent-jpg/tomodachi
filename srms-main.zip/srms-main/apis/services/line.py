import httpx
import os

LINE_CHANNEL_ACCESS_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN")

async def send_line_notification(to_line_user_id: str, message: str):
    if not to_line_user_id:
        return {"status": "skipped", "message": "LINE未連携"}

    async with httpx.AsyncClient() as client:
        res = await client.post(
            "https://api.line.me/v2/bot/message/push",
            headers={
                "Authorization": f"Bearer {LINE_CHANNEL_ACCESS_TOKEN}",
                "Content-Type": "application/json"
            },
            json={
                "to": to_line_user_id,
                "messages": [
                    {
                        "type": "text",
                        "text": message
                    }
                ]
            }
        )
        return {
            "status": "sent",
            "line_user_id": to_line_user_id,
            "response": res.text
        }
