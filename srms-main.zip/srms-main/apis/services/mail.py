import os
import httpx
import logging

logger = logging.getLogger(__name__)

MAILJET_API_KEY = os.getenv("MAILJET_API_KEY")
MAILJET_API_SECRET = os.getenv("MAILJET_API_SECRET")
MAILJET_URL = "https://api.mailjet.com/v3.1/send"


async def send_mailjet_email(
    to_email: str, subject: str, text_body: str, html_body: str = None
):
    logger.debug(
        "[mail] send_mailjet_email 呼び出し: to=%s, subject=%s", to_email, subject
    )

    if not to_email:
        logger.warning("[mail] メールアドレス未指定のためスキップ")
        return {"status": "skipped", "message": "メールアドレス未指定"}

    # API キーの存在確認（値は出力しない）
    if not MAILJET_API_KEY or not MAILJET_API_SECRET:
        logger.error(
            "[mail] Mailjet APIキー未設定: MAILJET_API_KEY=%s, MAILJET_API_SECRET=%s",
            "設定済み" if MAILJET_API_KEY else "未設定",
            "設定済み" if MAILJET_API_SECRET else "未設定",
        )
        return {"status": "error", "message": "Mailjet APIキーが設定されていません"}

    # 改行を <br> に変換（f-stringの外で処理）
    escaped_body = text_body.replace("\n", "<br>")

    styled_html = html_body or (
        "<div style=\"font-family: 'Meiryo', 'Hiragino Kaku Gothic ProN', 'Segoe UI', sans-serif; "
        'font-size: 14px; line-height: 1.6;">' + escaped_body + "</div>"
    )

    payload = {
        "Messages": [
            {
                "From": {
                    "Email": "tomodachijps2@gmail.com",
                    "Name": "友達日本語会話教室",
                },
                "To": [{"Email": to_email, "Name": to_email}],
                "Subject": subject,
                "TextPart": text_body,
                "HTMLPart": styled_html,
            }
        ]
    }

    logger.info("[mail] Mailjet APIリクエスト送信中: to=%s", to_email)
    try:
        async with httpx.AsyncClient() as client:
            res = await client.post(
                MAILJET_URL, auth=(MAILJET_API_KEY, MAILJET_API_SECRET), json=payload
            )
    except Exception as e:
        logger.error("[mail] Mailjet APIリクエスト中に例外発生: %s", e, exc_info=True)
        raise

    logger.info(
        "[mail] Mailjet APIレスポンス: status_code=%d, body=%s",
        res.status_code,
        res.text,
    )

    if res.status_code != 200:
        logger.error(
            "[mail] Mailjet APIエラー: status_code=%d, body=%s",
            res.status_code,
            res.text,
        )
        return {"status": "error", "code": res.status_code, "detail": res.text}

    logger.info("[mail] メール送信成功: to=%s", to_email)
    return {"status": "sent", "to": to_email, "response": res.text}
