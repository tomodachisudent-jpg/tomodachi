from __future__ import annotations

import json
from importlib import import_module
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable
from zoneinfo import ZoneInfo

JST = ZoneInfo("Asia/Tokyo")

LINE_CHANNEL = "line"
MAIL_CHANNEL = "mail"

STAGE_LABELS = {
    "3d": "3日前",
    "1d": "1日前",
    "6h": "6時間前",
    "2h": "2時間前",
    "30m": "30分前",
    "5m": "5分前",
    "1m": "1分前",
    "3_days": "3日前",
    "1_day": "1日前",
    "6_hours": "6時間前",
    "2_hours": "2時間前",
    "30_minutes": "30分前",
    "5_minutes": "5分前",
    "1_minute": "1分前",
}


class NotificationDeliveryError(Exception):
    pass


@dataclass(slots=True)
class NotificationSendResult:
    status: str
    message: str


LineSender = Callable[[str, str], Awaitable[dict[str, Any]]]
MailSender = Callable[..., Awaitable[dict[str, Any]]]


def _normalize_snapshot(snapshot: Any) -> dict[str, Any]:
    if snapshot is None:
        return {}
    if isinstance(snapshot, dict):
        return snapshot
    if isinstance(snapshot, str):
        try:
            loaded = json.loads(snapshot)
        except json.JSONDecodeError:
            return {}
        return loaded if isinstance(loaded, dict) else {}
    return {}


def _ensure_utc(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _parse_datetime(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return _ensure_utc(value)
    if isinstance(value, str):
        normalized = value.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError:
            return None
        return _ensure_utc(parsed)
    return None


def _format_datetime(dt: datetime | None) -> str:
    if dt is None:
        return "日時未設定"
    utc_dt = _ensure_utc(dt)
    if utc_dt is None:
        return "日時未設定"
    return utc_dt.astimezone(JST).strftime("%Y/%m/%d %H:%M")


def _get_first_present(data: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = data.get(key)
        if value not in (None, ""):
            return value
    return None


def _recipient_snapshot(
    snapshot: dict[str, Any], recipient_role: str
) -> dict[str, Any]:
    recipient = snapshot.get(recipient_role)
    if isinstance(recipient, dict):
        return {
            "name": _get_first_present(recipient, "name", "display_name"),
            "email": _get_first_present(recipient, "email"),
            "line_user_id": _get_first_present(recipient, "line_user_id"),
        }

    if recipient_role == "provider":
        return {
            "name": _get_first_present(
                snapshot, "provider_name", "provider_display_name"
            ),
            "email": _get_first_present(snapshot, "provider_email"),
            "line_user_id": _get_first_present(
                snapshot, "provider_line_user_id", "provider_line"
            ),
        }

    return {
        "name": _get_first_present(
            snapshot,
            "receiver_name",
            "student_name",
            "receiver_display_name",
        ),
        "email": _get_first_present(snapshot, "receiver_email", "student_email"),
        "line_user_id": _get_first_present(
            snapshot,
            "receiver_line_user_id",
            "receiver_line",
            "student_line_user_id",
        ),
    }


def _lesson_type_label(snapshot: dict[str, Any]) -> str:
    lesson_type = _get_first_present(
        snapshot, "s_type", "service_type", "lesson_type", "type"
    )
    if lesson_type == "online":
        return "オンライン"
    if lesson_type == "offline":
        return "対面"
    return str(lesson_type) if lesson_type else "授業"


def _stage_label(stage: Any) -> str:
    if stage is None:
        return "授業前"
    stage_key = str(stage)
    return STAGE_LABELS.get(stage_key, stage_key)


def build_reminder_content(delivery: dict[str, Any]) -> dict[str, str]:
    snapshot = _normalize_snapshot(delivery.get("reservation_snapshot"))
    recipient_role = delivery.get("recipient_role") or "receiver"
    recipient = _recipient_snapshot(snapshot, recipient_role)
    recipient_name = recipient.get("name") or "ご利用者様"
    counterpart_role = "receiver" if recipient_role == "provider" else "provider"
    counterpart = _recipient_snapshot(snapshot, counterpart_role)
    counterpart_name = counterpart.get("name") or "担当者"

    start_at = _parse_datetime(
        _get_first_present(snapshot, "start_at", "lesson_start_at")
    )
    end_at = _parse_datetime(_get_first_present(snapshot, "end_at", "lesson_end_at"))
    start_text = _format_datetime(start_at)
    end_text = _format_datetime(end_at)
    lesson_type = _lesson_type_label(snapshot)
    stage_text = _stage_label(delivery.get("stage"))
    reservation_id = delivery.get("reservation_id")

    subject = f"【授業リマインド】{stage_text}のご案内"
    text_body = (
        f"{recipient_name} 様\n\n"
        f"予約済み授業の {stage_text} リマインドです。\n"
        f"日時: {start_text} ～ {end_text}\n"
        f"形式: {lesson_type}\n"
        f"講師/受講者: {counterpart_name}\n"
        f"予約ID: {reservation_id}\n"
    )
    html_body = text_body.replace("\n", "<br>")
    line_message = (
        f"【授業リマインド】{stage_text}\n"
        f"日時: {start_text} ～ {end_text}\n"
        f"形式: {lesson_type}\n"
        f"相手: {counterpart_name}\n"
        f"予約ID: {reservation_id}"
    )

    return {
        "subject": subject,
        "text_body": text_body,
        "html_body": html_body,
        "line_message": line_message,
    }


async def send_reminder_notification(
    delivery: dict[str, Any],
    line_sender: LineSender | None = None,
    mail_sender: MailSender | None = None,
) -> NotificationSendResult:
    snapshot = _normalize_snapshot(delivery.get("reservation_snapshot"))
    recipient_role = delivery.get("recipient_role") or "receiver"
    recipient = _recipient_snapshot(snapshot, recipient_role)
    channel = str(delivery.get("channel") or "").lower()
    content = build_reminder_content(delivery)
    resolved_line_sender = line_sender or getattr(
        import_module("apis.services.line"), "send_line_notification"
    )
    resolved_mail_sender = mail_sender or getattr(
        import_module("apis.services.mail"), "send_mailjet_email"
    )

    if channel == LINE_CHANNEL:
        line_user_id = recipient.get("line_user_id")
        if not line_user_id:
            return NotificationSendResult("skipped", "LINE連携未設定")
        result = await resolved_line_sender(line_user_id, content["line_message"])
    elif channel == MAIL_CHANNEL:
        email = recipient.get("email")
        if not email:
            return NotificationSendResult("skipped", "メールアドレス未設定")
        result = await resolved_mail_sender(
            email,
            content["subject"],
            content["text_body"],
            content["html_body"],
        )
    else:
        raise NotificationDeliveryError(f"Unsupported channel: {channel}")

    status = result.get("status")
    if status == "sent":
        return NotificationSendResult("sent", result.get("message", "sent"))
    if status == "skipped":
        return NotificationSendResult("skipped", result.get("message", "skipped"))

    detail = (
        result.get("detail") or result.get("message") or "notification delivery failed"
    )
    raise NotificationDeliveryError(str(detail))
