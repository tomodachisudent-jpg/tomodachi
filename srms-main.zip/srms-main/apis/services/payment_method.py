"""
振込方法のビジネスロジックを提供するサービス層
"""
from ..crud import payment_method as payment_method_crud


def get_payment_method(db, provider_id: str):
    """
    先生の振込方法設定を取得

    Args:
        db: データベース接続
        provider_id: 先生のユーザーID

    Returns:
        dict: 振込方法情報

    Raises:
        ValueError: プロバイダーが見つからない場合
    """
    row = payment_method_crud.get_payment_method(db, provider_id)
    if not row:
        raise ValueError(f"Provider not found: {provider_id}")
    return row


def save_payment_method(db, provider_id: str, payment_method_data):
    """
    振込方法設定を保存/更新
    payment_methodの値に応じて不要なフィールドをNULLにクリアする

    Args:
        db: データベース接続
        provider_id: 先生のユーザーID
        payment_method_data: PaymentMethodスキーマ
    """
    # payment_methodに応じて不要なフィールドをNULLにクリア
    bank_name = None
    bank_branch = None
    bank_account_type = None
    bank_account_number = None
    bank_account_holder = None
    paypay_id = None
    paypay_phone_number = None

    if payment_method_data.payment_method == "bank":
        bank_name = payment_method_data.bank_name
        bank_branch = payment_method_data.bank_branch
        bank_account_type = payment_method_data.bank_account_type
        bank_account_number = payment_method_data.bank_account_number
        bank_account_holder = payment_method_data.bank_account_holder
    elif payment_method_data.payment_method == "paypay":
        paypay_id = getattr(payment_method_data, "paypay_id", None)
        paypay_phone_number = getattr(payment_method_data, "paypay_phone_number", None)

    payment_method_crud.update_payment_method(
        db,
        provider_id,
        payment_method_data.payment_method.value,
        bank_name,
        bank_branch,
        bank_account_type,
        bank_account_number,
        bank_account_holder,
        paypay_id,
        paypay_phone_number,
    )
