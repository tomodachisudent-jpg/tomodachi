# from fastapi import APIRouter, Depends, HTTPException, Body, Path
# from .deps import get_db, get_current_user, require_role
# from .auth import hash_password, TokenData
# from .security import generate_password
# import psycopg2.extras
# from uuid import UUID
# from typing import Literal

# router = APIRouter()

from fastapi import APIRouter, Depends, HTTPException, Body, Query
from .deps import get_db, get_current_user, require_role
from .auth import hash_password, TokenData
from .security import generate_password
from .services.payroll import calc_monthly_payroll, calc_all_providers_payroll
from .services.notification_planner import cancel_reservation_reminders
from .crud import salary_transfer as salary_transfer_crud
import psycopg2
import psycopg2.extras
from uuid import UUID
from typing import Literal
from datetime import datetime, timezone

router = APIRouter()

NOTIFICATION_JOB_TABLE = "notification_jobs"
NOTIFICATION_DELIVERY_TABLE = "notification_deliveries"


def validate_year_month(year: int, month: int):
    """
    年月のバリデーションチェック

    Args:
        year: 対象年
        month: 対象月

    Raises:
        HTTPException: バリデーションエラーの場合
    """
    current_year = datetime.now().year
    current_month = datetime.now().month

    # 年の範囲チェック（2000年以降、現在年+1年まで）
    if year < 2000:
        raise HTTPException(400, "年は2000年以降を指定してください")
    if year > current_year + 1:
        raise HTTPException(400, f"年は{current_year + 1}年以下を指定してください")

    # 月の範囲チェック（1-12、Queryパラメータでも制約されているが念のため）
    if month < 1 or month > 12:
        raise HTTPException(400, "月は1から12の範囲で指定してください")

    # 未来の月のチェック（現在月+1ヶ月まで許可）
    if year == current_year + 1 and month > 1:
        raise HTTPException(400, "未来の給与計算は翌年1月までです")
    if year == current_year and month > current_month + 1:
        raise HTTPException(400, f"未来の給与計算は{current_month + 1}月までです")


def notification_tables_ready(db) -> bool:
    cur = db.cursor()
    cur.execute(
        """
        SELECT EXISTS (
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = 'public' AND table_name = %s
        )
        AND EXISTS (
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = 'public' AND table_name = %s
        )
        """,
        (NOTIFICATION_JOB_TABLE, NOTIFICATION_DELIVERY_TABLE),
    )
    row = cur.fetchone()
    return bool(row and row[0])


def serialize_failed_notification(row: dict) -> dict:
    scheduled_for = row.get("scheduled_for")
    next_retry_at = row.get("next_retry_at")
    return {
        "reservation_id": row["reservation_id"],
        "recipient_type": row["recipient_type"],
        "channel": row["channel"],
        "scheduled_for": scheduled_for.isoformat() if scheduled_for else None,
        "attempt_count": row["attempt_count"],
        "last_error": row["last_error"],
        "next_retry_at": next_retry_at.isoformat() if next_retry_at else None,
    }


def get_failed_notifications(db) -> list[dict]:
    if not notification_tables_ready(db):
        raise HTTPException(
            status_code=503,
            detail="通知リマインダー用テーブルがまだ作成されていません",
        )

    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    try:
        cur.execute(
            f"""
            SELECT
                jobs.reservation_id,
                jobs.recipient_role AS recipient_type,
                deliveries.channel,
                deliveries.scheduled_for,
                deliveries.attempt_count,
                deliveries.last_error,
                deliveries.next_retry_at
            FROM {NOTIFICATION_DELIVERY_TABLE} deliveries
            JOIN {NOTIFICATION_JOB_TABLE} jobs
              ON jobs.id = deliveries.job_id
            WHERE deliveries.status = 'failed'
            ORDER BY deliveries.scheduled_for DESC, deliveries.id DESC
            """
        )
    except psycopg2.Error as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                "通知リマインダー用テーブル定義が想定と異なります。"
                "notification_jobs / notification_deliveries の列名を確認してください"
            ),
        ) from exc

    return [serialize_failed_notification(row) for row in cur.fetchall()]


def run_notification_hook(db, func, *args, **kwargs):
    cur = db.cursor()
    cur.execute("SAVEPOINT reservation_notification_hook")
    try:
        result = func(db, *args, **kwargs)
    except (psycopg2.Error, ValueError):
        cur.execute("ROLLBACK TO SAVEPOINT reservation_notification_hook")
        return None

    cur.execute("RELEASE SAVEPOINT reservation_notification_hook")
    return result


# --- ユーザー一覧取得 ---
@router.get("/api/admin/users", dependencies=[Depends(require_role("admin"))])
def get_users(db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT id, email, role, display_name,
               CASE WHEN line_user_id IS NOT NULL THEN true ELSE false END AS line_linked
        FROM app_users
        ORDER BY id
    """)
    return cur.fetchall()


# --- ユーザー作成 ---
@router.post("/api/admin/users", dependencies=[Depends(require_role("admin"))])
def create_user(payload: dict = Body(...), db=Depends(get_db)):
    role = payload["role"]
    email = payload["email"]
    dn = payload.get("display_name", "")
    webhook = payload.get("slack_webhook")

    cur = db.cursor()
    cur.execute("SELECT 1 FROM app_users WHERE email = %s", (email,))
    if cur.fetchone():
        raise HTTPException(400, "このメールアドレスは既に登録されています")

    raw_password = generate_password(10)
    pw_hash = hash_password(raw_password)

    cur.execute(
        """
        INSERT INTO app_users (email, password_hash, role, display_name, slack_webhook)
        VALUES (%s, %s, %s, %s, %s) RETURNING id
    """,
        (email, pw_hash, role, dn, webhook),
    )
    uid = cur.fetchone()[0]

    if role == "provider":
        cur.execute(
            """
            INSERT INTO providers (user_id, hourly_rate_offline, hourly_rate_online)
            VALUES (%s, %s, %s)
        """,
            (
                uid,
                payload.get("hourly_rate_offline", 2000),
                payload.get("hourly_rate_online", 1800),
            ),
        )
    elif role == "receiver":
        cur.execute(
            "INSERT INTO receivers (user_id, notes) VALUES (%s, %s)",
            (uid, payload.get("notes", "")),
        )

    db.commit()
    return {
        "id": str(uid),
        "email": email,
        "role": role,
        "generated_password": raw_password,
    }


# --- ユーザー削除 ---
@router.delete(
    "/api/admin/users/{user_id}", dependencies=[Depends(require_role("admin"))]
)
def delete_user(
    user_id: UUID, db=Depends(get_db), current: TokenData = Depends(get_current_user)
):
    if str(user_id) == str(current.user_id):
        raise HTTPException(403, "自分自身は削除できません")

    cur = db.cursor()
    cur.execute("SELECT role FROM app_users WHERE id = %s", (str(user_id),))
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "ユーザーが存在しません")

    role = row[0]

    if role == "admin":
        cur.execute(
            "SELECT COUNT(*) FROM app_users WHERE role = 'admin' AND id != %s",
            (str(user_id),),
        )
        count = cur.fetchone()[0]
        if count == 0:
            raise HTTPException(400, "最低1人は管理者が必要です")

    if role == "provider":
        cur.execute("DELETE FROM providers WHERE user_id = %s", (str(user_id),))
    elif role == "receiver":
        cur.execute("DELETE FROM receivers WHERE user_id = %s", (str(user_id),))

    cur.execute("DELETE FROM app_users WHERE id = %s", (str(user_id),))
    db.commit()

    return {"status": "success", "message": "ユーザーを削除しました"}


# --- ユーザのロール変更 ---
@router.patch(
    "/api/admin/users/{user_id}/role", dependencies=[Depends(require_role("admin"))]
)
def update_user_role(
    user_id: UUID,
    new_role: Literal["provider", "receiver", "admin"] = Body(...),
    db=Depends(get_db),
    current: TokenData = Depends(get_current_user),
):
    cur = db.cursor()

    if str(user_id) == str(current.user_id) and new_role != "admin":
        raise HTTPException(403, "自分自身のロールをadmin以外に変更できません")

    cur.execute("SELECT role FROM app_users WHERE id = %s", (str(user_id),))
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "ユーザーが存在しません")

    old_role = row[0]

    if old_role == "admin" and new_role != "admin":
        cur.execute(
            "SELECT COUNT(*) FROM app_users WHERE role = 'admin' AND id != %s",
            (str(user_id),),
        )
        count = cur.fetchone()[0]
        if count == 0:
            raise HTTPException(400, "最低1人は管理者が必要です")

    cur.execute(
        "UPDATE app_users SET role = %s WHERE id = %s", (new_role, str(user_id))
    )

    if new_role == "provider":
        cur.execute(
            """
            INSERT INTO providers (user_id)
            VALUES (%s)
            ON CONFLICT (user_id) DO NOTHING
        """,
            (str(user_id),),
        )
    elif new_role == "receiver":
        cur.execute(
            """
            INSERT INTO receivers (user_id)
            VALUES (%s)
            ON CONFLICT (user_id) DO NOTHING
        """,
            (str(user_id),),
        )

    db.commit()
    return {
        "status": "success",
        "message": f"ロールを {new_role} に変更し、関連テーブルに登録しました",
    }


# --- パスワード再発行 ---
@router.post(
    "/api/admin/users/{user_id}/reset-password",
    dependencies=[Depends(require_role("admin"))],
)
def reset_user_password(user_id: UUID, db=Depends(get_db)):
    cur = db.cursor()
    cur.execute("SELECT email FROM app_users WHERE id = %s", (str(user_id),))
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "ユーザーが存在しません")

    email = row[0]
    new_password = generate_password(10)
    pw_hash = hash_password(new_password)

    cur.execute(
        """
        UPDATE app_users
        SET password_hash = %s,
            is_active = TRUE,
            login_fail_count = 0
        WHERE id = %s
    """,
        (pw_hash, str(user_id)),
    )

    db.commit()
    return {
        "status": "success",
        "generated_password": new_password,
        "email": email,
        "message": "パスワードを再発行し、アカウントを有効化しました",
    }


# --- シフト一覧（管理者） ---
@router.get("/api/admin/shifts", dependencies=[Depends(require_role("admin"))])
def get_admin_shifts(db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT
            s.id, s.start_at, s.end_at, s.s_type, s.is_locked, s.provider_id,
            p.display_name AS provider_name,
            r.receiver_id AS reserved_by,
            u.display_name AS reserved_by_name,
            r.id AS reservation_id,
            r.status AS reservation_status,
            EXISTS (
                SELECT 1 FROM service_logs sl WHERE sl.reservation_id = r.id
            ) AS is_completed
        FROM shifts s
        LEFT JOIN (
            SELECT DISTINCT ON (shift_id) * FROM reservations
            ORDER BY shift_id, updated_at DESC
        ) r ON r.shift_id = s.id
        LEFT JOIN app_users u ON u.id = r.receiver_id
        LEFT JOIN app_users p ON p.id = s.provider_id
        ORDER BY s.start_at
    """)
    return cur.fetchall()


# --- 失敗通知一覧（管理者） ---
@router.get(
    "/api/admin/notifications/failed",
    dependencies=[Depends(require_role("admin"))],
)
def get_failed_notification_deliveries(db=Depends(get_db)):
    return get_failed_notifications(db)


# --- シフト強制キャンセル（管理者） ---
@router.post(
    "/api/admin/shifts/{shift_id}/force-cancel",
    dependencies=[Depends(require_role("admin"))],
)
def admin_force_cancel(shift_id: int, db=Depends(get_db)):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    now_utc = datetime.now(timezone.utc)

    # 該当予約を取得
    cur.execute(
        """
        SELECT r.id
        FROM reservations r
        WHERE r.shift_id = %s AND r.status = 'reserved'
    """,
        (shift_id,),
    )
    row = cur.fetchone()
    if not row:
        raise HTTPException(404, "予約が見つかりません")

    # 予約キャンセル
    cur.execute(
        "UPDATE reservations SET status = 'canceled', canceled_at = %s WHERE id = %s",
        (now_utc, row["id"]),
    )

    cur.execute("UPDATE shifts SET is_locked = false WHERE id = %s", (shift_id,))
    run_notification_hook(
        db, cancel_reservation_reminders, row["id"], canceled_at=now_utc
    )

    db.commit()
    return {"ok": True, "admin": True}


# --- 個別先生の月次給与計算 ---
@router.get(
    "/api/admin/payroll/{provider_id}", dependencies=[Depends(require_role("admin"))]
)
def get_provider_payroll(
    provider_id: UUID,
    year: int = Query(..., ge=2000, description="対象年（2000年以降）"),
    month: int = Query(..., ge=1, le=12, description="対象月（1-12）"),
    db=Depends(get_db),
):
    """
    指定された先生の月次給与を計算する

    - **provider_id**: 先生のユーザーID
    - **year**: 対象年（例: 2026）
    - **month**: 対象月（1-12）
    """
    # バリデーションチェック
    validate_year_month(year, month)

    try:
        result = calc_monthly_payroll(db, provider_id, year, month)
        return result
    except ValueError as e:
        raise HTTPException(404, str(e))
    except Exception as e:
        raise HTTPException(500, f"給与計算中にエラーが発生しました: {str(e)}")


# --- 全先生の月次給与計算 ---
@router.get("/api/admin/payroll", dependencies=[Depends(require_role("admin"))])
def get_all_payroll(
    year: int = Query(..., ge=2000, description="対象年（2000年以降）"),
    month: int = Query(..., ge=1, le=12, description="対象月（1-12）"),
    db=Depends(get_db),
):
    """
    全先生の月次給与を計算する

    - **year**: 対象年（例: 2026）
    - **month**: 対象月（1-12）
    """
    # バリデーションチェック
    validate_year_month(year, month)

    try:
        results = calc_all_providers_payroll(db, year, month)
        return results
    except Exception as e:
        raise HTTPException(500, f"給与計算中にエラーが発生しました: {str(e)}")


# --- 給与振込結果登録 ---
@router.post(
    "/api/admin/payroll/{provider_id}/transfer",
    dependencies=[Depends(require_role("admin"))],
)
def register_salary_transfer(
    provider_id: UUID,
    payload: dict = Body(...),
    db=Depends(get_db),
    current: TokenData = Depends(get_current_user),
):
    year = payload["year"]
    month = payload["month"]

    # バリデーションチェック
    validate_year_month(year, month)

    # 先生の存在確認
    if not salary_transfer_crud.check_provider_exists(db, str(provider_id)):
        raise HTTPException(404, "先生が存在しません")

    # 重複チェック
    existing = salary_transfer_crud.get_salary_transfer(
        db, str(provider_id), year, month
    )
    if existing:
        raise HTTPException(409, "既に振込結果が登録されています")

    # 振込結果を登録
    salary_transfer_crud.insert_salary_transfer(
        db, str(provider_id), year, month, str(current.user_id)
    )

    return {"status": "success", "message": "振込結果を登録しました"}
