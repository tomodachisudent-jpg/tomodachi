from fastapi import HTTPException
import secrets
import string

def generate_password(length=10) -> str:
    chars = string.ascii_letters + string.digits
    return ''.join(secrets.choice(chars) for _ in range(length))


def ensure_not_self_demotion(old_role: str, new_role: str, is_self: bool):
    if is_self and old_role == 'admin' and new_role != 'admin':
        raise HTTPException(400, "Cannot downgrade yourself if you are the last admin.")
