from __future__ import annotations

import asyncio
from importlib import import_module
import logging
import os
from contextlib import asynccontextmanager, suppress
from typing import AsyncIterator

from .services.notification_worker import run_notification_worker_loop

logger = logging.getLogger(__name__)


def notification_worker_enabled() -> bool:
    value = os.getenv("NOTIFICATION_WORKER_ENABLED", "true")
    return value.lower() in {"1", "true", "yes", "on"}


def create_notification_worker_connection():
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        raise RuntimeError("DATABASE_URL is not set")
    psycopg2 = import_module("psycopg2")
    return psycopg2.connect(database_url)


@asynccontextmanager
async def notification_worker_lifespan(app) -> AsyncIterator[None]:
    stop_event = None
    worker_task = None
    app.state.notification_worker_task = None
    app.state.notification_worker_stop_event = None

    if not notification_worker_enabled():
        yield
        return

    if not os.getenv("DATABASE_URL"):
        logger.warning("notification worker disabled because DATABASE_URL is not set")
        yield
        return

    stop_event = asyncio.Event()
    worker_task = asyncio.create_task(
        run_notification_worker_loop(
            create_notification_worker_connection,
            stop_event=stop_event,
        )
    )
    app.state.notification_worker_task = worker_task
    app.state.notification_worker_stop_event = stop_event
    logger.info("notification worker started in-process")

    try:
        yield
    finally:
        stop_event.set()
        shutdown_timeout = float(os.getenv("NOTIFICATION_WORKER_SHUTDOWN_TIMEOUT", "5"))
        try:
            await asyncio.wait_for(
                asyncio.shield(worker_task), timeout=shutdown_timeout
            )
        except asyncio.TimeoutError:
            worker_task.cancel()
            with suppress(asyncio.CancelledError):
                await worker_task
        app.state.notification_worker_task = None
        app.state.notification_worker_stop_event = None
        logger.info("notification worker stopped")
