
from fastapi import APIRouter, Depends, HTTPException, Body, Request
from .deps import get_db, get_current_user, require_role
from .schemas import MailRequest
from .services.mail import send_mailjet_email
import httpx, os, logging
from jose import jwt

router = APIRouter()

logger = logging.getLogger("uvicorn")
LINE_CHANNEL_ACCESS_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN")

@router.get("/api/line/callback")
async def line_callback(request: Request, db=Depends(get_db)):
    try:
        code = request.query_params.get("code")
        state = request.query_params.get("state")
        logger.info("LINE callback received")
        async with httpx.AsyncClient() as client:
            token_res = await client.post("https://api.line.me/oauth2/v2.1/token", data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": os.getenv("LINE_LOGIN_REDIRECT_URI"),
                "client_id": os.getenv("LINE_LOGIN_CHANNEL_ID"),
                "client_secret": os.getenv("LINE_LOGIN_CHANNEL_SECRET")
            }, headers={"Content-Type": "application/x-www-form-urlencoded"})
        logger.info(f"Token response status: {token_res.status_code}")
        token_data = token_res.json()
        id_token = token_data.get("id_token")
        if not id_token:
            logger.error("ID token not found in response")
            return {"status": "error", "message": "LINE認証に失敗しました"}
        try:
            decoded = jwt.decode(
                id_token,
                key=None,
                options={"verify_signature": False},
                audience=os.getenv("LINE_LOGIN_CHANNEL_ID")
            )
            line_user_id = decoded.get("sub")
        except Exception as e:
            logger.exception("JWTデコード失敗")
            return {"status": "error", "message": "LINE認証に失敗しました"}
        if not line_user_id:
            logger.error("LINE user IDが取得できませんでした")
            return {"status": "error", "message": "LINE認証に失敗しました"}
        cur = db.cursor()
        cur.execute("SELECT id FROM app_users WHERE id = %s", (state,))
        if not cur.fetchone():
            logger.warning("対象ユーザーが存在しません")
            return {"status": "error", "message": "対象ユーザーが存在しません"}
        cur.execute("UPDATE app_users SET line_user_id = %s WHERE id = %s", (line_user_id, state))
        db.commit()
        return {
            "status": "success",
            "line_user_id": line_user_id,
            "user_id": state,
            "message": "LINE連携が完了しました"
        }
    except Exception as e:
        logger.exception("LINE callback処理中に例外が発生しました")
        return {"status": "error", "message": "LINE連携エラー"}

@router.get("/api/line/webhook")
def verify_webhook():
    return {"status": "Webhook GET OK"}

@router.post("/api/line/webhook")
async def line_webhook(request: Request, db=Depends(get_db)):
    body = await request.json()
    for event in body.get("events", []):
        if event["type"] == "message":
            user_id = event["source"]["userId"]
            cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("SELECT id FROM app_users WHERE line_user_id = %s", (user_id,))
            existing = cur.fetchone()
            if not existing:
                cur.execute("INSERT INTO app_users (line_user_id, is_active) VALUES (%s, TRUE)", (user_id,))
                db.commit()
            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://api.line.me/v2/bot/message/push",
                    headers={
                        "Authorization": f"Bearer {LINE_CHANNEL_ACCESS_TOKEN}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "to": user_id,
                        "messages": [
                            {"type": "text", "text": "✅ LINE通知テスト成功！"}
                        ]
                    }
                )
    return {"status": "ok"}

@router.post("/api/line/test-notify", dependencies=[Depends(require_role("provider", "receiver", "admin"))])
async def line_notify_test(user=Depends(get_current_user)):
    line_user_id = user.line_user_id
    logger.info(f"LINE通知テスト: user_id={user.user_id}, line_user_id={line_user_id}")
    if not line_user_id:
        return {"status": "error", "message": "LINE連携されていません"}
    async with httpx.AsyncClient() as client:
        res = await client.post(
            "https://api.line.me/v2/bot/message/push",
            headers={
                "Authorization": f"Bearer {LINE_CHANNEL_ACCESS_TOKEN}",
                "Content-Type": "application/json"
            },
            json={
                "to": line_user_id,
                "messages": [
                    {"type": "text", "text": "✅ LINE通知テスト成功！"}
                ]
            }
        )
        return {
            "status": "success",
            "message": "LINE通知を送信しました",
            "line_response": res.text
        }

@router.post("/api/sendmail")
def send_mail(request: MailRequest):
    try:
        result = send_mailjet_email(
            to_email=request.to,
            subject=request.subject,
            text_body=request.body
        )
        return {"message": "メール送信成功", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
