from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, Enum, Float
from sqlalchemy.orm import relationship
from .database import Base
import enum

class RoleEnum(str, enum.Enum):
    admin = "admin"
    provider = "provider"
    customer = "customer"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    name = Column(String)
    role = Column(Enum(RoleEnum), default=RoleEnum.customer)

class Shift(Base):
    __tablename__ = "shifts"
    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(Integer, ForeignKey("users.id"))
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    is_online = Column(Boolean, default=False)

class Reservation(Base):
    __tablename__ = "reservations"
    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("users.id"))
    shift_id = Column(Integer, ForeignKey("shifts.id"))
    status = Column(String, default="booked")

class Payroll(Base):
    __tablename__ = "payrolls"
    id = Column(Integer, primary_key=True)
    provider_id = Column(Integer, ForeignKey("users.id"))
    hours = Column(Float)
    wage = Column(Float)
