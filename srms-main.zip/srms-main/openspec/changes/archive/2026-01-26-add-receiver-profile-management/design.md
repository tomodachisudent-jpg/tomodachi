# Design: 生徒用プロフィール登録・編集機能

## アーキテクチャ概要
本機能は、既存の Provider Profile 機能と同様の3層アーキテクチャパターンを採用します：
- **Presentation Layer**: Vue 3 + Quasar Framework による UI
- **Business Logic Layer**: FastAPI による REST API
- **Data Access Layer**: PostgreSQL + SQLAlchemy

## データモデル設計

### receiver_profiles テーブル
Provider Profiles と同様の構造を採用しますが、生徒向けにフィールドを簡素化します。

```sql
CREATE TABLE public.receiver_profiles (
  id uuid DEFAULT gen_random_uuid() NOT NULL,
  user_id uuid NOT NULL,
  name text NULL,
  age integer NULL,
  gender text NULL,
  nationality text NULL,
  self_introduction text NULL,
  learning_goals text NULL,
  created_at timestamp DEFAULT now() NULL,
  updated_at timestamp DEFAULT now() NULL,
  CONSTRAINT receiver_profiles_pkey PRIMARY KEY (id),
  CONSTRAINT receiver_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.app_users(id) ON DELETE CASCADE
);
```

**設計判断の理由**:
- `age` を `integer` 型とすることで、データベースレベルでの型検証を実現
- Provider Profiles にある `photo_url` を除外し、シンプルな情報管理に注力
- すべてのフィールドを `NULL` 許可とし、段階的な情報入力を可能にする
- `user_id` を外部キーとし、ユーザーアカウント削除時にプロフィールも自動削除

## API設計

### エンドポイント
既存の Provider Profile API パターンに準拠します：

1. **GET /api/receiver/profile**
   - 認証済みユーザー自身のプロフィール取得
   - レスポンス: プロフィールオブジェクトまたは空オブジェクト `{}`

2. **POST /api/receiver/profile**
   - プロフィールの作成または更新（upsert）
   - リクエストボディ: `ReceiverProfile` スキーマ
   - レスポンス: `{"status": "success", "message": "プロフィールを保存しました"}`

3. **GET /api/receiver/profile/{receiver_id}** (将来的な拡張)
   - 他のユーザーが生徒プロフィールを閲覧（講師向け機能）
   - 現時点では実装対象外

### Pydantic スキーマ
```python
class ReceiverProfile(BaseModel):
    name: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    nationality: Optional[str] = None
    self_introduction: Optional[str] = None
    learning_goals: Optional[str] = None
```

**設計判断の理由**:
- すべてのフィールドを `Optional` とし、デフォルト値 `None` を設定
- `age` を `int` 型とすることで、Pydantic による自動バリデーションを活用
- Provider Profile と同様のパターンで、既存コードとの一貫性を保つ

## フロントエンド設計

### ルーティング
- パス: `/receiver/profile`
- コンポーネント: `ReceiverProfile.vue`
- 認証: `meta: { requiresAuth: true, roles: ['receiver'] }`

### UI設計
既存の `ProviderProfile.vue` を参考に、以下の入力フィールドを持つフォームを作成：

1. **名前** - `q-input` (text)
2. **年齢** - `q-input` (number) ※数値バリデーション付き
3. **性別** - `q-select` (選択肢: 男性, 女性, その他, 無回答)
4. **国籍** - `q-input` (text) または `q-select` (主要国リスト)
5. **自己紹介** - `q-input` (textarea)
6. **学習目的** - `q-input` (textarea)

**設計判断の理由**:
- Provider Profile UI との一貫性を保ちながら、シンプルな構成を維持
- 写真アップロード機能を除外することで、実装コストを削減
- Quasar の標準コンポーネントを使用し、レスポンシブ対応

## セキュリティ考慮事項

### Row Level Security (RLS)
```sql
-- 生徒は自分のプロフィールのみ参照・更新可能
CREATE POLICY receiver_profiles_select_own ON public.receiver_profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY receiver_profiles_insert_own ON public.receiver_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY receiver_profiles_update_own ON public.receiver_profiles
  FOR UPDATE USING (auth.uid() = user_id);
```

**設計判断の理由**:
- JWT 認証により、API レベルでユーザー認証を実施
- RLS ポリシーにより、データベースレベルでアクセス制御を強化
- 既存の Provider Profiles と同様のセキュリティモデルを適用

## バリデーション戦略

### バックエンド
- Pydantic による型バリデーション（`age: int`）
- FastAPI の自動バリデーションエラーレスポンス

### フロントエンド
- Quasar の `q-input` に `type="number"` および `:rules` を設定
- 年齢フィールド: `[val => val === null || val === '' || (!isNaN(val) && val > 0) || '正の数値を入力してください']`

**設計判断の理由**:
- 二重バリデーションにより、ユーザビリティとセキュリティを両立
- フロントエンドで即座にフィードバック、バックエンドで最終検証

## 実装パターン

Provider Profile の実装パターンを踏襲：
1. データベーススキーマ: `supabase/schema.sql` に追加
2. Pydantic スキーマ: `apis/schemas.py` に `ReceiverProfile` 追加
3. API ルート: 新規ファイル `apis/receiver_profile.py` を作成（または既存 `receiver.py` に追加）
4. フロントエンド: `ui/src/pages/ReceiverProfile.vue` を作成
5. ルーティング: `ui/src/router/routes.js` に追加

**設計判断の理由**:
- 既存の Provider Profile 実装を参考にすることで、開発効率と保守性を向上
- 新規ファイル作成により、既存コードへの影響を最小化
- コードの一貫性を保ち、将来的な拡張を容易にする
