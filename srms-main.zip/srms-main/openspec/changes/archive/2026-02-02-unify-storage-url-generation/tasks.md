## 1. 共通ユーティリティ関数の作成

- [x] 1.1 `apis/utils.py` を新規作成
- [x] 1.2 `is_local_environment()` 関数を実装（SUPABASE_URL に基づく環境判定）
- [x] 1.3 `get_storage_url()` 関数を実装（環境に応じた URL 生成）

## 2. Provider 画像アップロードの修正

- [x] 2.1 `apis/provider.py` で `from .utils import get_storage_url` を追加
- [x] 2.2 `upload_profile_photo()` 関数で `get_public_url()` の代わりに `get_storage_url()` を使用

## 3. Receiver Profile 画像アップロードの修正

- [x] 3.1 `apis/receiver_profile.py` で `from .utils import get_storage_url` を追加
- [x] 3.2 `upload_receiver_profile_photo()` 関数で `get_storage_url()` を使用するよう統一

## 4. 環境変数の更新

- [x] 4.1 `.env` の `SUPABASE_KEY` を `SUPABASE_SERVICE_ROLE_KEY` に変更
- [x] 4.2 `.env.dev` の検証（追加設定は不要と確認）

## 5. 動作確認

- [x] 5.1 ローカル環境（DevContainer）で provider 画像アップロードと表示を確認
- [x] 5.2 ローカル環境（DevContainer）で receiver profile 画像アップロードと表示を確認
- [x] 5.3 本番環境（Koyeb）での動作は変更なし（絶対URLが生成される）
