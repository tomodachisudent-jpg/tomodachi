# Storage URL生成の統一

## Why

開発環境（ローカル）と本番環境で Supabase Storage の画像URL生成方式が異なっており、ローカル環境では画像が表示できない問題が発生していた。`provider.py` では絶対URLを返していたが、これではブラウザから Docker 内部ネットワーク（172.17.0.1）にアクセスできない。一方 `receiver_profile.py` では相対パスを使用しており動作していた。この実装の違いを統一し、環境に応じて適切なURL形式を自動的に選択する仕組みが必要だった。

## What Changes

- **新規作成**: `apis/utils.py` - Storage URL 生成の共通ユーティリティ関数
  - `is_local_environment()`: SUPABASE_URL に基づいてローカル環境を判定
  - `get_storage_url()`: 環境に応じて相対パスまたは絶対URLを生成
- **修正**: `apis/provider.py` - `get_public_url()` の代わりに `get_storage_url()` を使用
- **修正**: `apis/receiver_profile.py` - 共通関数 `get_storage_url()` を使用するよう統一

## Capabilities

### New Capabilities
- `storage-url-utils`: Storage URL生成の共通ユーティリティ関数群。環境判定とURL形式の自動選択を提供。

### Modified Capabilities
- なし（既存の機能要件変更はなし、実装の統一のみ）

## Impact

- **Affected Files**:
  - `apis/utils.py`（新規作成）
  - `apis/provider.py`（修正）
  - `apis/receiver_profile.py`（修正）
- **動作環境**: DevContainer（ローカル）、Koyeb（本番）
- **互換性**: 本番環境での動作は変更なし、ローカル環境で画像表示が正常化
