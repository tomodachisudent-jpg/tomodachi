## ADDED Requirements

### Requirement: Environment detection based on SUPABASE_URL
The system SHALL detect local development environment by checking if `SUPABASE_URL` contains local-specific patterns.

#### Scenario: Local environment detection
- **WHEN** `SUPABASE_URL` contains "localhost" or "127.0.0.1" or "172.17.0.1"
- **THEN** the system SHALL identify it as local environment

#### Scenario: Production environment detection
- **WHEN** `SUPABASE_URL` does NOT contain local patterns (e.g., "https://xxx.supabase.co")
- **THEN** the system SHALL identify it as production environment

### Requirement: Storage URL generation with environment awareness
The system SHALL generate appropriate Storage URLs based on the detected environment.

#### Scenario: Generate relative path for local environment
- **GIVEN** the system is running in local environment
- **WHEN** generating a storage URL for bucket "profile-photos" and file "image.jpg"
- **THEN** the system SHALL return "/storage/v1/object/public/profile-photos/image.jpg"

#### Scenario: Generate absolute URL for production environment
- **GIVEN** the system is running in production environment
- **AND** `SUPABASE_URL` is "https://xxx.supabase.co"
- **WHEN** generating a storage URL for bucket "profile-photos" and file "image.jpg"
- **THEN** the system SHALL return "https://xxx.supabase.co/storage/v1/object/public/profile-photos/image.jpg"

### Requirement: Utility function reusability
The system SHALL provide reusable utility functions that can be imported by multiple API endpoint files.

#### Scenario: Import in provider.py
- **WHEN** importing `get_storage_url` from `apis.utils` in `provider.py`
- **THEN** the function SHALL be available for generating provider profile photo URLs

#### Scenario: Import in receiver_profile.py
- **WHEN** importing `get_storage_url` from `apis.utils` in `receiver_profile.py`
- **THEN** the function SHALL be available for generating receiver profile photo URLs
