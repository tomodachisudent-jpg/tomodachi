## Context

現在、Supabase Storage にアップロードした画像URLを生成する方法が `provider.py` と `receiver_profile.py` で異なっていた：

- **provider.py**: `get_public_url()` を使用し絶対URLを返す（例: `http://172.17.0.1:54321/storage/v1/object/public/profile-photos/xxx.jpg`）
- **receiver_profile.py**: 相対パスを返す（例: `/storage/v1/object/public/receiver-profile-photos/xxx.jpg`）

ローカル開発環境（DevContainer）では、ブラウザ（ホスト側）から Docker 内部ネットワーク（172.17.0.1）にアクセスできないため、provider.py の方式では画像が表示できなかった。一方、相対パス方式では quasar.config.js のプロキシ設定（`/storage/*` → `http://172.17.0.1:54321`）を経由して正常にアクセスできる。

本番環境（Koyeb）では、絶対URL（`https://xxx.supabase.co/...`）はブラウザから直接アクセス可能なため、どちらの方式でも動作する。

## Goals / Non-Goals

**Goals:**
- ローカル環境と本番環境で両方とも正常に動作する URL 生成方式を実現
- 画像アップロード処理を行う複数のファイルで URL 生成ロジックを共通化
- 環境（ローカル/本番）を自動的に判定し、適切な URL 形式（相対パス/絶対URL）を選択

**Non-Goals:**
- Supabase Storage のバケット設定や RLS ポリシーの変更
- nginx.conf にプロキシ設定を追加（インフラ構成の変更）
- フロントエンド側の画像表示ロジックの変更

## Decisions

### 1. SUPABASE_URL ベースの環境判定

**決定**: `SUPABASE_URL` の内容に基づいてローカル環境を判定する
- `localhost`, `172.17.0.1`, `127.0.0.1` を含む場合はローカル環境と判定
- 明示的な `ENV` 環境変数は使用しない（不要な変数の追加を避ける）

**理由**:
- `.env` と `.env.dev` の切り替えだけで環境が決まるため、追加の環境変数が不要
- 既存の `SUPABASE_URL` の値だけで十分に判定可能

### 2. 共通ユーティリティ関数の配置場所

**決定**: `apis/utils.py` を新規作成し、そこに共通関数を定義する

**理由**:
- `utils/` や `helpers/` ディレクトリは既存では存在しない
- `apis/` ディレクトリ内に同階層で配置することで、既存の `deps.py` などと同じパターンになる
- 複数の router ファイル（provider.py, receiver_profile.py など）から import しやすい

### 3. URL生成関数のインターフェース

**決定**: `get_storage_url(bucket_name: str, file_name: str) -> str` とする

**理由**:
- シンプルで使いやすい
- バケット名とファイル名を受け取り、環境に応じた URL を返す
- 呼び出し元は環境を意識する必要がない

## Risks / Trade-offs

**[Trade-off] SUPABASE_URL ベースの判定は暗黙的**
→ 環境判定ロジックが `SUPABASE_URL` の文字列パターンマッチングに依存しており、将来的に特殊な URL 形式が追加された場合、誤判定する可能性がある。しかし、一般的な開発環境では `localhost` や `127.0.0.1`、`172.17.0.1`（Docker Bridge）などのパターンで十分カバーできる。

**[Risk] 本番環境で URL が正しく生成されない**
→ 本番環境の `SUPABASE_URL` が `localhost` などを含まないことを確認する必要がある。実際の本番環境では `https://xxx.supabase.co` 形式のため、問題ない。

**[Trade-off] 相対パス方式では開発サーバー（Quasar proxy）に依存**
→ ローカル環境では quasar.config.js のプロキシ設定が必要。ただし、これは既存の設定であり、receiver_profile.py でも既に利用されているため、新規の依存ではない。
