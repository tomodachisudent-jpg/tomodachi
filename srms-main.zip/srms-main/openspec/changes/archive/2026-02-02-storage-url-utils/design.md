## Context

### 問題の背景

ローカル開発環境で画像アップロードは成功するが、画像表示ができない問題が発生していた。

**本番環境の構成**:
- SUPABASE_URL: `https://xxx.supabase.co`
- URL形式: 絶対URL（ブラウザから直接アクセス可能）
- 動作: 問題なし

**ローカル開発環境の構成**:
- SUPABASE_URL: `http://172.17.0.1:54321`（Docker Bridgeネットワーク）
- URL形式: 絶対URL（ブラウザからアクセス不可）
- 動作: 画像がローディング表示のまま

### 技術的制約

1. **Dockerネットワーク**: DevContainer内からは `172.17.0.1` にアクセス可能だが、ブラウザ（ホスト側）からはアクセス不可
2. **Quasarプロキシ**: `quasar.config.js` で `/storage/*` → `http://172.17.0.1:54321` にプロキシ設定済み
3. **nginx.conf**: 本番環境では `/storage/` へのプロキシ設定がない（絶対URLが必要）

## Goals / Non-Goals

### Goals
- ローカル環境でも画像表示が正常に動作すること
- 本番環境との互換性を維持すること
- 重複コードを削減し、共通関数化すること

### Non-Goals
- nginx.conf の変更（本番環境のインフラ変更は行わない）
- フロントエンドの大幅な変更
- Supabase Storage の設定変更

## Decisions

### 1. 環境判定ロジック

**決定**: SUPABASE_URL の内容に基づいて環境を判定する

```python
def is_local_environment() -> bool:
    supabase_url = os.getenv("SUPABASE_URL", "")
    return any(x in supabase_url for x in ["localhost", "172.17.0.1", "127.0.0.1"])
```

**理由**:
- 明示的な `ENV` 環境変数を追加する必要がない
- 既存の `.env` / `.env.dev` ファイルの切り替え方式と整合性がある
- SUPABASE_URL の値は環境によって確実に異なる（localhost/172.17.0.1 vs https://xxx.supabase.co）

**代替案**:
- ❌ `ENV=local` 環境変数を追加: 不要な環境変数の追加となる
- ❌ 設定ファイルベースの判定: 複雑化する

### 2. URL生成関数の設計

**決定**: `get_storage_url(bucket_name, file_name)` 関数を共通実装

```python
def get_storage_url(bucket_name: str, file_name: str) -> str:
    if is_local_environment():
        return f"/storage/v1/object/public/{bucket_name}/{file_name}"
    else:
        supabase_url = os.getenv("SUPABASE_URL", "").rstrip("/")
        return f"{supabase_url}/storage/v1/object/public/{bucket_name}/{file_name}"
```

**理由**:
- シンプルで再利用可能
- ローカル/本番の切り替えを自動的に処理
- 既存の `provider.py` と `receiver_profile.py` の両方で使用可能

**返却値の違い**:
- ローカル: `/storage/v1/object/public/profile-photos/xxx.jpg`（相対パス）
- 本番: `https://xxx.supabase.co/storage/v1/object/public/profile-photos/xxx.jpg`（絶対URL）

### 3. 環境変数名の統一

**決定**: `.env` の `SUPABASE_KEY` を `SUPABASE_SERVICE_ROLE_KEY` に変更

**理由**:
- `.env.dev` では既に `SUPABASE_SERVICE_ROLE_KEY` を使用
- コードは `SUPABASE_SERVICE_ROLE_KEY` を参照
- 環境間での整合性を取る

**変更前**:
```bash
SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**変更後**:
```bash
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 4. ファイル配置

**決定**: `apis/utils.py` に共通関数を定義

**理由**:
- シンプルな構成（新規ディレクトリ作成不要）
- 他のAPIモジュールから容易にインポート可能
- 将来的に他のユーティリティ関数も追加可能

**インポート方法**:
```python
from .utils import get_storage_url
```

## Risks / Trade-offs

### Risk: 環境判定の誤判定

**詳細**: SUPABASE_URL に意図しない文字列が含まれる場合、誤判定の可能性がある

**軽減策**:
- 明確なパターン（localhost, 172.17.0.1, 127.0.0.1）のみを判定対象とする
- 本番URLは通常 `https://` かつ `.supabase.co` を含むため、誤判定のリスクは低い

### Trade-off: 相対パス vs 絶対URL

**メリット**:
- ローカル環境での画像表示が正常に動作
- プロキシ設定を活用して一貫した開発体験を提供

**デメリット**:
- 本番とローカルでURL形式が異なる（相対 vs 絶対）
- フロントエンドでURL処理に注意が必要（通常はそのまま使用可能）

**判断**:
- 環境ごとの最適な形式を自動選択することで、開発者体験を向上
- フロントエンドは受け取ったURLをそのまま使用すれば問題なし

## Migration Plan

### フェーズ 1: 共通関数の作成

1. `apis/utils.py` を新規作成
2. `is_local_environment()` 関数を実装
3. `get_storage_url()` 関数を実装

### フェーズ 2: 既存コードの修正

1. `apis/provider.py` の修正:
   - `from .utils import get_storage_url` を追加
   - `get_public_url()` の代わりに `get_storage_url()` を使用

2. `apis/receiver_profile.py` の修正:
   - `from .utils import get_storage_url` を追加
   - 相対パス生成を `get_storage_url()` に置き換え

### フェーズ 3: 環境変数の更新

1. `.env` の修正:
   - `SUPABASE_KEY` → `SUPABASE_SERVICE_ROLE_KEY` に変更

### フェーズ 4: テスト

1. ローカル環境での画像アップロードと表示テスト
2. 本番環境での動作確認（デプロイ後）

### ロールバック戦略

1. `apis/utils.py` を削除
2. `provider.py` と `receiver_profile.py` を元の実装に戻す
3. `.env` を元の `SUPABASE_KEY` に戻す

## Open Questions

1. **将来的な拡張**: 他のStorageバケットでも同様の問題が発生する可能性があるか？
   - 現時点では `profile-photos` と `receiver-profile-photos` のみ該当
   - 新規バケット追加時は `get_storage_url()` を使用することで対応可能

2. **テスト環境**: ステージング環境での動作は？
   - ステージングURLのパターンに応じて `is_local_environment()` を調整可能
