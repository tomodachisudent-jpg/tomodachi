## Backend Tasks

### Task 1: 共通ユーティリティ関数の作成

- [x] 1.1 `apis/utils.py` を新規作成
- [x] 1.2 `is_local_environment()` 関数を実装（SUPABASE_URLに基づく環境判定）
- [x] 1.3 `get_storage_url()` 関数を実装（環境に応じたURL生成）

### Task 2: provider.py の修正

- [x] 2.1 `from .utils import get_storage_url` をインポートに追加
- [x] 2.2 `upload_profile_photo()` 関数で `get_public_url()` の代わりに `get_storage_url()` を使用
- [x] 2.3 ローカル環境で動作確認

### Task 3: receiver_profile.py の修正

- [x] 3.1 `from .utils import get_storage_url` をインポートに追加
- [x] 3.2 `upload_receiver_profile_photo()` 関数で相対パス生成を `get_storage_url()` に置き換え
- [x] 3.3 ローカル環境で動作確認

### Task 4: 環境変数の修正

- [x] 4.1 `.env` の `SUPABASE_KEY` を `SUPABASE_SERVICE_ROLE_KEY` に変更
- [x] 4.2 DevContainerで環境変数が正しく読み込まれることを確認

## Testing Tasks

### Task 5: ローカル環境でのテスト

- [x] 5.1 provider.py で画像アップロードが成功することを確認
- [x] 5.2 アップロードした画像がプロフィール画面で表示されることを確認
- [x] 5.3 receiver_profile.py で画像アップロードが成功することを確認
- [x] 5.4 アップロードした画像が生徒プロフィール画面で表示されることを確認

### Task 6: 本番環境での検証（デプロイ後）

- [ ] 6.1 provider.py で画像アップロードが成功することを確認
- [ ] 6.2 アップロードした画像が正しく表示されることを確認
- [ ] 6.3 receiver_profile.py で画像アップロードが成功することを確認

## Documentation Tasks

### Task 7: OpenSpecドキュメントの作成

- [x] 7.1 `.openspec.yaml` を作成
- [x] 7.2 `proposal.md` を作成
- [x] 7.3 `design.md` を作成
- [x] 7.4 `tasks.md` を作成（本ファイル）
- [x] 7.5 `specs/storage-utils/spec.md` を作成

## Archive Tasks

### Task 8: 変更のアーカイブ

- [x] 8.1 OpenSpecファイルを `openspec/changes/archive/2026-02-02-storage-url-utils/` に配置
- [x] 8.2 実装の完了を確認
