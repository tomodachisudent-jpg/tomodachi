## Why

ローカル開発環境（DevContainer）で Supabase Storage にアップロードした画像が表示できない問題が発生していた。原因は以下の通り：

1. **provider.py**（講師用）: `get_public_url()` で絶対URLを返却 → ローカルでは `http://172.17.0.1:54321/...` となり、ブラウザからアクセス不可
2. **receiver_profile.py**（生徒用）: 相対パス `/storage/v1/object/public/...` を返却 → quasar.config.js のプロキシ経由でアクセス可能

本番環境（Koyeb）では両方とも正常に動作していたが、ローカル環境でのみ問題が発生していた。また、環境変数名の不一致（`SUPABASE_KEY` vs `SUPABASE_SERVICE_ROLE_KEY`）も原因の一つだった。

## What Changes

### Backend API
- **新規**: `apis/utils.py` - Storage URL生成の共通ユーティリティ関数
  - `is_local_environment()`: SUPABASE_URL に基づいてローカル環境を判定
  - `get_storage_url()`: 環境に応じて絶対URL（本番）または相対パス（ローカル）を返却
  
- **修正**: `apis/provider.py` - 画像アップロード処理
  - `get_storage_url()` を使用するように変更
  - `get_public_url()` の代わりに共通関数を使用
  
- **修正**: `apis/receiver_profile.py` - 画像アップロード処理
  - `get_storage_url()` を使用するように変更
  - 共通関数による一元化

### 環境変数設定
- **修正**: `.env` - 環境変数名を統一
  - `SUPABASE_KEY` → `SUPABASE_SERVICE_ROLE_KEY` に変更
  - `.env.dev` との整合性を取る

## Capabilities

### New Capabilities
- `storage-utils`: 環境に応じたStorage URL生成機能
  - ローカル環境: 相対パス `/storage/v1/object/public/{bucket}/{file}`
  - 本番環境: 絶対URL `https://xxx.supabase.co/storage/v1/object/public/{bucket}/{file}`

### Modified Capabilities
- `provider-photo-upload`: 講師プロフィール画像アップロードのURL生成を共通関数に統一
- `receiver-profile-photo-upload`: 生徒プロフィール画像アップロードのURL生成を共通関数に統一

## Impact

**影響を受けるファイル**:
- `apis/utils.py`: 新規作成（共通関数定義）
- `apis/provider.py`: 画像アップロード処理の修正
- `apis/receiver_profile.py`: 画像アップロード処理の修正
- `.env`: 環境変数名の変更（`SUPABASE_KEY` → `SUPABASE_SERVICE_ROLE_KEY`）

**破壊的変更**:
- なし（内部実装の変更のみ、APIインターフェースは変更なし）

**データ移行**:
- なし（既存の画像URLはそのまま保持）
