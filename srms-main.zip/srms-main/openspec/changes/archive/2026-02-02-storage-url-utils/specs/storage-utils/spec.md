# Storage URL Utils 仕様

## 概要

Supabase Storage にアップロードしたファイルのURLを、環境に応じて適切な形式（絶対URLまたは相対パス）で生成する共通ユーティリティ。

## 背景

- ローカル開発環境（DevContainer）では、Supabaseが `http://172.17.0.1:54321` で動作
- ブラウザ（ホスト側）からは `172.17.0.1` にアクセスできない
- Quasar開発サーバーのプロキシ設定（`/storage/*` → Supabase）を活用する必要がある
- 本番環境では絶対URLが必要（nginx.conf にプロキシ設定がないため）

## 仕様詳細

### 関数: `is_local_environment()`

**目的**: 現在の環境がローカル開発環境かどうかを判定

**実装**:
```python
def is_local_environment() -> bool:
    supabase_url = os.getenv("SUPABASE_URL", "")
    return any(x in supabase_url for x in ["localhost", "172.17.0.1", "127.0.0.1"])
```

**判定基準**:
- SUPABASE_URL に `localhost` が含まれる → ローカル環境
- SUPABASE_URL に `172.17.0.1` が含まれる → ローカル環境（Docker Bridge）
- SUPABASE_URL に `127.0.0.1` が含まれる → ローカル環境
- それ以外（通常は `https://xxx.supabase.co`）→ 本番環境

### 関数: `get_storage_url()`

**目的**: 環境に応じたStorage URLを生成

**シグネチャ**:
```python
def get_storage_url(bucket_name: str, file_name: str) -> str
```

**引数**:
- `bucket_name`: Supabase Storage のバケット名（例: `"profile-photos"`, `"receiver-profile-photos"`）
- `file_name`: アップロードされたファイル名（例: `"profile_1234567890.jpg"`）

**戻り値**:
- ローカル環境: 相対パス（例: `/storage/v1/object/public/profile-photos/profile_1234567890.jpg`）
- 本番環境: 絶対URL（例: `https://xxx.supabase.co/storage/v1/object/public/profile-photos/profile_1234567890.jpg`）

**実装**:
```python
def get_storage_url(bucket_name: str, file_name: str) -> str:
    if is_local_environment():
        # ローカル: 相対パス（開発サーバーのプロキシ経由でアクセス）
        return f"/storage/v1/object/public/{bucket_name}/{file_name}"
    else:
        # 本番: 絶対URL（ブラウザから直接アクセス可能）
        supabase_url = os.getenv("SUPABASE_URL", "").rstrip("/")
        return f"{supabase_url}/storage/v1/object/public/{bucket_name}/{file_name}"
```

## 使用例

### provider.py（講師プロフィール画像）

```python
from .utils import get_storage_url

@router.post("/api/provider/photo-upload")
async def upload_profile_photo(file: UploadFile = File(...)):
    # ... アップロード処理 ...
    
    # 環境に応じたURLを生成
    photo_url = get_storage_url("profile-photos", file_name)
    return {"status": "success", "url": photo_url}
```

### receiver_profile.py（生徒プロフィール画像）

```python
from .utils import get_storage_url

@router.post("/api/receiver/profile-photo")
async def upload_receiver_profile_photo(file: UploadFile = File(...)):
    # ... アップロード処理 ...
    
    # 環境に応じたURLを生成
    profile_photo_url = get_storage_url("receiver-profile-photos", file_name)
    return {"status": "success", "url": profile_photo_url}
```

## 環境ごとの動作

### ローカル環境（DevContainer）

**環境変数**:
```bash
SUPABASE_URL=http://172.17.0.1:54321
```

**URL生成結果**:
```
/storage/v1/object/public/profile-photos/profile_1234567890.jpg
```

**アクセスフロー**:
1. ブラウザが `http://localhost:9000/storage/v1/object/public/...` をリクエスト
2. Quasar開発サーバーのプロキシが `http://172.17.0.1:54321/storage/v1/object/public/...` に転送
3. Supabase Storage が画像を返却

### 本番環境（Koyeb）

**環境変数**:
```bash
SUPABASE_URL=https://xxx.supabase.co
```

**URL生成結果**:
```
https://xxx.supabase.co/storage/v1/object/public/profile-photos/profile_1234567890.jpg
```

**アクセスフロー**:
1. ブラウザが `https://xxx.supabase.co/storage/v1/object/public/...` を直接リクエスト
2. Supabase Storage が画像を返却

## 注意事項

1. **環境変数の依存**: `SUPABASE_URL` 環境変数が正しく設定されている必要がある
2. **本番環境のnginx**: nginx.conf に `/storage/` へのプロキシ設定がないため、絶対URLが必須
3. **将来的な拡張**: 新規Storageバケット追加時も `get_storage_url()` を使用することで対応可能
