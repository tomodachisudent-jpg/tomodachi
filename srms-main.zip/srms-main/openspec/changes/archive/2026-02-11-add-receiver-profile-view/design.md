## Context

SRMSプロジェクトは、先生（provider）と生徒（receiver）のマッチングおよび予約管理を行うシステムです。現在、先生のプロフィール閲覧機能（ProviderProfileView.vue）は実装済みですが、生徒プロフィール閲覧機能は存在しません。

**現在の技術スタック:**
- フロントエンド: Vue 3 (Composition API) + Quasar Framework v2.16.0 + Pinia
- バックエンド: FastAPI (Python) + psycopg2（raw SQL）
- データベース: PostgreSQL (Supabase) + Row Level Security (RLS)
- 認証: JWT Bearer Token

**既存実装:**
- `ProviderProfileView.vue`: 先生プロフィール閲覧ページ（参考実装）
- `ReceiverProfile.vue`: 生徒プロフィール編集ページ（既存）
- `apis/receiver_profile.py`: 生徒プロフィールAPI（既存、編集用エンドポイントのみ）
- `receiver_profiles` テーブル: 生徒プロフィール情報（既存）

**制約:**
- 既存のVue 3 + Quasarパターンに厳密に従う
- ProviderProfileView.vueと同じCard-basedレイアウトを使用
- 認証・認可は既存のJWT + RLSパターンを踏襲
- データベーススキーマ変更なし

## Goals / Non-Goals

**Goals:**
- providerロールが任意の生徒のプロフィールを閲覧できる
- 既存のProviderProfileView.vueと同様のUIパターンで統一性を保つ
- 最小限の変更で実装（新規ファイル1つ + 既存3ファイル修正）
- 既存のreceiver_profilesテーブルを活用

**Non-Goals:**
- 生徒プロフィールの編集機能（ReceiverProfile.vueで既に実装済み）
- アクセス制御の細分化（自分の生徒のみ閲覧可能等）
- プロフィール検索・フィルタリング機能
- データベーススキーマの変更

## Decisions

### Decision 1: ProviderProfileView.vueをベースにする
**選択肢:**
- A. ProviderProfileView.vueの構造をコピーしてフィールドのみ変更
- B. 新規に独自のコンポーネント構造を設計

**選択: A**

**理由:**
- 既存のProviderProfileView.vueは同様の要件（プロフィール閲覧）を実装済み
- UIの一貫性を保ちやすい
- 開発時間を削減できる
- Vue 3 + Quasarのベストプラクティスが既に適用されている

### Decision 2: APIエンドポイントをreceiver_profile.pyに追加
**選択肢:**
- A. receiver_profile.pyに追加
- B. 新規にreceiver_view.pyを作成

**選択: A**

**理由:**
- receiver関連のAPIは既にreceiver_profile.pyにまとめられている
- ファイル数を増やさない
- provider.pyも同様の構造（編集と閲覧を同じファイルに配置）

### Decision 3: 認証は必須、アクセス制限はなし
**選択肢:**
- A. providerロールなら全生徒を閲覧可能
- B. 予約関係のある生徒のみ閲覧可能に制限

**選択: A**

**理由:**
- 仕様上、先生は全生徒のプロフィールを見られる必要がある（予約前の確認用）
- 制限を追加する場合は別途要件として定義すべき
- 実装がシンプル（JWTのroleチェックのみ）

### Decision 4: データ取得はraw SQLを使用
**選択肢:**
- A. psycopg2でraw SQL（既存パターン）
- B. SQLAlchemyなどのORMを導入

**選択: A**

**理由:**
- 既存のprovider.pyと同じパターン
- プロジェクト全体でraw SQLが使用されている
- シンプルなSELECT文のみなのでORMは不要

## Risks / Trade-offs

### Risk 1: プロフィール写真の欠損
**リスク:** receiver_profilesテーブルでprofile_photo_urlが必須だが、既存データで未設定の可能性
**対策:** 
- フロントエンドでフォールバック処理（`/images/default-profile.png`）
- `profile_photo_url || defaultPhoto` パターンを使用

### Risk 2: オプション項目の表示制御
**リスク:** learning_history, qualifications, special_skillsが未入力の場合の表示
**対策:** 
- `v-if="profile.learning_history"` でnull/空文字チェック
- 各オプション項目を個別に制御

### Risk 3: receiver_idの不正な指定
**リスク:** 存在しないreceiver_idがURLパラメータで渡される
**対策:**
- APIは空オブジェクト `{}` を返す（エラーにしない）
- フロントエンドで「プロフィールが見つかりません」メッセージを表示

### Trade-off: 全生徒閲覧可能 vs アクセス制限
**選択:** 全生徒閲覧可能
**トレードオフ:**
- 柔軟性が高い（予約前の生徒プロフィール確認可能）
- セキュリティ面で緩い（providerなら誰のプロフィールでも閲覧可能）
- 将来的にアクセス制限が必要になった場合は追加実装が必要

## Migration Plan

**デプロイ手順:**
1. バックエンドAPI追加（`apis/receiver_profile.py`）
2. フロントエンドページ・ルーティング追加
3. メニュー項目追加
4. 動作確認（開発環境）
5. 本番デプロイ

**ロールバック戦略:**
- 新規エンドポイント・ページ追加のみなので、既存機能への影響なし
- ロールバック時は新規ルートとメニュー項目を削除

**破壊的変更:** なし

## Open Questions

- ✅ 生徒プロフィール一覧ページは必要か？ → 本changeでは不要（将来対応）
- ✅ receiver_idはどこから取得するか？ → URLパラメータ `?id={receiver_id}` で渡す想定
