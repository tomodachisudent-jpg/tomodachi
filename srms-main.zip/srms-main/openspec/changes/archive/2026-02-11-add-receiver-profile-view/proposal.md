## Why

SRMSシステムで先生（provider）が生徒（receiver）のプロフィールを閲覧できる機能が必要です。現在、先生のプロフィールは閲覧可能ですが、生徒のプロフィールを閲覧する手段がありません。この機能により、先生は生徒の背景（年齢、国籍、日本語レベル、学習目標等）を把握し、より適切な指導を行うことができます。

## What Changes

- **新規ページ追加**: `ReceiverProfileView.vue` - 生徒プロフィール閲覧専用ページ
- **API追加**: `GET /api/receiver/profile/{receiver_id}` - 特定生徒のプロフィール取得エンドポイント
- **ルーティング追加**: `/receiver/profile-view` - 生徒プロフィール閲覧用ルート
- **メニュー追加**: 先生向けメニューに「生徒プロフィール閲覧」項目を追加

## Capabilities

### New Capabilities
- `receiver-profile-view`: 生徒プロフィール閲覧機能。providerロールのユーザーがreceiverのプロフィール情報を閲覧できる機能。表示項目：名前、年齢、性別、国籍、自己紹介、学習目標、学習歴、資格、特技、日本語レベル、プロフィール写真。

### Modified Capabilities
- （既存の仕様変更なし - 新機能追加のみ）

## Impact

- **フロントエンド**: 
  - 新規ファイル: `ui/src/pages/ReceiverProfileView.vue`
  - 修正: `ui/src/router/routes.js`（ルート追加）
  - 修正: `ui/src/layouts/MainLayout.vue`（メニュー追加）
  
- **バックエンド**:
  - 修正: `apis/receiver_profile.py`（APIエンドポイント追加）
  
- **データベース**:
  - 変更なし（既存の`receiver_profiles`テーブルを使用）
  
- **認証・認可**:
  - providerロールが対象
  - JWT認証必須
  - 全生徒のプロフィールを閲覧可能（自分の生徒に限定しない）
