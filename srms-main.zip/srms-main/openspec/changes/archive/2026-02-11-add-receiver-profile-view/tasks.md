## 1. バックエンドAPI実装

- [ ] 1.1 apis/receiver_profile.py に GET /api/receiver/profile/{receiver_id} エンドポイントを追加
- [ ] 1.2 エンドポイントでJWT認証を必須化（Depends(get_current_user)）
- [ ] 1.3 psycopg2でreceiver_profilesテーブルからデータ取得するSQLクエリを実装
- [ ] 1.4 存在しないreceiver_idの場合は空オブジェクト {} を返すように実装
- [ ] 1.5 FastAPIのレスポンススキーマを確認（既存のReceiverProfileスキーマを使用）

## 2. フロントエンド - ページ作成

- [ ] 2.1 ui/src/pages/ReceiverProfileView.vue を新規作成
- [ ] 2.2 ProviderProfileView.vue の構造をベースにコピー
- [ ] 2.3 Vue 3 Composition API (setup script) で実装
- [ ] 2.4 receiver_profilesテーブルのフィールドに合わせてテンプレートを修正
- [ ] 2.5 必須表示項目（name, age, gender, nationality, self_introduction, learning_goals, japanese_level, profile_photo_url）を実装
- [ ] 2.6 オプション表示項目（learning_history, qualifications, special_skills）をv-ifで条件表示
- [ ] 2.7 プロフィール写真のフォールバック処理を実装（profile_photo_url || '/images/default-profile.png'）

## 3. フロントエンド - データ取得

- [ ] 3.1 URLパラメータから receiver_id を取得（useRoute().query.id）
- [ ] 3.2 onMountedフックでAPIリクエストを実装
- [ ] 3.3 axios.get(`/api/receiver/profile/${receiverId}`) でデータ取得
- [ ] 3.4 レスポンスデータをreactiveなprofile変数にバインド（Object.assign）
- [ ] 3.5 エラーハンドリング実装（try-catchでconsole.error）

## 4. ルーティング設定

- [ ] 4.1 ui/src/router/routes.js を開く
- [ ] 4.2 /receiver/profile-view ルートを追加
- [ ] 4.3 ReceiverProfileView.vueをlazy import
- [ ] 4.4 meta.requiresAuth = true を設定
- [ ] 4.5 meta.roles = ['provider'] を設定

## 5. ナビゲーションメニュー追加

- [ ] 5.1 ui/src/layouts/MainLayout.vue を開く
- [ ] 5.2 providerLinks 配列に新規メニュー項目を追加
- [ ] 5.3 title: '生徒プロフィール閲覧', icon: 'school', link: '/receiver/profile-view' を設定

## 6. UI/UXの調整

- [ ] 6.1 Quasar q-page, q-card, q-card-section の構造を確認
- [ ] 6.2 Card-basedレイアウトでProviderProfileView.vueと一貫性を保つ
- [ ] 6.3 q-img コンポーネントでプロフィール写真表示（max-width: 200px, border-radius: 8px）
- [ ] 6.4 q-input (readonly) でテキスト項目表示
- [ ] 6.5 japanese_level フィールドの表示を確認（初心者/中級者/上級者）

## 7. テスト・動作確認

- [x] 7.1 開発環境で先生ロールでログイン
- [x] 7.2 メニューに「生徒プロフィール閲覧」が表示されることを確認 → 廃止
- [x] 7.3 有効なreceiver_idを指定してプロフィールページにアクセス
- [x] 7.4 全ての必須項目が正しく表示されることを確認
- [x] 7.5 オプション項目（learning_history等）の条件表示を確認
- [x] 7.6 存在しないreceiver_idでアクセスして空データのハンドリングを確認 → 生徒が存在しない旨のメッセージを表示させる
- [x] 7.7 未認証でアクセスしてリダイレクトされることを確認
- [x] 7.8 receiverロールでアクセスしてアクセス拒否されることを確認
