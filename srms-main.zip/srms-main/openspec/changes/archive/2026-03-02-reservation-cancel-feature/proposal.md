## Why

予約一覧画面にキャンセル機能が存在しないため、生徒が予約をキャンセルする手段がない。
また、無制限キャンセルや直前キャンセルによる運営への影響を防ぐため、月次上限・キャンセル料ルールの適用と通知連携が必要である。

## What Changes

- 予約一覧画面からキャンセルボタンを押してキャンセルできるようにする
- キャンセル確認ダイアログでキャンセル料の有無を生徒に表示・認識させてから実行する
- 生徒のキャンセル回数を月3回に制限する（上限到達時はキャンセル不可）
- キャンセル時に受講者・講師へLINEおよびメールで通知する
- 予約一覧画面に過去の予約を非表示にするトグルスイッチを追加する
- `reservations` テーブルに `canceled_at` カラムを追加し、キャンセル月を正確に記録する

## Capabilities

### New Capabilities

- `reservation-cancel`: 予約一覧からのキャンセル操作、キャンセル料確認ダイアログ、月次上限チェック、キャンセル通知（LINE/メール）
- `reservation-list-filter`: 予約一覧の過去予約トグルフィルタ、今月のキャンセル回数表示

### Modified Capabilities

（なし）

## Impact

- **バックエンド**: `apis/receiver.py`（キャンセルAPIへの月次制限・通知追加、一覧APIのフィルタ対応、キャンセル回数取得API新設）
- **バックエンド**: `apis/crud/reservations.py`（キャンセル回数クエリ、日付フィルタクエリ追加）
- **フロントエンド**: `ui/src/pages/ReceiverReservations.vue`（キャンセルボタン、確認ダイアログ、トグルフィルタ、回数バナー追加）
- **DB**: `supabase/schema.sql`（`reservations.canceled_at` カラム追加）
- **外部サービス**: LINE Messaging API / Mailjet（既存サービス、新規メッセージを追加）
