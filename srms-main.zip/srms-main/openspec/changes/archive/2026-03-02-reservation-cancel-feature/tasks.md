## 1. DBマイグレーション

- [x] 1.1 `supabase/schema.sql` の `reservations` テーブルに `canceled_at TIMESTAMP WITH TIME ZONE NULL` カラムを追加する
- [x] 1.2 Supabase上で `ALTER TABLE reservations ADD COLUMN canceled_at TIMESTAMP WITH TIME ZONE NULL;` を実行する

## 2. バックエンド: CRUD層の追加

- [x] 2.1 `apis/crud/reservations.py` に当月キャンセル回数取得関数 `get_monthly_cancel_count(db, receiver_id, month)` を追加する（`canceled_at` の暦月でカウント）
- [x] 2.2 `apis/crud/reservations.py` に reservation_id ベースでキャンセル対象予約を取得する関数 `get_reservation_by_id(db, reservation_id, receiver_id)` を追加する

## 3. バックエンド: キャンセルAPI新設

- [x] 3.1 `apis/receiver.py` に `POST /api/receiver/reservations/{reservation_id}/cancel` エンドポイントを新設する
- [x] 3.2 月次キャンセル上限チェック（3回）をエンドポイントに実装し、超過時は HTTP 400 と「今月のキャンセル上限（3回）に達しています。キャンセルをご希望の場合は、運営にお問い合わせください。」メッセージを返す
- [x] 3.3 `reservations.status = 'canceled'`、`reservations.canceled_at = UTC現在時刻` の更新処理を実装する
- [x] 3.4 対応する `shifts.is_locked = false` の更新処理を実装する
- [x] 3.5 キャンセル通知用の予約情報（生徒・講師のLINE ID / メールアドレス / 日時 / 形式）をクエリで取得する処理を実装する
- [x] 3.6 受講者（生徒）へのLINE通知メッセージを作成・送信する（`send_line_notification` 使用）
- [x] 3.7 受講者（生徒）へのキャンセル確認メール本文・件名を作成・送信する（`send_mailjet_email` 使用）
- [x] 3.8 講師へのLINE通知メッセージを作成・送信する
- [x] 3.9 講師へのキャンセル通知メール本文・件名を作成・送信する
- [x] 3.10 通知処理全体を try/except で囲み、失敗してもキャンセル本体に影響しないようにする

## 4. バックエンド: キャンセル回数取得API新設

- [x] 4.1 `apis/receiver.py` に `GET /api/receiver/cancel-count` エンドポイントを新設する（クエリパラメータ `month=YYYY-MM` 省略時は当月）
- [x] 4.2 当月の `canceled_at` ベースのキャンセル回数と上限（3）を返す `{ "count": N, "limit": 3 }` レスポンスを実装する

## 5. フロントエンド: 予約一覧画面の改修

- [x] 5.1 `ui/src/pages/ReceiverReservations.vue` にマウント時のキャンセル回数APIコール（`GET /api/receiver/cancel-count`）を追加する
- [x] 5.2 画面上部に「今月のキャンセル回数: ○回 / 3回」バナー（`q-banner` または `q-card`）を追加する
- [x] 5.3 テーブルに「キャンセル」ボタン列を追加する（`status === 'reserved'` の行のみ表示）
- [x] 5.4 月次上限到達時はキャンセルボタンを非活性（`disable`）にし、ツールチップで「今月のキャンセル上限に達しました。キャンセルをご希望の場合は、運営にお問い合わせください。」を表示する
- [x] 5.5 トグルスイッチ「過去の予約を表示する」をテーブル上部に追加する
- [x] 5.6 トグルOFF時は `start_at` が本日未満の予約を表示データからフィルタする算出プロパティを実装する

## 6. フロントエンド: キャンセル確認ダイアログの実装

- [x] 6.1 `q-dialog` を使ったキャンセル確認ダイアログコンポーネントを `ReceiverReservations.vue` 内に実装する
- [x] 6.2 ダイアログに予約詳細（日時・形式・講師名）を表示する
- [x] 6.3 `start_at`・`s_type`・現在時刻からキャンセル料区分（無料 / 20% / 全額）を判定するロジックを実装する
- [x] 6.4 判定結果に応じてダイアログにキャンセル料案内を表示する（無料=通常、20%=警告色、全額=強調警告色）
- [x] 6.5 「キャンセルする」ボタン押下時に `POST /api/receiver/reservations/{id}/cancel` を呼び出す処理を実装する
- [x] 6.6 キャンセル成功後、予約一覧データとキャンセル回数を再取得（またはローカル更新）する処理を実装する
- [x] 6.7 APIエラー時（上限超過等）のエラーメッセージを `q-notify` で表示する処理を実装する（上限超過時は「今月のキャンセル上限（3回）に達しています。キャンセルをご希望の場合は、運営にお問い合わせください。」と表示）
