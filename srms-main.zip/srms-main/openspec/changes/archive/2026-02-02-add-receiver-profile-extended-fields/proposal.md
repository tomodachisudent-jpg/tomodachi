## Why

生徒（receiver）の詳細情報を収集し、より良いマッチングと学習支援を実現するため、プロフィール登録画面に追加項目が必要。現在の基本情報（名前、年齢、性別等）に加えて、顔写真、学習歴、資格、特技、日本語レベルを登録できるようにすることで、講師と生徒のマッチング精度を向上させる。

## What Changes

- **データベース**: `receiver_profiles` テーブルに以下のカラムを追加
  - `profile_photo_url` (text): 顔写真の URL（必須）
  - `learning_history` (text): 学習歴（任意）
  - `qualifications` (text): 資格（任意）
  - `special_skills` (text): 特技（任意）
  - `japanese_level` (text): 日本語のレベル（任意、"初心者"/"中級者"/"上級者"）

- **Supabase Storage**: 生徒専用の顔写真バケット `receiver-profile-photos` を新規作成
  - 公開アクセス可能に設定
  - RLS ポリシーで自分のファイルのみアップロード可能に制限

- **Backend API**: 
  - `ReceiverProfile` Pydantic スキーマに新規フィールドを追加
  - `POST /api/receiver/profile-photo` エンドポイントを新規追加（画像アップロード用）
  - 既存の `POST /api/receiver/profile` エンドポイントを拡張して新規フィールドに対応
  - 顔写真の必須バリデーションを追加

- **Frontend**:
  - `ReceiverProfile.vue` に以下のフォーム項目を追加
    - 顔写真アップロード（File input + プレビュー表示、必須）
    - 学習歴（textarea、任意）
    - 資格（textarea、任意）
    - 特技（textarea、任意）
    - 日本語のレベル（select、任意）
  - 画像アップロードコンポーネントを抽象化し、将来のカメラ自撮り機能に対応できる設計にする
  - 顔写真未アップロード時の保存ボタン無効化

## Capabilities

### New Capabilities
<!-- なし：既存の receiver-profile 機能の拡張のみ -->

### Modified Capabilities
- `receiver-profile`: 生徒プロフィール登録・編集機能に、顔写真（必須）、学習歴、資格、特技、日本語レベルの各フィールドを追加。顔写真は Supabase Storage にアップロードし、URL をデータベースに保存する。顔写真が未アップロードの場合はプロフィール保存を許可しない。

## Impact

**影響を受けるファイル**:
- `supabase/schema.sql`: `receiver_profiles` テーブル定義の変更
- `supabase/migrations/`: 新規マイグレーションファイルの追加
- `apis/schemas.py`: `ReceiverProfile` クラスの拡張
- `apis/receiver_profile.py`: API エンドポイントの拡張と新規追加
- `ui/src/pages/ReceiverProfile.vue`: フォーム項目の追加と画像アップロード機能の実装

**依存関係**:
- Supabase Storage の設定が必要（新規バケット `receiver-profile-photos` の作成）
- 既存の `profile-photos` バケット（provider 用）とは別に生徒専用バケットを作成

**データ移行**:
- 既存の `receiver_profiles` レコードには新規フィールドは NULL または空文字として追加される
- 既存ユーザーは次回プロフィール編集時に顔写真のアップロードが必須となる

**破壊的変更**:
- なし（新規フィールドは任意または段階的に必須化可能）
