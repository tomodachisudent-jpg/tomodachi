# Implementation Tasks

生徒プロフィール拡張（顔写真・追加情報）の実装タスク一覧

---

## 1. データベースマイグレーション

- [ ] 1.1 Supabase マイグレーションファイルを作成（`npx supabase db diff -f add_receiver_profile_extended_fields`）
- [ ] 1.2 `receiver_profiles` テーブルに 5 つの新規カラム（`profile_photo_url`, `learning_history`, `qualifications`, `special_skills`, `japanese_level`）を追加する SQL を記述
- [ ] 1.3 マイグレーションを実行してローカル DB に反映
- [ ] 1.4 `\d receiver_profiles` でテーブル構造を確認し、新規カラムが追加されていることを検証

---

## 2. Supabase Storage バケット設定

- [ ] 2.1 Supabase ダッシュボードで新規バケット `receiver-profile-photos` を作成
- [ ] 2.2 バケットの公開アクセスを有効化（Public bucket 設定）
- [ ] 2.3 RLS ポリシーを設定（認証済みユーザーが自分のファイルのみアップロード可能）
- [ ] 2.4 手動で画像をアップロードし、公開 URL でアクセスできることを確認

---

## 3. バックエンド: Pydantic スキーマ拡張

- [ ] 3.1 `apis/schemas.py` の `ReceiverProfile` クラスに 5 つの新規フィールドを追加
  - `profile_photo_url: str`（必須）
  - `learning_history: Optional[str] = None`
  - `qualifications: Optional[str] = None`
  - `special_skills: Optional[str] = None`
  - `japanese_level: Optional[str] = None`
- [ ] 3.2 `profile_photo_url` のバリデータを追加（空文字チェック: `ValueError("顔写真をアップロードしてください")`）
- [ ] 3.3 既存のバリデータ（`name`, `age`）が正常に動作することを確認

---

## 4. バックエンド: 画像アップロード API 実装

- [ ] 4.1 `apis/receiver_profile.py` に `POST /api/receiver/profile-photo` エンドポイントを追加
- [ ] 4.2 ファイル形式検証（jpg, jpeg, png, gif のみ許可）を実装
- [ ] 4.3 ファイルサイズ検証（5MB 以下）を実装
- [ ] 4.4 `user_id` を含むファイル名（`receiver_{user_id}_{timestamp}.{ext}`）を生成
- [ ] 4.5 Supabase Storage の `receiver-profile-photos` バケットにアップロード
- [ ] 4.6 公開 URL を取得し、`{"status": "success", "url": public_url}` を返却
- [ ] 4.7 エラーハンドリング（アップロード失敗時に `HTTPException` を raise）を実装
- [ ] 4.8 `require_role('receiver')` の依存関係を追加（認証済み生徒のみアクセス可能）

---

## 5. バックエンド: プロフィール保存 API 拡張

- [ ] 5.1 `apis/receiver_profile.py` の `save_receiver_profile()` 関数を拡張
- [ ] 5.2 UPDATE クエリに新規フィールド（`profile_photo_url`, `learning_history`, `qualifications`, `special_skills`, `japanese_level`）を追加
- [ ] 5.3 INSERT クエリに新規フィールドを追加
- [ ] 5.4 既存のプロフィールデータ取得（`get_receiver_profile()`）が新規フィールドを返すことを確認

---

## 6. フロントエンド: 画像アップロードコンポーネント実装

- [ ] 6.1 `ui/src/pages/ReceiverProfile.vue` に画像アップロードセクションを追加
- [ ] 6.2 `<q-file>` または `<input type="file">` で画像ファイル選択機能を実装
- [ ] 6.3 `accept="image/jpeg,image/png,image/gif"` 属性でファイル形式を制限
- [ ] 6.4 選択した画像のプレビュー表示機能を実装（Data URL を使用）
- [ ] 6.5 アップロードボタンをクリックして `POST /api/receiver/profile-photo` を呼び出す処理を実装
- [ ] 6.6 アップロード成功時に公開 URL を `profile.profile_photo_url` に保存
- [ ] 6.7 アップロード中のローディング表示を実装
- [ ] 6.8 アップロードエラー時の通知表示を実装（`$q.notify` を使用）

---

## 7. フロントエンド: 新規フォームフィールド追加

- [ ] 7.1 学習歴フィールドを追加（`<q-input type="textarea" v-model="profile.learning_history" />`）
- [ ] 7.2 資格フィールドを追加（`<q-input type="textarea" v-model="profile.qualifications" />`）
- [ ] 7.3 特技フィールドを追加（`<q-input type="textarea" v-model="profile.special_skills" />`）
- [ ] 7.4 日本語のレベルフィールドを追加（`<q-select v-model="profile.japanese_level" :options="['初心者', '中級者', '上級者']" clearable />`）
- [ ] 7.5 各フィールドに適切なラベルとプレースホルダーを設定

---

## 8. フロントエンド: 保存ボタン制御

- [ ] 8.1 `profile.profile_photo_url` が空の場合、保存ボタンを無効化（`:disable="!profile.profile_photo_url"`）
- [ ] 8.2 顔写真未アップロード時にエラーメッセージを表示（「顔写真をアップロードしてください」）
- [ ] 8.3 保存ボタンクリック時、新規フィールドを含むペイロードを作成
- [ ] 8.4 `POST /api/receiver/profile` を呼び出してプロフィールを保存

---

## 9. フロントエンド: 既存プロフィール読み込み対応

- [ ] 9.1 `onMounted` で `GET /api/receiver/profile` を呼び出し、新規フィールドを含むデータを読み込む
- [ ] 9.2 `profile_photo_url` が存在する場合、画像プレビューを表示
- [ ] 9.3 他の新規フィールド（学習歴、資格、特技、日本語レベル）をフォームに反映

---

## 10. エラーハンドリングとバリデーション

- [ ] 10.1 画像ファイル形式が不正な場合のエラーメッセージを実装（フロントエンド）
- [ ] 10.2 ファイルサイズが 5MB を超える場合のエラーメッセージを実装（フロントエンド）
- [ ] 10.3 バックエンドの顔写真必須バリデーションが正しく動作することを確認
- [ ] 10.4 既存のバリデーション（名前必須、年齢数値）が正常に動作することを確認

---

## 11. 手動テスト

- [ ] 11.1 新規ユーザーでプロフィール登録テスト
  - 顔写真をアップロードせずに保存ボタンが無効であることを確認
  - 顔写真をアップロード後、保存ボタンが有効になることを確認
  - 全フィールドを入力して保存成功を確認
- [ ] 11.2 既存ユーザー（顔写真なし）でプロフィール編集テスト
  - プロフィール編集画面にアクセスし、既存データが表示されることを確認
  - 顔写真をアップロードして保存成功を確認
- [ ] 11.3 画像アップロードエラーケーステスト
  - 不正なファイル形式（PDF 等）をアップロードしてエラーが表示されることを確認
  - 大きすぎるファイル（5MB 超）をアップロードしてエラーが表示されることを確認
- [ ] 11.4 顔写真の差し替えテスト
  - 既存の顔写真を新しい画像に差し替えて保存成功を確認
- [ ] 11.5 任意フィールドのテスト
  - 学習歴、資格、特技、日本語レベルを空のまま保存できることを確認
  - 各フィールドに値を入力して保存後、再読み込みで値が保持されることを確認
- [ ] 11.6 日本語レベルの選択肢テスト
  - セレクトボックスで「初心者」「中級者」「上級者」が選択できることを確認
  - 選択肢をクリアして空にできることを確認

---

## 12. セキュリティとアクセス制御

- [ ] 12.1 `POST /api/receiver/profile-photo` に認証チェック（`require_role('receiver')`）が適用されていることを確認
- [ ] 12.2 講師ロールのユーザーが生徒用エンドポイントにアクセスできないことを確認（403 エラー）
- [ ] 12.3 Supabase Storage の RLS ポリシーが正しく動作することを確認（他のユーザーのファイルにアクセスできない）

---

## 13. ドキュメント更新（オプション）

- [ ] 13.1 `README.md` のプロフィール機能説明を更新（新規フィールドを追記）
- [ ] 13.2 API エンドポイント一覧に `POST /api/receiver/profile-photo` を追加
- [ ] 13.3 データベーススキーマドキュメントに新規カラムを追記

---

## 14. 本番環境へのデプロイ準備

- [ ] 14.1 本番環境の Supabase でマイグレーションを実行
- [ ] 14.2 本番環境の Supabase で `receiver-profile-photos` バケットを作成
- [ ] 14.3 本番環境で RLS ポリシーを設定
- [ ] 14.4 Docker イメージをビルドしてデプロイ
- [ ] 14.5 本番環境で動作確認（画像アップロード、プロフィール保存）
