## Context

現在の `receiver_profiles` テーブルには基本的なプロフィール情報（名前、年齢、性別、国籍、自己紹介、学習目的）のみが格納されている。講師と生徒のマッチング精度を向上させるため、顔写真、学習歴、資格、特技、日本語レベルの追加情報が必要となった。

**現状の制約**:
- Backend: FastAPI + PostgreSQL (Supabase)
- Frontend: Vue 3 + Quasar Framework
- Storage: Supabase Storage（既存の `profile-photos` バケットは講師用）
- 認証: JWT ベースの認証（RLS ポリシーで保護）

**既存の参考実装**:
- 講師プロフィール画像アップロード機能（`apis/provider.py` の `upload_profile_photo()`）
- 既存の `receiver_profiles` テーブルと API エンドポイント

## Goals / Non-Goals

### Goals
- 生徒プロフィールに 5 つの新規フィールド（顔写真、学習歴、資格、特技、日本語レベル）を追加
- 顔写真を必須項目として、Supabase Storage にアップロード可能にする
- 他の新規フィールドは任意項目として実装
- 将来のカメラ自撮り機能に対応できる拡張可能な設計
- 既存データへの影響を最小限に抑える

### Non-Goals
- カメラ自撮り機能の実装（将来対応のための設計のみ）
- 画像の加工・編集機能（トリミング、フィルタ等）
- 顔写真の顔認識・検証機能
- 他のファイル形式（PDF、動画等）のアップロード対応
- プロフィール公開範囲の制御機能

## Decisions

### 1. Supabase Storage バケット設計

**決定**: 生徒専用の新規バケット `receiver-profile-photos` を作成する。

**理由**:
- 講師用（`profile-photos`）と生徒用でバケットを分離することで、RLS ポリシーを明確に分離できる
- 将来的に異なるストレージポリシー（保存期間、サイズ制限等）を適用できる
- 管理・監視が容易になる

**代替案**:
- ❌ 既存の `profile-photos` バケットを共有: RLS ポリシーが複雑化し、権限管理が煩雑になる
- ❌ ユーザーごとにバケットを作成: 管理コストが高く、Supabase の料金体系に不利

**実装詳細**:
- バケット名: `receiver-profile-photos`
- 公開アクセス: 有効（public URL で画像を参照可能）
- ファイル命名規則: `receiver_{user_id}_{timestamp}.{ext}`
- 許可する拡張子: jpg, jpeg, png, gif
- ファイルサイズ制限: 5MB（Supabase Storage のデフォルト設定に従う）

### 2. 画像アップロード API 設計

**決定**: 専用エンドポイント `POST /api/receiver/profile-photo` を新規作成する。

**理由**:
- 画像アップロードとプロフィール保存を分離することで、UX が向上（アップロード後即座にプレビュー表示可能）
- ファイルアップロードのエラーハンドリングを独立して実装できる
- 将来的にカメラ自撮り機能を追加する際、同じエンドポイントを再利用できる

**代替案**:
- ❌ `POST /api/receiver/profile` で画像とプロフィールを同時送信: multipart/form-data と JSON の混在で実装が複雑化
- ❌ 画像を Base64 エンコードして JSON に含める: ペイロードサイズが大きくなり、パフォーマンスが低下

**実装詳細**:
```python
@router.post("/api/receiver/profile-photo")
async def upload_receiver_profile_photo(
    file: UploadFile = File(...),
    user=Depends(get_current_user),
    db=Depends(get_db)
):
    # 1. ファイル形式検証（jpg, jpeg, png, gif）
    # 2. ファイルサイズ検証（5MB以下）
    # 3. user_id を含むファイル名生成
    # 4. Supabase Storage にアップロード
    # 5. 公開 URL を返却
    return {"status": "success", "url": public_url}
```

### 3. データベーススキーマ設計

**決定**: `receiver_profiles` テーブルに 5 つのカラムを追加する。

**カラム定義**:
```sql
ALTER TABLE receiver_profiles
  ADD COLUMN profile_photo_url TEXT,
  ADD COLUMN learning_history TEXT,
  ADD COLUMN qualifications TEXT,
  ADD COLUMN special_skills TEXT,
  ADD COLUMN japanese_level TEXT;
```

**理由**:
- `profile_photo_url`: URL 文字列を保存（Storage のパスではなく公開 URL）
- テキストフィールド（learning_history, qualifications, special_skills）: TEXT 型で長文対応
- `japanese_level`: TEXT 型（将来的に選択肢が増える可能性を考慮し、ENUM は使用しない）

**代替案**:
- ❌ 別テーブルに分離: 1:1 関係のため JOIN が増えてパフォーマンスが低下
- ❌ JSONB カラムに格納: クエリが複雑化し、型安全性が失われる

### 4. 顔写真の必須化戦略

**決定**: フロントエンドで保存ボタンの有効/無効を制御し、バックエンドでもバリデーションを実施する。

**理由**:
- UX: フロントエンドで即座にフィードバックを提供
- セキュリティ: バックエンドで最終的な検証を行い、API の直接呼び出しにも対応

**実装詳細**:
- フロントエンド: `profile_photo_url` が空の場合、保存ボタンを無効化
- バックエンド: Pydantic バリデータで `profile_photo_url` が空の場合エラーを返却
- 既存ユーザー対応: マイグレーション時は NULL を許可し、次回編集時に必須化

**例外処理**:
```python
@validator("profile_photo_url")
def validate_profile_photo_url(cls, value):
    if value is None or value.strip() == "":
        raise ValueError("顔写真をアップロードしてください")
    return value
```

### 5. フロントエンド画像アップロードコンポーネント設計

**決定**: 画像アップロード機能を抽象化し、将来のカメラ自撮り対応を考慮した設計にする。

**コンポーネント構造**:
```vue
<template>
  <div class="profile-photo-upload">
    <!-- プレビュー表示 -->
    <div v-if="photoUrl" class="photo-preview">
      <img :src="photoUrl" alt="プロフィール写真" />
    </div>
    
    <!-- アップロードボタン -->
    <q-btn label="写真を選択" @click="selectFile" />
    
    <!-- 将来のカメラボタン（未実装） -->
    <!-- <q-btn label="カメラで撮影" @click="openCamera" /> -->
    
    <input
      ref="fileInput"
      type="file"
      accept="image/jpeg,image/png,image/gif"
      @change="handleFileSelect"
      style="display: none"
    />
  </div>
</template>
```

**理由**:
- File API と Camera API の両方に対応できるインターフェース
- アップロード処理を共通化し、ソースの切り替えが容易

**将来対応**:
- Camera API (`navigator.mediaDevices.getUserMedia()`) を使用してカメラ起動
- 撮影後、Blob を File オブジェクトに変換して同じアップロードフローを使用

### 6. 日本語レベルの選択肢設計

**決定**: 「初心者」「中級者」「上級者」の 3 段階のみ提供する。

**理由**:
- シンプルで直感的（JLPT レベルを知らないユーザーにも理解しやすい）
- マッチングの粗い分類として十分

**代替案**:
- ❌ JLPT レベル（N5〜N1）: ユーザーによっては理解が難しく、未受験者が選択しにくい
- ❌ 自由記述: データの標準化が困難で、マッチングに利用しにくい

**実装詳細**:
- フロントエンド: `q-select` で選択肢を提供（clearable で未選択も許可）
- バックエンド: バリデーションなし（TEXT 型で自由に保存可能）

## Risks / Trade-offs

### Risk: 顔写真の必須化により既存ユーザーの UX が低下

**詳細**: 既存の `receiver_profiles` レコードには `profile_photo_url` が NULL のため、次回編集時に必ず写真をアップロードしなければならない。

**軽減策**:
- マイグレーション時に `profile_photo_url` を NULL 許可で追加
- 既存ユーザーが初めてプロフィール編集画面にアクセスした際、顔写真アップロードを促すメッセージを表示
- 段階的な必須化: 一定期間は警告のみ表示し、猶予期間後に完全必須化

### Risk: Supabase Storage の容量制限

**詳細**: 無料プランでは 1GB までのストレージ制限があり、ユーザー数が増えると上限に達する可能性がある。

**軽減策**:
- ファイルサイズを 5MB に制限
- 画像を適切に圧縮（フロントエンドまたはバックエンドで）
- 将来的に有料プランへの移行を検討

### Risk: 画像アップロードのパフォーマンス

**詳細**: 大きな画像ファイルのアップロードに時間がかかり、UX が低下する可能性がある。

**軽減策**:
- アップロード中にローディングインジケータを表示
- アップロード前にクライアント側で画像を圧縮（例: 最大解像度 1024x1024）
- 将来的に CDN を導入してパフォーマンスを向上

### Trade-off: 画像アップロード API の分離

**メリット**: UX が向上し、エラーハンドリングが明確になる

**デメリット**: API 呼び出しが増える（アップロード 1 回 + プロフィール保存 1 回）

**判断**: UX とコードの保守性を優先し、API を分離する設計を採用

## Migration Plan

### フェーズ 1: データベースマイグレーション

1. Supabase マイグレーションファイルを作成
   ```bash
   npx supabase db diff -f add_receiver_profile_extended_fields
   ```

2. マイグレーション SQL を実行
   ```sql
   ALTER TABLE receiver_profiles
     ADD COLUMN profile_photo_url TEXT,
     ADD COLUMN learning_history TEXT,
     ADD COLUMN qualifications TEXT,
     ADD COLUMN special_skills TEXT,
     ADD COLUMN japanese_level TEXT;
   ```

3. 既存データの検証（すべてのカラムが NULL で追加されることを確認）

### フェーズ 2: Supabase Storage バケット作成

1. Supabase ダッシュボードで `receiver-profile-photos` バケットを作成
2. 公開アクセスを有効化
3. RLS ポリシーを設定（自分のファイルのみアップロード可能）

### フェーズ 3: バックエンド実装

1. `ReceiverProfile` スキーマを拡張（新規フィールド追加）
2. `POST /api/receiver/profile-photo` エンドポイントを実装
3. `POST /api/receiver/profile` エンドポイントを更新（新規フィールド対応）
4. バリデーションロジックを追加

### フェーズ 4: フロントエンド実装

1. `ReceiverProfile.vue` に画像アップロードコンポーネントを追加
2. 新規フォームフィールド（学習歴、資格、特技、日本語レベル）を追加
3. 顔写真未アップロード時の保存ボタン制御を実装

### フェーズ 5: テスト

1. 新規ユーザーのプロフィール登録テスト
2. 既存ユーザーのプロフィール編集テスト（顔写真追加）
3. 画像アップロードエラーケースのテスト
4. バリデーションエラーのテスト

### ロールバック戦略

1. フロントエンドのロールバック: 以前のバージョンをデプロイ
2. バックエンドのロールバック: 新規エンドポイントを無効化
3. データベースロールバック:
   ```sql
   ALTER TABLE receiver_profiles
     DROP COLUMN profile_photo_url,
     DROP COLUMN learning_history,
     DROP COLUMN qualifications,
     DROP COLUMN special_skills,
     DROP COLUMN japanese_level;
   ```
   注意: カラム削除により既に保存されたデータが失われる

## Open Questions

1. **画像の圧縮設定**: クライアント側で圧縮する場合、最大解像度とファイルサイズの具体的な値は？
   - 提案: 最大 1024x1024、最大 2MB

2. **顔写真の必須化タイミング**: 既存ユーザーに対する猶予期間はどの程度？
   - 提案: 初回は警告のみ、1ヶ月後に完全必須化

3. **画像のファイル形式**: WebP 形式のサポートは必要か？
   - 提案: 現時点では JPG/PNG/GIF のみ、将来的に WebP を追加検討

4. **セキュリティ**: アップロード画像の内容検証（不適切な画像のフィルタリング）は必要か？
   - 提案: 初期リリースでは実装せず、将来的に AI ベースの画像モデレーション導入を検討
