# Project Context

## Purpose
This project is a **Shift Reservation Management System (SRMS)** designed for Japanese language classroom scheduling and reservation management. The system enables:
- **Providers** (teachers/instructors) to create and manage their availability shifts
- **Receivers** (students) to make reservations for classes
- **Admins** to manage users, view analytics, and calculate payroll
- Automated notifications via Slack and LINE Messaging API
- Secure multi-tenant access control using RBAC and Row Level Security (RLS)

## Tech Stack

### Backend
- **Language**: Python 3.11
- **Framework**: FastAPI with Uvicorn (ASGI server)
- **ORM**: SQLAlchemy
- **Validation**: Pydantic (including email validation)
- **Authentication**: JWT via python-jose with cryptography, bcrypt for password hashing
- **HTTP Client**: httpx for external API calls
- **Database Client**: psycopg2-binary, @supabase/supabase-js
- **Session Management**: itsdangerous
- **Environment**: python-dotenv
- **File Upload**: python-multipart

### Frontend
- **Language**: JavaScript (ES Modules)
- **Framework**: Vue 3 (Composition API)
- **UI Framework**: Quasar Framework v2
- **Build Tool**: Vite (via @quasar/app-vite)
- **State Management**: Pinia v3
- **Routing**: Vue Router v4
- **HTTP Client**: Axios
- **Internationalization**: Vue I18n v11
- **Rich Text Editor**: TipTap v2
- **Calendar Component**: vue-cal v4.10
- **Icons**: @quasar/extras
- **Linting**: ESLint v9 with Vue plugin
- **Formatting**: Prettier v3

### Database & Backend Services
- **Database**: PostgreSQL (Supabase hosted)
- **Security**: Row Level Security (RLS) policies
- **Schema Management**: SQL scripts in `supabase/` directory

### Infrastructure & Deployment
- **Container**: Docker (multi-stage build)
- **Orchestration**: Docker Compose
- **Reverse Proxy**: Nginx
- **Process Management**: supervisord
- **Hosting**: Koyeb (single container deployment)
- **CDN/WAF**: Cloudflare

### External Integrations
- **Slack**: Webhook notifications for reservations and cancellations
- **LINE Messaging API**: Notifications and OAuth callback handling
- **Email**: SMTP-based email notifications

## Project Conventions

### Code Style
- **Backend (Python)**:
  - Follow PEP 8 conventions
  - Use type hints with Pydantic for validation
  - Organize code in layers: CRUD (data access) → Services (business logic) → Routes (API endpoints)
  - Use dependency injection pattern via FastAPI's `Depends()`

- **Frontend (Vue/JavaScript)**:
  - Use Composition API (not Options API)
  - ESLint configuration in `eslint.config.js`
  - Prettier for code formatting
  - Vue single-file components (.vue)
  - Component naming: PascalCase for files, kebab-case in templates

- **Naming Conventions**:
  - Database tables: snake_case (e.g., `service_logs`, `provider_profiles`)
  - API endpoints: kebab-case with REST conventions
  - Python variables/functions: snake_case
  - JavaScript variables/functions: camelCase
  - Vue components: PascalCase
  - Constants: UPPER_SNAKE_CASE

### Architecture Patterns
- **Architecture**: 3-tier architecture (Presentation → Business Logic → Data Access)
- **API Design**: RESTful API with JWT authentication
- **Security**: RBAC (Role-Based Access Control) + RLS (Row Level Security)
- **State Management**: Centralized with Pinia stores
- **Component Structure**:
  - Layouts for page scaffolding
  - Pages for route components
  - Reusable components in `components/`
- **Backend Structure**:
  - `apis/main.py`: FastAPI application entry point
  - `apis/crud/`: Database operations layer
  - `apis/services/`: External service integration (Slack, LINE, email)
  - `apis/models.py`: SQLAlchemy data models
  - `apis/schemas.py`: Pydantic schemas for request/response
  - `apis/security.py`: JWT and password hashing utilities
  - `apis/deps.py`: Dependency injection providers

### Testing Strategy
- Backend: Test specifications documented separately from implementation
- Frontend: Tests run via `npm test` (currently placeholder)
- Testing policy details in `doc/policies/testing-policy.md`

### Git Workflow
- **Current branch**: `docs/setup`
- **Default branch**: `main`
- Development policies documented in `doc/policies/development-policy.md`
- Commit messages should be written in Japanese (per project guidelines)

### Documentation Standards
- **Language**: All documentation, comments, PRs, and commit messages must be written in **Japanese** unless validation constraints explicitly require English
- **Design Documents**:
  - Backend: Describe processing flow in prose, include DB data and API request items, exclude code/test code
  - Frontend: Document screen elements, event handling, API endpoints; omit activation states, initial values, and API request details
- Technical terms may remain in English when appropriate
- Code identifiers (variables, functions) follow language conventions (English)

## Domain Context

### User Roles
1. **Admin**: Full system access - user management, analytics, payroll calculation
2. **Provider**: Teachers/instructors who create shifts and log service records
3. **Receiver**: Students who make reservations for available shifts

### Core Entities
- **Users**: All system users with role-based permissions
- **Provider Profiles**: Extended profile for providers (teachers)
- **Shifts**: Availability slots created by providers
- **Reservations**: Bookings made by receivers for specific shifts
- **Service Logs**: Actual service delivery records for payroll calculation
- **Rooms**: Virtual/physical spaces for sessions

### Business Rules
- Providers create shifts defining their availability
- Receivers can reserve available shifts
- Reservations trigger notifications (Slack/LINE)
- Service logs track actual delivery for payroll
- Cancellations are supported with proxy cancellation capability
- Monthly payroll calculation based on service logs
- Row Level Security ensures data isolation between tenants

## Important Constraints

### Technical Constraints
- Single container deployment on Koyeb (Nginx + Uvicorn bundled)
- Port mapping: Port 80 (Nginx) → Port 8088 (Uvicorn internal)
- Frontend built as static SPA served by Nginx
- Database connections via Supabase (external PostgreSQL)
- JWT tokens for stateless authentication
- CORS configured for API access

### Business Constraints
- Multi-tenant system with data isolation via RLS
- Japanese language classroom domain
- Real-time notifications required for reservations
- Payroll calculations must be accurate and auditable
- User roles strictly enforced at database and application layers

### Security Constraints
- Passwords must be hashed with bcrypt
- JWT secret must be configured via environment variables
- Cloudflare WAF for production security
- HTTPS required in production
- Row Level Security policies active on all tables
- RBAC enforced at API layer

## External Dependencies

### Required External Services
- **Supabase**: PostgreSQL database hosting with RLS support
  - Environment variable: `DATABASE_URL`
  - Connection: psycopg2-binary + @supabase/supabase-js

- **Slack**: Webhook notifications
  - Environment variable: `SLACK_DEFAULT_WEBHOOK`
  - Used for: Reservation/cancellation notifications

- **LINE Messaging API**: User notifications and OAuth
  - Callback endpoint: `/api/line/callback`
  - Integration in `apis/services/line.py`

### Optional Services
- **Email SMTP**: Email notifications via `apis/services/mail.py`

### Infrastructure Services
- **Koyeb**: Production hosting platform
- **Cloudflare**: CDN, DNS, and WAF protection
- **Docker Registry**: For container image distribution

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SUPABASE_URL`: Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY`: Service role key for admin operations
- `JWT_SECRET`: Secret key for JWT signing
- `ACCESS_TTL_MIN`: JWT token expiration time (default: 120 minutes)
- `FRONTEND_BASE_URL`: Frontend URL for CORS and redirects
- `SLACK_DEFAULT_WEBHOOK`: Slack webhook URL for notifications
