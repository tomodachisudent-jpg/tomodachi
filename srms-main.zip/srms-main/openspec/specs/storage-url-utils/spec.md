## 目的

Supabase Storage の画像URLを生成する共通ユーティリティ関数を提供する。環境（ローカル/本番）を自動的に判定し、適切なURL形式（相対パスまたは絶対URL）を生成する。

## 要件

### 要件: SUPABASE_URL に基づく環境判定
システムは `SUPABASE_URL` にローカル環境特有のパターンが含まれているかを確認し、ローカル開発環境を検出しなければならない（SHALL）。

#### シナリオ: ローカル環境の検出
- **WHEN** `SUPABASE_URL` に "localhost" または "127.0.0.1" または "172.17.0.1" が含まれる場合
- **THEN** システムはこれをローカル環境として識別しなければならない（SHALL）

#### シナリオ: 本番環境の検出
- **WHEN** `SUPABASE_URL` にローカルパターンが含まれていない場合（例: "https://xxx.supabase.co"）
- **THEN** システムはこれを本番環境として識別しなければならない（SHALL）

### 要件: 環境認識に基づく Storage URL 生成
システムは検出された環境に基づいて、適切な Storage URL を生成しなければならない（SHALL）。

#### シナリオ: ローカル環境での相対パス生成
- **GIVEN** システムがローカル環境で実行されている場合
- **WHEN** バケット "profile-photos" とファイル "image.jpg" の Storage URL を生成する場合
- **THEN** システムは "/storage/v1/object/public/profile-photos/image.jpg" を返さなければならない（SHALL）

#### シナリオ: 本番環境での絶対URL生成
- **GIVEN** システムが本番環境で実行されている場合
- **AND** `SUPABASE_URL` が "https://xxx.supabase.co" である場合
- **WHEN** バケット "profile-photos" とファイル "image.jpg" の Storage URL を生成する場合
- **THEN** システムは "https://xxx.supabase.co/storage/v1/object/public/profile-photos/image.jpg" を返さなければならない（SHALL）

### 要件: ユーティリティ関数の再利用性
システムは複数の API エンドポイントファイルからインポート可能な再利用可能なユーティリティ関数を提供しなければならない（SHALL）。

#### シナリオ: provider.py でのインポート
- **WHEN** `provider.py` で `apis.utils` から `get_storage_url` をインポートする場合
- **THEN** この関数は講師プロフィール写真のURL生成に使用可能でなければならない（SHALL）

#### シナリオ: receiver_profile.py でのインポート
- **WHEN** `receiver_profile.py` で `apis.utils` から `get_storage_url` をインポートする場合
- **THEN** この関数は生徒プロフィール写真のURL生成に使用可能でなければならない（SHALL）
