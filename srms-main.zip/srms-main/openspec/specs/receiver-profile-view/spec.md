# receiver-profile-view Specification

## Purpose

生徒（receiver）のプロフィール情報を、講師（provider）および管理者（admin）が閲覧できる機能を定義します。この機能はメール等で共有されたURLから直接アクセスすることを想定しており、Webアプリのナビゲーションメニューからの導線はありません。

## Requirements

### Requirement: 生徒プロフィール閲覧ページの表示

システムは、providerロールまたはadminロールのユーザーがreceiver（生徒）のプロフィール情報を閲覧できるページを提供しなければならない (SHALL)。

#### Scenario: 先生が生徒プロフィールページにアクセス

- **WHEN** providerロールでログイン済みのユーザーが `/receiver/profile/view/{receiver_id}` にアクセス
- **THEN** 指定されたreceiver_idの生徒プロフィール情報が表示される

#### Scenario: 管理者が生徒プロフィールページにアクセス

- **WHEN** adminロールでログイン済みのユーザーが `/receiver/profile/view/{receiver_id}` にアクセス
- **THEN** 指定されたreceiver_idの生徒プロフィール情報が表示される

#### Scenario: 未認証ユーザーのアクセス

- **WHEN** 未認証のユーザーが `/receiver/profile/view/{receiver_id}` にアクセス
- **THEN** システムはログインページにリダイレクトする

#### Scenario: 不正なロール（receiver）のアクセス

- **WHEN** receiverロールのユーザーが `/receiver/profile/view/{receiver_id}` にアクセス
- **THEN** システムはアクセス拒否エラーを表示する

---

### Requirement: プロフィールデータの取得

システムは、GET `/api/receiver/profile/{receiver_id}` エンドポイントを提供し、指定されたreceiverのプロフィール情報を返さなければならない (SHALL)。

#### Scenario: 正常なプロフィールデータ取得

- **WHEN** providerまたはadminロールでJWT認証済みのリクエストが `/api/receiver/profile/{receiver_id}` に送信される
- **THEN** システムは該当するreceiver_profilesレコードをJSON形式で返す

#### Scenario: 存在しないreceiver_idの指定

- **WHEN** 存在しないreceiver_idを指定してAPIリクエストが送信される
- **THEN** システムは空のオブジェクト `{}` を返す
- **AND** フロントエンドは「生徒が見つかりません」メッセージを表示する

#### Scenario: JWT認証なしのAPIリクエスト

- **WHEN** JWT認証ヘッダーなしで `/api/receiver/profile/{receiver_id}` にリクエストが送信される
- **THEN** システムは401 Unauthorizedエラーを返す

---

### Requirement: プロフィール表示項目

システムは、生徒プロフィール閲覧ページに以下のフィールドを表示しなければならない (SHALL)。

**必須表示項目:**

- プロフィール写真 (profile_photo_url)
- 名前 (name)
- 年齢 (age)
- 性別 (gender)
- 国籍 (nationality)
- 自己紹介 (self_introduction)
- 学習目標 (learning_goals)
- 日本語レベル (japanese_level)

**オプション表示項目（データが存在する場合のみ）:**

- 学習歴 (learning_history)
- 資格 (qualifications)
- 特技 (special_skills)

#### Scenario: 全項目が入力された生徒のプロフィール表示

- **WHEN** 全フィールドにデータが入力されている生徒のプロフィールを表示
- **THEN** 全ての必須項目とオプション項目が画面に表示される

#### Scenario: オプション項目が未入力の生徒のプロフィール表示

- **WHEN** learning_history, qualifications, special_skillsが未入力の生徒のプロフィールを表示
- **THEN** 必須項目のみが表示され、オプション項目は非表示となる

#### Scenario: プロフィール写真が未設定の場合

- **WHEN** profile_photo_urlが空またはnullの生徒のプロフィールを表示
- **THEN** デフォルトプロフィール画像 (`/images/default-profile.png`) が表示される

#### Scenario: 存在しない生徒のプロフィール表示

- **WHEN** 存在しないreceiver_idでプロフィールページにアクセス
- **THEN** 「生徒が見つかりません」メッセージが表示される
- **AND** 空のプロフィールカードは表示されない

---

### Requirement: UI/UXの一貫性

生徒プロフィール閲覧ページは、既存のProviderProfileView.vueと同様のCard-basedレイアウト構造を使用しなければならない (SHALL)。

#### Scenario: レイアウト構造の確認

- **WHEN** 生徒プロフィール閲覧ページを表示
- **THEN** Quasar q-page > q-card > q-card-section の構造で表示される

#### Scenario: レスポンシブ対応

- **WHEN** モバイルデバイスで生徒プロフィールページを表示
- **THEN** Quasarグリッドシステムによりレスポンシブに調整される
