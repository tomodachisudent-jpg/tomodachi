# コードベースの構造

## プロジェクトルート構造

```
tomodachi_classroom/
├── ui/                     # フロントエンド (Vue + Quasar)
├── apis/                   # バックエンド (FastAPI)
├── supabase/              # データベーススキーマとポリシー
├── .devcontainer/         # VS Code Dev Container設定
├── doc/                   # ドキュメント
├── .serena/              # Serenaエージェント設定
├── .claude/              # Claude Code設定
├── .vscode/              # VS Code設定
├── .git/                 # Gitリポジトリ
├── docker-compose.yml    # Docker Compose設定
├── Dockerfile            # マルチステージDockerfile
├── nginx.conf            # Nginx設定
├── supervisord.conf      # Supervisor設定
├── requirements.txt      # Python依存関係
├── .env.sample          # 環境変数サンプル
├── .env.dev             # 開発環境用環境変数
├── .gitignore           # Git除外設定
├── .mcp.json            # MCP設定
├── LICENSE              # ライセンス
└── README.md            # プロジェクト説明
```

## Frontend構造 (ui/)

```
ui/
├── src/
│   ├── pages/            # ページコンポーネント
│   │   ├── LoginPage.vue
│   │   ├── DashboardView.vue
│   │   ├── CalendarView.vue
│   │   ├── AdminUserManagement.vue
│   │   ├── AdminAnalytics.vue
│   │   ├── ProviderHistory.vue
│   │   ├── ProviderProfile.vue
│   │   ├── ProviderProfileView.vue
│   │   ├── ReceiverReservations.vue
│   │   ├── RoomView.vue
│   │   ├── AccountView.vue
│   │   ├── LineCallbackView.vue
│   │   ├── AboutView.vue
│   │   ├── UnauthorizedPage.vue
│   │   └── ErrorNotFound.vue
│   ├── components/       # 再利用可能なコンポーネント
│   ├── layouts/          # レイアウトコンポーネント
│   ├── stores/           # Pinia stores (状態管理)
│   ├── router/           # Vue Router設定
│   ├── boot/             # Quasar boot files
│   ├── css/              # グローバルスタイル
│   ├── i18n/             # 国際化ファイル
│   ├── assets/           # 静的アセット
│   └── App.vue           # ルートコンポーネント
├── public/               # 公開静的ファイル
├── node_modules/         # Node依存関係 (gitignore)
├── .quasar/             # Quasarビルドファイル (gitignore)
├── dist/                # ビルド出力 (gitignore)
├── package.json         # Node設定と依存関係
├── package-lock.json    # Node依存関係ロック
├── quasar.config.js     # Quasar設定
├── eslint.config.js     # ESLint設定
├── .prettierrc.json     # Prettier設定
├── postcss.config.js    # PostCSS設定
├── jsconfig.json        # JavaScript設定
├── .editorconfig        # エディタ設定
├── .npmrc               # npm設定
├── .gitignore           # Git除外設定
└── index.html           # エントリーHTML
```

### ページの役割分担
- **LoginPage**: ログイン画面
- **DashboardView**: ダッシュボード
- **CalendarView**: カレンダービュー
- **AdminUserManagement**: 管理者用ユーザー管理
- **AdminAnalytics**: 管理者用分析画面
- **ProviderHistory**: プロバイダーの履歴
- **ProviderProfile**: プロバイダープロファイル編集
- **ProviderProfileView**: プロバイダープロファイル表示
- **ReceiverReservations**: レシーバーの予約一覧
- **RoomView**: ルーム/チャットビュー
- **AccountView**: アカウント設定
- **LineCallbackView**: LINE連携コールバック

## Backend構造 (apis/)

```
apis/
├── __pycache__/          # Pythonキャッシュ (gitignore)
├── services/             # ビジネスロジック/外部サービス
│   ├── slack.py         # Slack通知
│   ├── line.py          # LINE通知
│   ├── mail.py          # メール送信 (Mailjet)
│   └── payroll.py       # 給与計算ロジック
├── crud/                 # CRUD操作
├── main.py              # FastAPIエントリーポイント
├── auth.py              # 認証ロジック (JWT, ハッシュ)
├── security.py          # セキュリティユーティリティ
├── deps.py              # 依存性注入 (DB, 認証)
├── models.py            # SQLAlchemyモデル
├── schemas.py           # Pydanticスキーマ
├── admin.py             # 管理者用ルーター
├── provider.py          # プロバイダー用ルーター
├── receiver.py          # レシーバー用ルーター
├── login.py             # ログインルーター
├── notify.py            # 通知ルーター
├── room.py              # ルーム/チャットルーター
└── __init__.py          # パッケージ初期化
```

### ルーターの役割
- **login.py**: 認証エンドポイント
- **admin.py**: 管理者専用機能 (ユーザー管理、給与集計)
- **provider.py**: プロバイダー専用機能 (シフト管理、実績登録)
- **receiver.py**: レシーバー専用機能 (予約作成・キャンセル)
- **notify.py**: 通知関連エンドポイント
- **room.py**: ルーム/チャット機能

## Database構造 (supabase/)

```
supabase/
├── schema.sql           # テーブル定義
└── policies.sql         # RLS (Row Level Security) ポリシー
```

### セットアップ順序
1. `schema.sql` を実行してテーブル作成
2. `policies.sql` を実行してRLSポリシー適用

## ユーザーロール
- **admin**: 管理者 (全機能アクセス可能)
- **provider**: サービス提供者 (シフト管理、実績登録)
- **receiver** (customer): サービス受給者 (予約作成・キャンセル)

## 認証フロー
1. ユーザーがログイン (`POST /api/auth/login`)
2. JWTトークン発行
3. 以降のリクエストでトークンを使用
4. ロールに基づいてエンドポイントへのアクセス制御

## 通知フロー
1. イベント発生 (予約作成、キャンセルなど)
2. 対応する通知サービス呼び出し
3. Slack/LINE/メールで通知送信
