# プロジェクト概要

## プロジェクト名
Shift Reservation Sample (SRMS - Shift Reservation Management System)

## 目的
本番運用を意識した **RBAC/RLS/給与計算/Slack通知** 付きのシフト・予約管理アプリのサンプルプロジェクト。

## 主な機能
- **認証・認可**: JWT認証 + ロールベースアクセス制御 (RBAC)
- **ユーザー管理**: 管理者によるユーザー作成・管理（admin/provider/receiver）
- **シフト管理**: プロバイダーによるシフト作成・管理
- **予約管理**: レシーバーによる予約作成・キャンセル
- **通知機能**: Slack/LINE/メール通知
- **給与計算**: 月次給与集計機能
- **提供実績登録**: サービス提供ログの記録

## 主要エンドポイント
- `POST /api/auth/login` : ログイン（JWT）
- `POST /api/admin/users` : 管理者がユーザ作成
- `POST /api/provider/shifts` : シフト作成
- `POST /api/receiver/reservations` : 予約作成（Slack通知）
- `POST /api/reservations/{id}/cancel` : 予約キャンセル
- `POST /api/provider/service-logs` : 提供実績登録
- `GET  /api/admin/payroll?month=2025-08-01` : 月次給与集計

## ホスティング環境
- 本番環境: Koyeb（単一コンテナにNginx+Uvicornで同梱）
- セキュリティ: Cloudflare (WAF, HTTPS)
- DB: Supabase (PostgreSQL) + RLS
