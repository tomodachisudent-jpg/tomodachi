# コードスタイルとコンベンション

## JavaScript/Vue コードスタイル

### Prettier設定
- **セミコロン**: なし (`"semi": false`)
- **クォート**: シングルクォート (`"singleQuote": true`)
- **行の最大幅**: 100文字 (`"printWidth": 100`)

### ESLint設定
- Vue 3 Essential ルール
- Quasar推奨設定
- ECMAScript: latest
- 開発環境では `no-debugger` 許可

### Vue コーディング規約
- **構文**: Composition API + `<script setup>`
- **状態管理**: Pinia
- **命名規則**:
  - コンポーネント: PascalCase (例: `LoginPage.vue`, `AdminUserManagement.vue`)
  - Composables/Stores: camelCase (例: `useAuthStore`)
  - 定数: camelCase (例: `roleHomeMap`)
- **インポート順序**:
  1. Vue core (`vue`, `vue-router`)
  2. サードパーティライブラリ (`axios`)
  3. ローカルストア/コンポーネント (`stores/auth`)

### ファイル構造
- Pages: `ui/src/pages/`
- Components: `ui/src/components/`
- Stores: `ui/src/stores/`
- Layouts: `ui/src/layouts/`
- Router: `ui/src/router/`

## Python コードスタイル

### 一般規約
- **タイプヒント**: 必須（関数引数、戻り値）
- **Docstring**: 一般的に使用されていない（コードは自己説明的）
- **命名規則**:
  - 関数/変数: snake_case
  - クラス: PascalCase
  - 定数: UPPER_SNAKE_CASE
  - Private: `_` プレフィックス

### FastAPI パターン
- **スキーマ**: Pydantic BaseModel (`schemas.py`)
- **モデル**: SQLAlchemy ORM (`models.py`)
- **依存性注入**: `Depends()` を使用
- **ルーター**: 機能ごとに分離 (`admin.py`, `provider.py`, `receiver.py`)
- **認証**: JWT + ロールベース認可

### ファイル構造
- Main: `apis/main.py`
- Routers: `apis/{admin,provider,receiver,login,notify,room}.py`
- Models: `apis/models.py`
- Schemas: `apis/schemas.py`
- Auth: `apis/auth.py`, `apis/security.py`
- Dependencies: `apis/deps.py`
- Services: `apis/services/`

### インポート順序
1. 標準ライブラリ
2. サードパーティライブラリ (`fastapi`, `pydantic`)
3. ローカルモジュール (`.deps`, `.auth`, `.schemas`)

## データベーススキーマ
- スキーマ定義: `supabase/schema.sql`
- RLSポリシー: `supabase/policies.sql`
- セットアップ順序: schema.sql → policies.sql

## 環境変数
- サンプル: `.env.sample`
- 本番用: `.env` (gitignore対象)
- 必須変数:
  - `DATABASE_URL`: Supabase Postgres接続
  - `JWT_SECRET`: JWT署名シークレット
  - `SLACK_DEFAULT_WEBHOOK`: Slack通知用
  - その他: LINE, Mailjet, WeChat設定
