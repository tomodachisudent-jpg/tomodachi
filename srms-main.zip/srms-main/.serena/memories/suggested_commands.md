# 開発に必要なコマンド

## Frontend (ui/)

### 開発サーバー起動
```bash
cd ui
npm run dev
# または
quasar dev
```
デフォルト: http://localhost:9000

### ビルド
```bash
cd ui
npm run build
# または
quasar build
```
出力先: `ui/dist/spa/`

### リント
```bash
cd ui
npm run lint
```

### フォーマット
```bash
cd ui
npm run format
```

### 依存関係インストール
```bash
cd ui
npm install --legacy-peer-deps
```

### Quasar CLI グローバルインストール
```bash
npm install -g @quasar/cli
```

## Backend (apis/)

### 開発サーバー起動
```bash
# プロジェクトルートから
uvicorn apis.main:app --host 0.0.0.0 --port 8000 --reload
```
デフォルト: http://localhost:8000
API Docs: http://localhost:8000/docs

### Python依存関係インストール
```bash
pip install -r requirements.txt
```

## Docker

### Docker Compose (開発環境)
```bash
# ビルド＆起動
docker-compose up --build

# バックグラウンド起動
docker-compose up -d

# 停止
docker-compose down
```

サービス構成:
- `backend`: FastAPI (ポート 8000)
- `frontend`: Quasar (ポート 9000)
- `final`: Nginx + Uvicorn (ポート 80, 8088)

### 本番イメージビルド
```bash
docker build -t shift-sample .
docker run -p 8080:80 --env-file .env shift-sample
```
アクセス: http://localhost:8080

## Database (Supabase)

### スキーマセットアップ
Supabase SQL Editorで以下を順に実行:
1. `supabase/schema.sql`
2. `supabase/policies.sql`

## Git コマンド (Darwin/macOS)

### 基本コマンド
```bash
git status
git add .
git commit -m "message"
git push
git pull
```

### ブランチ操作
```bash
git branch
git checkout -b feature/new-feature
git merge main
```

## システムユーティリティ (Darwin/macOS)

### ファイル操作
```bash
ls -la          # ファイル一覧
find . -name "*.py"   # ファイル検索
grep -r "keyword" .   # 文字列検索
```

### プロセス管理
```bash
ps aux | grep python
lsof -i :8000   # ポート使用確認
kill -9 <PID>   # プロセス終了
```

## 環境変数設定

### .env ファイル作成
```bash
cp .env.sample .env
# .env を編集して必要な環境変数を設定
```

必須環境変数:
- `DATABASE_URL`: Supabase接続文字列
- `JWT_SECRET`: JWT署名用シークレット
- `SLACK_DEFAULT_WEBHOOK`: Slack通知用WebhookURL
