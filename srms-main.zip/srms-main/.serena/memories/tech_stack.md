# 技術スタック

## Backend
- **Framework**: FastAPI
- **Python Version**: 3.11
- **主要ライブラリ**:
  - `fastapi`: Webフレームワーク
  - `uvicorn[standard]`: ASGIサーバー
  - `pydantic`: データバリデーション
  - `sqlalchemy`: ORM
  - `psycopg2-binary`: PostgreSQLドライバ
  - `python-jose[cryptography]`: JWT認証
  - `bcrypt`: パスワードハッシュ
  - `supabase`: Supabaseクライアント
  - `httpx`: HTTPクライアント

## Frontend
- **Framework**: Vue 3 (Composition API)
- **UI Framework**: Quasar Framework
- **Build Tool**: Vite
- **Node Version**: 18/20/22/24/26/28
- **主要ライブラリ**:
  - `quasar`: UIコンポーネントフレームワーク
  - `pinia`: 状態管理
  - `vue-router`: ルーティング
  - `axios`: HTTPクライアント
  - `vue-i18n`: 国際化
  - `vue-cal`: カレンダーコンポーネント
  - `@tiptap/vue-3`: リッチテキストエディタ
  - `@supabase/supabase-js`: Supabaseクライアント

## Database
- **DB**: Supabase (PostgreSQL)
- **セキュリティ**: Row Level Security (RLS)

## Infrastructure
- **コンテナ**: Docker
- **本番サーバー**: Nginx + Uvicorn
- **オーケストレーション**: docker-compose
- **ホスティング**: Koyeb
- **CDN/WAF**: Cloudflare

## 通知サービス
- **Slack**: Webhook通知
- **LINE**: Messaging API
- **Email**: Mailjet
- **WeChat Work**: 小程序通知（オプション）
