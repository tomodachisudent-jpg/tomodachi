# DevContainer フルスタック開発環境

このプロジェクトは VSCode DevContainer を使用したフルスタック（バックエンド + フロントエンド）開発環境をサポートしています。

## 技術スタック

- **バックエンド**: FastAPI (Python 3.11)
- **フロントエンド**: Quasar Framework 2.16 / Vue.js 3.4
- **データベース**: PostgreSQL 15
- **SQL ブラウザ**: Adminer

## 必要な環境

- Docker Desktop
- Visual Studio Code
- VSCode 拡張機能: Dev Containers (ms-vscode-remote.remote-containers)

## DevContainer の起動方法

### 1. プロジェクトを開く

```bash
code /path/to/srms
```

### 2. DevContainer で再起動

1. VSCode のコマンドパレット（`Cmd+Shift+P` / `Ctrl+Shift+P`）を開く
2. 「Dev Containers: Reopen in Container」を選択
3. 初回起動時は Docker イメージのビルドに 5-10 分かかります

### 3. 環境の確認

DevContainer が起動すると、以下のサービスが利用可能になります：

| サービス        | URL                        | 説明                          |
| --------------- | -------------------------- | ----------------------------- |
| FastAPI Backend | http://localhost:8000      | バックエンド API              |
| FastAPI Docs    | http://localhost:8000/docs | Swagger UI (API ドキュメント) |
| Quasar Frontend | http://localhost:9000      | フロントエンド開発サーバー    |
| Adminer         | http://localhost:8080      | SQL ブラウザ管理ツール        |
| PostgreSQL      | localhost:5432             | データベース (直接接続)       |

## フルスタック開発

### プロジェクト構成

```
/workspace/
├── apis/           # バックエンド (FastAPI)
│   ├── main.py
│   ├── deps.py
│   └── ...
├── ui/             # フロントエンド (Quasar/Vue)
│   ├── src/
│   ├── package.json
│   └── ...
├── supabase/       # データベーススキーマ
└── requirements.txt
```

### 方法 1: VSCode タスクを使用（推奨）

VSCode のコマンドパレットから「Tasks: Run Task」を選択：

- **Full Stack: Start All Services** - バックエンドとフロントエンドを同時起動

個別に起動したい場合は以下を選択する

- **Backend: Start FastAPI Dev Server** - バックエンドのみ起動
- **Frontend: Start Quasar Dev Server** - フロントエンドのみ起動

### 方法 2: VSCode デバッガーを使用

デバッグパネル（`Cmd+Shift+D` / `Ctrl+Shift+D`）から起動：

- **Full Stack: Backend + Frontend** - 両方を同時にデバッグ実行
- **Backend: FastAPI Debug** - バックエンドのみデバッグ実行
- **Frontend: Quasar Dev Server** - フロントエンドのみ起動

### 方法 3: ターミナルから手動起動

**バックエンド起動:**

```bash
cd /workspace
uvicorn apis.main:app --host 0.0.0.0 --port 8000 --reload
```

**フロントエンド起動:**

```bash
cd /workspace/ui
npm run dev
# または
quasar dev
```

## デバッグ実行

### バックエンド (FastAPI) のデバッグ

1. `apis/` ディレクトリ内のファイルにブレークポイントを設定
2. デバッグパネルから「Backend: FastAPI Debug」を選択
3. F5 キーでデバッグ実行を開始
4. http://localhost:8000/docs で API をテスト

### フロントエンド (Vue/Quasar) のデバッグ

1. `ui/src/` ディレクトリ内のファイルを編集
2. 変更は自動的にホットリロードされます
3. ブラウザの開発者ツールでデバッグ
4. または「Frontend: Chrome Debug」で VSCode 内でデバッグ

## データベース管理

### Adminer を使用（ブラウザ）

1. http://localhost:8080 にアクセス
2. 以下の認証情報でログイン：
   - システム: PostgreSQL
   - サーバ: postgres
   - ユーザ名: postgres
   - パスワード: postgres
   - データベース: tomodachi_db

### VSCode SQLTools 拡張機能を使用

1. VSCode のサイドバーから「SQLTools」アイコンをクリック
2. 「Tomodachi PostgreSQL」接続をクリック
3. SQL クエリを実行可能

### psql コマンドラインを使用

```bash
psql -h postgres -U postgres -d tomodachi_db
```

または VSCode タスク「Database: Connect with psql」を使用

## 開発ワークフロー

### 1. バックエンドの開発

```bash
# Python依存関係のインストール
pip install package-name

# requirements.txtに追加
echo "package-name==1.0.0" >> requirements.txt

# FastAPIサーバーを起動（ホットリロード有効）
# VSCodeタスクまたはデバッガーから起動
```

主なファイル：

- `apis/main.py` - FastAPI アプリケーションのエントリーポイント
- `apis/deps.py` - 依存関係（DB 接続、認証など）
- `apis/*.py` - 各機能の API ルーター

### 2. フロントエンドの開発

```bash
cd /workspace/ui

# Node依存関係のインストール
npm install --save package-name

# 開発サーバー起動（自動で実行中）
npm run dev

# Lint
npm run lint

# フォーマット
npm run format

# ビルド（本番用）
npm run build
```

主なファイル：

- `ui/src/pages/` - ページコンポーネント
- `ui/src/components/` - 再利用可能なコンポーネント
- `ui/src/router/` - ルーティング設定
- `ui/src/stores/` - Pinia ストア（状態管理）

### 3. データベーススキーマの変更

1. `supabase/schema.sql` を編集
2. データベースをリセット:

   ```bash
   # VSCodeターミナルで実行
   exit  # DevContainerから一時的に抜ける

   # ローカルのターミナルで
   docker-compose -f docker-compose.dev.yml down -v
   docker-compose -f docker-compose.dev.yml up -d postgres adminer

   # 再度DevContainerに接続
   ```

## ログイン情報

| ID                    | パスワード | ロール         |
| --------------------- | ---------- | -------------- |
| admin@example.com     | tomodachi  | システム管理者 |
| provider1@example.com | tomodachi  | 講師           |
| provider2@example.com | tomodachi  | 講師           |
| provider3@example.com | tomodachi  | 講師           |
| receiver1@example.com | tomodachi  | 生徒           |
| receiver2@example.com | tomodachi  | 生徒           |
| receiver3@example.com | tomodachi  | 生徒           |

## よく使う VSCode タスク

コマンドパレット（`Cmd+Shift+P`）→「Tasks: Run Task」から以下を選択：

### バックエンド

- Backend: Start FastAPI Dev Server
- Backend: Install Python Dependencies
- Backend: Run Python File

### フロントエンド

- Frontend: Start Quasar Dev Server
- Frontend: Install Node Dependencies
- Frontend: Build for Production
- Frontend: Lint
- Frontend: Format

### データベース

- Database: Connect with psql
- Database: Show Tables

### フルスタック

- Full Stack: Start All Services

## トラブルシューティング

### ポートが既に使用されている

他のコンテナを停止：

```bash
docker-compose -f docker-compose.dev.yml down
```

### node_modules が見つからない

```bash
cd /workspace/ui
npm install --legacy-peer-deps --ignore-scripts
```

### Python パッケージが見つからない

```bash
cd /workspace
pip install -r requirements.txt
```

### データベース接続エラー

PostgreSQL コンテナが起動しているか確認：

```bash
docker ps | grep postgres
```

起動していない場合：

```bash
docker-compose -f docker-compose.dev.yml up -d postgres
```

### DevContainer のリビルド

設定ファイルを変更した場合：

1. コマンドパレットから「Dev Containers: Rebuild Container」を選択
2. または「Dev Containers: Rebuild Container Without Cache」で完全再ビルド

## 環境変数の設定

開発用の環境変数は `.env.dev` ファイルに定義されています。
DevContainer 内では自動的にロードされます。

```bash
# 編集
code .env.dev
```

## DevContainer から抜ける

VSCode のコマンドパレットから：

- 「Dev Containers: Reopen Folder Locally」を選択

または、VSCode を閉じる。

## 詳細情報

- [VSCode DevContainers Documentation](https://code.visualstudio.com/docs/devcontainers/containers)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Quasar Framework](https://quasar.dev/)
- [Vue.js](https://vuejs.org/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
