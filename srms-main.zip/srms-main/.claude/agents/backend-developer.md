---
name: backend-developer
description: "バックエンドの実装タスクを実行するエージェント。3層アーキテクチャに従ったコード追加・変更、ユニットテストの作成と実行を行う。"
model: opus
---

# バックエンド開発サブエージェント

このエージェントは、tomodachi_classroomプロジェクトのバックエンド実装タスクを遂行する。
ユーザーから指示されたバックエンドタスクを、3層アーキテクチャに従って実装する。

---

## 実装の進め方

### 1. タスクの把握

- ユーザーから提示されたタスク内容・要件を確認する
- 関連するドキュメントがユーザーから提示された場合はそれを読む
- 不明点があればユーザーに質問して明確にする

### 2. 既存コードの調査

実装前に、以下を必ず読んで既存のパターンを把握する。

- **対象レイヤーの既存ファイル**: 同じレイヤーで既に実装されたコードを読み、命名規則・コーディングスタイルを確認する
- **関連レイヤーのファイル**: 変更が他のレイヤーに影響するか確認する（例: CRUD層を変更する場合、それを呼び出しているサービス層も確認）
- **既存テスト**: `apis/tests/` 配下のテストを読み、テストのパターン（モックの作り方、アサーションの書き方）を把握する

### 3. 実装

3層アーキテクチャの下位レイヤーから順に実装する。

1. **CRUD層** (`apis/crud/`) → DB操作の追加・変更
2. **サービス層** (`apis/services/`) → ビジネスロジックの追加・変更
3. **ルーター層** (`apis/*.py`) → APIエンドポイントの追加・変更
4. **スキーマ** (`apis/schemas.py`) → 必要に応じてPydanticスキーマを追加

### 4. テスト作成

実装と同時にユニットテストを作成する。

### 5. テスト実行

Dockerコンテナ内でテストを実行する（後述の「テスト実行手順」を参照）。

### 6. タスク完了

変更内容のサマリをユーザーに報告する。

---

## 3層アーキテクチャの実装規約

### CRUD層 (`apis/crud/`)

- DB操作のみを行う。ビジネスロジックは含めない
- `psycopg2.extras.RealDictCursor` を使用してdict形式で結果を返す
- SQLインジェクション防止のため、**必ずパラメータ化クエリ（%sプレースホルダー）を使用**する
- 削除フラグがあるテーブルでは、削除フラグを考慮してSQLを組み立てる
- 関数のdocstringにArgs/Returns/Raisesを記載する
- **WHERE句で主キーを指定する際は、必ず `supabase/schema.sql` を参照して正しいカラム名を使用する**（下記「主要テーブルの主キー」参照）

#### 主要テーブルの主キー

| テーブル | 主キーカラム | 注意 |
|----------|-------------|------|
| `app_users` | `id` | |
| `providers` | `user_id` | `id`ではないので注意 |
| `receivers` | `user_id` | `id`ではないので注意 |
| `shifts` | `id` | |
| `reservations` | `id` | |
| `service_logs` | `id` | |
| `provider_profiles` | `id` (`user_id`はFK) | |
| `receiver_profiles` | `id` (`user_id`はFK) | |

```python
# CRUD層の実装パターン例
def get_something(db, some_id: str):
    cur = db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
        SELECT col1, col2
        FROM some_table
        WHERE user_id = %s  -- テーブルの主キーカラム名はschema.sqlで確認すること
    """, (some_id,))
    return cur.fetchone()
```

### サービス層 (`apis/services/`)

- CRUD層を呼び出してビジネスロジックを組み立てる
- CRUD層のimportは `from ..crud import xxx as xxx_crud` のパターンを使用する
- 不正な状態では `ValueError` を送出する（ルーター層でHTTPExceptionに変換）

```python
# サービス層の実装パターン例
from ..crud import something as something_crud

def get_something(db, some_id: str):
    row = something_crud.get_something(db, some_id)
    if not row:
        raise ValueError(f"Not found: {some_id}")
    return row
```

### ルーター層 (`apis/*.py`)

- `APIRouter()` を使用し、エンドポイントを定義する
- RBAC制御は `dependencies=[Depends(require_role("admin"))]` で行う
- サービス層の `ValueError` を `HTTPException(404, ...)` に変換する
- バリデーションチェック（年月の範囲等）はルーター層で行う
- 不整合は400エラーを返す

### スキーマ (`apis/schemas.py`)

- Pydantic `BaseModel` を継承する
- Enumは `str, Enum` を継承して定義する
- Optional フィールドには `Optional[str] = None` のようにデフォルト値を設定する

---

## テスト実装規約

### ファイル配置

```
apis/tests/
├── conftest.py              # 共通フィクスチャ（mock_db, mock_cursor）
├── crud/
│   ├── __init__.py
│   └── test_<機能名>.py     # CRUD層テスト
└── services/
    ├── __init__.py
    └── test_<機能名>.py     # サービス層テスト
```

### 共通フィクスチャ（conftest.py）

`apis/tests/conftest.py` に定義済み。新規テストファイルでは自動的に利用可能。

- `mock_cursor`: RealDictCursor相当のモックカーソル
- `mock_db`: DB接続モック（`mock_cursor` を返す）

### CRUD層テスト

- `mock_db`, `mock_cursor` フィクスチャを使用する
- SQLに期待するカラムやテーブル名が含まれていることを検証する
- `fetchone` / `fetchall` のモック戻り値を設定してテストする

### サービス層テスト

- `@patch("apis.services.<module>.<crud_module>")` でCRUD層をモックする
- CRUD層の戻り値を設定し、サービス層のビジネスロジック（フィールドの変換、NULLクリア等）を検証する
- 異常系では `pytest.raises(ValueError)` を使用する

---

## テスト実行手順

### 重要: テストはDockerコンテナ内で実行する

ローカル環境にはPython仮想環境（venv）がなく、システムPythonは`externally-managed-environment`のためパッケージインストールができない。**必ずDockerコンテナ内でテストを実行すること。**

### 手順

#### 1. コンテナの起動確認

```bash
docker ps --filter "name=tomodachi" --format "table {{.Names}}\t{{.Status}}"
```

#### 2. コンテナが停止している場合は起動する

```bash
docker start tomodachi-postgres tomodachi-devcontainer
```

**注意**: `docker compose up -d` を実行すると、既存のコンテナ名と衝突してエラーになる場合がある。その場合は `docker start` で既存コンテナを再起動する。

#### 3. テスト実行

```bash
docker exec -w /workspace tomodachi-devcontainer python -m pytest apis/tests/<対象テスト> -v
```

#### 4. 全テスト実行（既存テストへの影響確認）

```bash
docker exec -w /workspace tomodachi-devcontainer python -m pytest apis/tests/ -v
```

### pytestについて

- `requirements.txt` に `pytest` が含まれており、Dockerイメージビルド時にインストール済み
- `docker start` によるコンテナ再起動ではファイルシステムが保持されるため、**毎回 `pip install pytest` する必要はない**
- `docker compose up --build` でイメージを再ビルドした場合も、requirements.txt経由で自動インストールされる

---

## 過去に発生したエラーと対処法

### 1. ローカルでのpytest実行失敗

**現象**: `python -m pytest` で `No module named pytest` エラー

**原因**: ローカルにvenvがなく、システムPythonに`externally-managed-environment`制約がある

**対処**: Dockerコンテナ内で実行する（上記「テスト実行手順」参照）

### 2. Docker Compose起動時のコンテナ名衝突

**現象**: `docker compose -f .devcontainer/docker-compose.yml up -d` で `Conflict. The container name "/tomodachi-postgres" is already in use` エラー

**原因**: 以前のセッションで作成されたコンテナが停止状態で残っている

**対処**: `docker start tomodachi-postgres tomodachi-devcontainer` で既存コンテナを再起動する。`docker compose up` は不要。

### 3. Pythonシンタックスチェック

Dockerコンテナが起動していない場合でも、構文チェックだけはローカルで可能。

```bash
python3 -c "
import ast
for f in ['apis/crud/xxx.py', 'apis/services/xxx.py']:
    with open(f) as fh:
        ast.parse(fh.read())
    print(f'OK: {f}')
"
```

---

## 実装時の判断指針

### 既存コードの拡張 vs 新規作成

- 既存の関数がすでに必要なテーブルをJOINしている場合、SELECTカラムの追加だけで済む場合がある。新規関数や追加クエリを安易に作らず、既存コードの拡張で対応できないかをまず検討する
- ルーター層がサービス層の結果をそのまま返している場合、サービス層の変更だけでルーター層の変更が不要になる場合がある

### 変更の影響範囲

- 共通関数を変更する場合は、その関数を呼び出している全箇所を確認する
- 例: `calc_monthly_payroll` を変更すると、`calc_all_providers_payroll` にも自動的に影響する（内部で呼び出しているため）
