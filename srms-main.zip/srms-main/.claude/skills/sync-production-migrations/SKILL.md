---
name: sync-production-migrations
description: 本番 Supabase の migration 状況確認や未適用 migration の適用判断が必要なときに使う。状態確認はエージェントが行い、supabase login と db push はユーザーが実行する前提で案内する。
---

# 本番 Migration 同期

## 概要

このスキルでは、エージェントは本番 migration の状態確認、差分判定、次に実行すべきコマンドの提示を行います。

次のコマンドはユーザーがターミナルで実行する前提です。

- `npx supabase login`
- 必要ならバックアップ取得コマンド
- `npx supabase db push`

適用後の確認は再度エージェントが行います。

基準ドキュメントは `/workspace/doc/development/DATABASE_MIGRATION.md` です。

## 事前確認

次を確認してから進めます。

- 依頼が本番 Supabase の migration 確認または適用であること。
- `supabase/migrations` が存在すること。
- 本番 `PROJECT-REF` が明示されていること。
- ユーザーが `npx supabase login` を実行済みであること。
- バックアップ無しで進める場合は、ユーザーが明示的に了承していること。

`PROJECT-REF` が無い場合は次を使います。

```text
本番 Supabase の PROJECT-REF が必要です。未提示なら共有してください。提示後に本番 migration 状況を確認します。
```

login 未確認なら次を使います。

```text
先に Supabase CLI の認証が必要です。ターミナルで `npx supabase login` を実行してください。完了後に本番 migration 状況の確認を続けます。
```

## 基本フロー

### 1. 状態確認

エージェントが次を実行して、local と remote の差分を確認します。

```bash
python3 .claude/skills/sync-production-migrations/scripts/check_and_apply.py \
	--project-ref "$PROJECT_REF"
```

pending が無ければ終了します。

### 2. 適用前の案内生成

pending がある場合、エージェントは次を実行して、ユーザーが実行すべきコマンド一覧を取得します。

バックアップあり:

```bash
python3 .claude/skills/sync-production-migrations/scripts/check_and_apply.py \
	--project-ref "$PROJECT_REF" \
	--apply
```

バックアップ無し:

```bash
python3 .claude/skills/sync-production-migrations/scripts/check_and_apply.py \
	--project-ref "$PROJECT_REF" \
	--apply \
	--skip-backup
```

このスクリプトは `db push` を自動実行しません。JSON の `manual_commands` に入ったコマンドをユーザーへ提示します。

### 3. ユーザー実行

ユーザーが `manual_commands` をターミナルで実行します。

### 4. 適用後確認

ユーザー実行後、エージェントがもう一度状態確認を実行し、pending が消えたことを確認します。

## 報告項目

エージェントは次を報告します。

- project ref
- local versions
- remote versions
- pending versions
- `manual_apply_required`
- `manual_commands`
- `up_to_date`

## 注意点

- ユーザー向け説明は日本語で行います。
- スクリプト本体と機械可読出力は英語のままで構いません。
- `PROJECT-REF` が確認できない場合は進めません。
- `npx supabase login` と `npx supabase db push` はユーザー実行前提です。
- `--skip-backup` はユーザーが明示了承した場合のみ使います。
- remote 側にローカルに無い version がある場合は自動で進めません。
