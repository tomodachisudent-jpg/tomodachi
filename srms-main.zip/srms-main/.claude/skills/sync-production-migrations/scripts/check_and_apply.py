#!/usr/bin/env python3

import argparse
import json
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


MIGRATION_PATTERN = re.compile(r"^(\d{14})_.*\.sql$")
TABLE_LINE_PATTERN = re.compile(r"^\|(?P<local>.*?)\|(?P<remote>.*?)\|(?P<time>.*?)\|$")


@dataclass
class MigrationStatus:
    local_versions: list[str]
    remote_versions: list[str]
    pending_versions: list[str]
    extra_remote_versions: list[str]


def build_manual_commands(project_ref: str, skip_backup: bool) -> list[str]:
    commands: list[str] = []

    if not skip_backup:
        commands.extend(
            [
                "mkdir -p supabase/backup",
                "TIMESTAMP=$(date +%Y%m%d_%H%M%S)",
                "npx supabase db dump -f supabase/backup/production_schema_${TIMESTAMP}.sql",
                "npx supabase db dump --role-only -f supabase/backup/production_roles_${TIMESTAMP}.sql",
                "npx supabase db dump --data-only -f supabase/backup/production_data_${TIMESTAMP}.sql",
                "ls -lh supabase/backup/production_*_${TIMESTAMP}.sql",
            ]
        )

    commands.extend(
        [
            f"npx supabase link --project-ref {project_ref}",
            "npx supabase db push",
            "npx supabase migration list",
        ]
    )
    return commands


def run_command(args: list[str], cwd: Path, capture_output: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=str(cwd),
        text=True,
        capture_output=capture_output,
        check=False,
        env=None,
    )


def build_cli_error(result: subprocess.CompletedProcess[str], fallback: str) -> str:
    message = result.stderr.strip() or result.stdout.strip() or fallback
    lowered = message.lower()
    auth_markers = [
        "access token",
        "not logged in",
        "authentication required",
        "failed to load access token",
        "invalid access token",
    ]
    if any(marker in lowered for marker in auth_markers):
        return f"{message}\nRun `npx supabase login` before retrying this script."
    return message


def require_project_ref(project_ref: str | None) -> str:
    if project_ref:
        return project_ref
    print(
        "PROJECT-REF is required. Ask the user for the production PROJECT-REF before running this script.",
        file=sys.stderr,
    )
    sys.exit(2)


def get_repo_root(explicit_workdir: str | None) -> Path:
    if explicit_workdir:
        return Path(explicit_workdir).resolve()
    return Path.cwd()


def load_local_versions(repo_root: Path) -> list[str]:
    migrations_dir = repo_root / "supabase" / "migrations"
    if not migrations_dir.exists():
        raise FileNotFoundError(f"Missing migrations directory: {migrations_dir}")

    versions: list[str] = []
    for path in sorted(migrations_dir.iterdir()):
        if not path.is_file():
            continue
        match = MIGRATION_PATTERN.match(path.name)
        if match:
            versions.append(match.group(1))
    return versions


def ensure_supabase_link(repo_root: Path, project_ref: str) -> None:
    result = run_command(
        ["npx", "supabase", "link", "--project-ref", project_ref],
        cwd=repo_root,
    )
    if result.returncode != 0:
        raise RuntimeError(build_cli_error(result, "supabase link failed"))


def fetch_migration_list_output(repo_root: Path) -> str:
    result = run_command(["npx", "supabase", "migration", "list"], cwd=repo_root)
    if result.returncode != 0:
        raise RuntimeError(build_cli_error(result, "supabase migration list failed"))
    return result.stdout


def parse_table_cell(cell: str) -> str | None:
    value = cell.strip().strip("`").strip()
    if not value:
        return None
    if value.lower() in {"local", "remote", "time (utc)", "---"}:
        return None
    return value


def parse_fixed_width_line(line: str) -> tuple[str | None, str | None] | None:
    if "|" not in line:
        return None

    parts = [part.strip() for part in line.split("|")]
    if len(parts) != 3:
        return None

    local_value = parse_table_cell(parts[0])
    remote_value = parse_table_cell(parts[1])
    if local_value is None and remote_value is None:
        return None
    return local_value, remote_value


def parse_remote_versions(table_output: str) -> list[str]:
    remote_versions: list[str] = []
    for raw_line in table_output.splitlines():
        line = raw_line.strip()
        if not line or set(line) <= {"-", " ", "|"}:
            continue

        remote_value: str | None = None
        if line.startswith("|"):
            match = TABLE_LINE_PATTERN.match(line)
            if match:
                remote_value = parse_table_cell(match.group("remote"))
        else:
            parsed = parse_fixed_width_line(line)
            if parsed:
                _, remote_value = parsed

        if remote_value and remote_value.isdigit():
            remote_versions.append(remote_value)
    return sorted(set(remote_versions))


def compare_versions(local_versions: list[str], remote_versions: list[str]) -> MigrationStatus:
    local_set = set(local_versions)
    remote_set = set(remote_versions)
    pending = sorted(local_set - remote_set)
    extra_remote = sorted(remote_set - local_set)
    return MigrationStatus(
        local_versions=local_versions,
        remote_versions=remote_versions,
        pending_versions=pending,
        extra_remote_versions=extra_remote,
    )


def print_summary(
    project_ref: str,
    status: MigrationStatus,
    backups_created: bool,
    push_executed: bool,
    manual_apply_required: bool = False,
    manual_commands: list[str] | None = None,
) -> None:
    summary = {
        "project_ref": project_ref,
        "local_versions": status.local_versions,
        "remote_versions": status.remote_versions,
        "pending_versions": status.pending_versions,
        "extra_remote_versions": status.extra_remote_versions,
        "backups_created": backups_created,
        "push_executed": push_executed,
        "manual_apply_required": manual_apply_required,
        "manual_commands": manual_commands or [],
        "up_to_date": not status.pending_versions and not status.extra_remote_versions,
    }
    print(json.dumps(summary, indent=2))


def main() -> int:
    parser = argparse.ArgumentParser(description="Check production Supabase migration status and prepare manual apply steps.")
    parser.add_argument("--project-ref", help="Production Supabase PROJECT-REF")
    parser.add_argument("--apply", action="store_true", help="Print manual commands for applying pending migrations")
    parser.add_argument(
        "--skip-backup",
        action="store_true",
        help="Print manual apply commands without backup commands",
    )
    parser.add_argument("--workdir", help="Repository root. Defaults to current directory")
    args = parser.parse_args()

    if args.skip_backup and not args.apply:
        print("--skip-backup can only be used together with --apply.", file=sys.stderr)
        return 2

    project_ref = require_project_ref(args.project_ref)
    repo_root = get_repo_root(args.workdir)

    local_versions = load_local_versions(repo_root)
    ensure_supabase_link(repo_root, project_ref)
    table_output = fetch_migration_list_output(repo_root)
    remote_versions = parse_remote_versions(table_output)

    status = compare_versions(local_versions, remote_versions)

    if status.extra_remote_versions:
        print_summary(project_ref, status, backups_created=False, push_executed=False)
        print(
            "Remote migration history contains versions that do not exist locally. Review manually before any push.",
            file=sys.stderr,
        )
        return 3

    if not args.apply or not status.pending_versions:
        print_summary(project_ref, status, backups_created=False, push_executed=False)
        return 0

    print_summary(
        project_ref,
        status,
        backups_created=False,
        push_executed=False,
        manual_apply_required=True,
        manual_commands=build_manual_commands(project_ref, args.skip_backup),
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
