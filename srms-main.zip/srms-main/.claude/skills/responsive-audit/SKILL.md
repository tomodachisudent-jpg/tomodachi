---
name: responsive-audit
description: スマホの画面サイズで横スクロールの発生、見切れがないかを確認する。フロントエンドをテストするときに使用する。
---

## Purpose

Quasar (SPA) アプリにおいて、スマホ・タブレット幅での

- 横スクロールの発生
- 要素の見切れ（viewport 外へのはみ出し）
  を **ローカル環境のみ**で自動検出する。

Playwright を用い、DOMベースの検知とスクリーンショット取得により、
「どの要素が・どの画面幅で・どれだけはみ出したか」を特定する。

---

## Scope / Assumptions

- Framework: Quasar Framework
- Mode: SPA
- Environment: local dev only（CI 非対応）
- Dev server は事前に `quasar dev` で起動済み
- テスト実行時に `BASE_URL` が環境変数で渡される

---

## Default Configuration

### Viewports

以下をデフォルトとする（必要に応じて追加・削除可）

- iphone-se: 375 x 667
- iphone-14: 390 x 844
- android-small: 360 x 800
- tablet: 768 x 1024

### Routes

- `/`
- `/login`
- `/settings`

※ 実アプリの主要導線（一覧 / 詳細 / 入力フォーム）に合わせて変更すること。

---

## Detection Rules

### 1. Page-level Horizontal Scroll (Critical)

以下を満たす場合、即 NG とする。

```

document.documentElement.scrollWidth

>

document.documentElement.clientWidth

```

理由:

- UX 的に致命的
- ほぼ確実に CSS 設計ミス（固定幅 / 画像 / 長文など）

---

### 2. Element-level Overflow (Primary)

各要素について以下を評価する。

- `getBoundingClientRect()` を使用
- viewport 左右にはみ出している要素を offenders として記録

判定条件（X方向）:

- rect.right > viewportWidth
- rect.left < 0

---

### 3. Visibility Filter

以下の要素は検査対象外とする。

- `display: none`
- `visibility: hidden`
- width / height が極小（<= 2px）

---

### 4. Allowed Overflow (Exception Rule)

以下の属性を持つ要素配下は「意図的な横スクロール」とみなし除外する。

```html
<div data-allow-overflow="true"></div>
```

想定例:

- 横スクロール前提のテーブル
- コードブロック

---

## Stabilization for Quasar

### Disable Animations (Test Only)

Quasar は transition / animation が多いため、
E2E 実行中は以下の CSS を inject して無効化する。

```css
*,
*::before,
*::after {
  transition: none !important;
  animation: none !important;
  scroll-behavior: auto !important;
}
```

目的:

- レイアウト揺れによる誤検知防止
- テストの再現性向上

---

## Artifacts

### Screenshots

- 各 route × viewport ごとに fullPage screenshot を保存
- Path例:

```
reports/screens/{viewport}_{route}.png
```

### Offenders Log

各テスト失敗時に以下情報を JSON 形式で出力する。

- route
- viewport (name / width / height)
- selector（簡易）
- innerText（先頭80文字）
- rect（left / right / width）

---

## Typical Root Causes (Diagnosis Guide)

offenders が検出された場合、以下を優先的に疑う。

1. 固定幅 / min-width の指定
   - `width: 400px`
   - `min-width: 600px`

2. 長い英数字・URL・UUID
   - `overflow-wrap: anywhere`
   - `word-break: break-word`

3. 画像・動画
   - `max-width: 100%`
   - `height: auto`

4. Quasar Layout 系
   - QDrawer の width
   - fixed header / footer による押し出し

---

## Execution Checklist

1. `quasar dev` を起動済みであること
2. 実際の dev server URL を BASE_URL に設定
3. Playwright テストを実行
4. 失敗時:
   - offenders を確認
   - 該当スクショを確認
   - CSS / Quasar component を修正

---

## Non-goals

- Visual regression（ピクセル差分）の厳密比較
- CI / GitHub Actions 対応
- SSR / PWA / Mobile モード対応

---

## Recommended Extensions

- Vue Router から routes を自動抽出
- offenders を CSV / Markdown に出力
- 重要画面のみスクショ差分比較を追加
