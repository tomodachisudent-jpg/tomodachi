<script setup>
import { defineProps } from 'vue'
import { useRouter } from 'vue-router'

const props = defineProps({
  link: {
    type: Object,
    required: true
  }
})

const router = useRouter()

const navigate = () => {
  router.push(props.link.to)
}
</script>

<template>
  <q-item clickable @click="navigate" v-ripple>
    <q-item-section avatar>
      <q-icon :name="link.icon" />
    </q-item-section>
    <q-item-section>
      <q-item-label>{{ link.title }}</q-item-label>
    </q-item-section>
  </q-item>
</template>