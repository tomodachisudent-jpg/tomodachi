import { boot } from 'quasar/wrappers'
import axios from 'axios'
import { useAuthStore } from 'stores/auth'

export default boot(({ store }) => {
  const auth = useAuthStore(store)

  axios.defaults.baseURL = '/api' // Nginxが /api/ を FastAPI にプロキシ

  axios.interceptors.request.use(config => {
    if (auth.userInfo?.token) {
      config.headers.Authorization = `Bearer ${auth.userInfo.token}`
    }
    return config
  })
})

export { axios }