import { defineRouter } from '#q-app/wrappers'
import {
  createRouter,
  createMemoryHistory,
  createWebHistory,
  createWebHashHistory
} from 'vue-router'
import routes from './routes'
import { useAuthStore } from 'stores/auth'

export default defineRouter(function () {
  const createHistory = process.env.SERVER
    ? createMemoryHistory
    : process.env.VUE_ROUTER_MODE === 'history'
      ? createWebHistory
      : createWebHashHistory

  const Router = createRouter({
    scrollBehavior: () => ({ left: 0, top: 0 }),
    routes,
    history: createHistory(process.env.VUE_ROUTER_BASE)
  })

  // 🔐 グローバルナビゲーションガード
  Router.beforeEach((to, from, next) => {
    const auth = useAuthStore()

    // セッション復元（初回アクセス時）
    if (!auth.isLoggedIn) {
      auth.restoreSession()
    }

    // 認証が必要なルート
    if (to.meta.requiresAuth) {
      if (!auth.isLoggedIn) {
        return next({ path: '/login', query: { redirect: to.fullPath } })
      }

      // ロール制限がある場合
      if (to.meta.roles && !to.meta.roles.includes(auth.userRole)) {
        return next('/unauthorized')
      }
    }

    next()
  })

  return Router
})