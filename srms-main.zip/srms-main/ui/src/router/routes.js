const routes = [
  // ログイン画面（最初に表示）
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: 'login',
        component: () => import('pages/LoginPage.vue'),
      },
    ],
  },

  // ダッシュボード（ログイン後の共通画面）
  {
    path: '/dashboard',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/DashboardView.vue'),
        beforeEnter: (to, from, next) => {
          const isLoggedIn = localStorage.getItem('loggedIn') === 'true'
          if (isLoggedIn) next()
          else next('/login')
        },
      },
    ],
  },

  // アカウント情報画面（全ユーザー共通）
  {
    path: '/account',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/AccountView.vue'),
        meta: { requiresAuth: true },
      },
    ],
  },

  // カレンダー画面（提供者・受給者・管理者）
  {
    path: '/calendar',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/CalendarView.vue'),
        meta: { requiresAuth: true, roles: ['provider', 'receiver', 'admin'] },
      },
    ],
  },

  // 提供者向け：実績一覧
  {
    path: '/provider/history',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/ProviderHistory.vue'),
        meta: { requiresAuth: true, roles: ['provider'] },
      },
    ],
  },

  // 受給者向け：予約一覧
  {
    path: '/receiver/reservations',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/ReceiverReservations.vue'),
        meta: { requiresAuth: true, roles: ['receiver'] },
      },
    ],
  },

  // 管理者向け：ユーザ管理
  {
    path: '/admin/users',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/AdminUserManagement.vue'),
        meta: { requiresAuth: true, roles: ['admin'] },
      },
    ],
  },

  // 管理者向け：稼働状況確認
  {
    path: '/admin/analytics',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/AdminAnalytics.vue'),
        meta: { requiresAuth: true, roles: ['admin'] },
      },
    ],
  },

  // 管理者向け：給与計算
  {
    path: '/admin/payroll',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/PayrollPage.vue'),
        meta: { requiresAuth: true, roles: ['admin'] },
      },
    ],
  },

  // ROOMダイレクトリンク表示ページ（全ユーザー共通）
  {
    path: '/room/:shiftId',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/RoomView.vue'),
        meta: { requiresAuth: true },
      },
    ],
  },

  {
    path: '/about',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/AboutView.vue'),
        // meta: { requiresAuth: true }  // 任意で制限
      },
    ],
  },

  // LINEログイン後のコールバック表示ページ
  {
    path: '/line/callback',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/LineCallbackView.vue'),
      },
    ],
  },

  {
    path: '/provider/profile',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/ProviderProfile.vue'),
        meta: { requiresAuth: true, roles: ['provider'] },
      },
    ],
  },

  {
    path: '/receiver/profile',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/ReceiverProfile.vue'),
        meta: { requiresAuth: true, roles: ['receiver'] },
      },
    ],
  },

  {
    path: '/provider/profile/view/:id',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/ProviderProfileView.vue'),
        meta: { requiresAuth: true },
      },
    ],
  },

  {
    path: '/receiver/profile/view/:id',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/ReceiverProfileView.vue'),
        meta: { requiresAuth: true, roles: ['provider', 'admin'] },
      },
    ],
  },

  // 権限なし画面（任意）
  {
    path: '/unauthorized',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        component: () => import('pages/UnauthorizedPage.vue'),
      },
    ],
  },

  // 404ページ
  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue'),
  },
]

export default routes
