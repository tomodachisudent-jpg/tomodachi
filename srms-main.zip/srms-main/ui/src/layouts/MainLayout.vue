<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useQuasar } from 'quasar'
import { useAuthStore } from 'stores/auth'
import { useUnsavedStore } from 'stores/unsaved'
import MenuLink from 'components/MenuLink.vue'

const $q = useQuasar()
const router = useRouter()
const auth = useAuthStore()
const unsavedStore = useUnsavedStore()

const leftDrawerOpen = ref(false)

function toggleLeftDrawer() {
  leftDrawerOpen.value = !leftDrawerOpen.value
}

function closeDrawerOnMobile() {
  if ($q.screen.lt.md) {
    leftDrawerOpen.value = false
  }
}

// 未保存変更確認ダイアログ用
const showUnsavedDialog = ref(false)

function executeLogout() {
  auth.logout()
  router.push('/login')
}

async function handleLogoutChoice(choice) {
  showUnsavedDialog.value = false

  if (choice === 'save') {
    // 保存してからログアウト
    await unsavedStore.executeSave()
    executeLogout()
  } else if (choice === 'discard') {
    // 破棄してからログアウト
    unsavedStore.executeDiscard()
    executeLogout()
  }
  // キャンセルの場合は何もしない（ログアウトしない）
}

function logout() {
  // 未保存の変更がある場合は確認ダイアログを表示
  if (unsavedStore.hasUnsavedChanges) {
    showUnsavedDialog.value = true
  } else {
    // 未保存の変更がなければそのままログアウト
    executeLogout()
  }
}

// メニュー定義
const commonLinks = [{ title: 'アカウント情報', icon: 'person', to: '/account' }]

const providerLinks = [
  { title: 'カレンダー', icon: 'event', to: '/calendar' },
  { title: '提供実績一覧', icon: 'list', to: '/provider/history' },
  { title: 'プロフィール編集', icon: 'edit', to: '/provider/profile' },
]

const receiverLinks = [
  { title: 'カレンダー', icon: 'event', to: '/calendar' },
  { title: '予約一覧', icon: 'list_alt', to: '/receiver/reservations' },
  { title: 'プロフィール編集', icon: 'edit', to: '/receiver/profile' },
]

const adminLinks = [
  { title: 'カレンダー', icon: 'event', to: '/calendar' },
  { title: 'ユーザ管理', icon: 'manage_accounts', to: '/admin/users' },
  { title: '稼働状況確認', icon: 'bar_chart', to: '/admin/analytics' },
  { title: '給与計算', icon: 'payments', to: '/admin/payroll' },
]

// ロールに応じたメニュー構築
const linksList = computed(() => {
  const role = auth.userRole
  if (role === 'provider') return [...commonLinks, ...providerLinks]
  if (role === 'receiver') return [...commonLinks, ...receiverLinks]
  if (role === 'admin') return [...commonLinks, ...adminLinks]
  return [...commonLinks]
})
</script>

<template>
  <q-layout view="lHh Lpr lFf">
    <!-- ヘッダー -->
    <q-header elevated>
      <q-toolbar>
        <q-btn flat dense round icon="menu" aria-label="Menu" @click="toggleLeftDrawer" />
        <q-toolbar-title>友達日本語会話教室</q-toolbar-title>
        <q-btn flat icon="logout" @click="logout" />
      </q-toolbar>
    </q-header>

    <!-- ドロワー（メニュー） -->
    <q-drawer v-model="leftDrawerOpen" show-if-above bordered>
      <q-list class="column justify-between full-height">
        <div>
          <q-item-label header>メニュー</q-item-label>
          <MenuLink
            v-for="link in linksList"
            :key="link.title"
            :link="link"
            @click="closeDrawerOnMobile"
          />
        </div>

        <!-- 最下部に常に表示されるAboutリンク -->
        <div class="q-pa-sm">
          <q-separator />
          <q-item clickable to="/about" v-ripple @click="closeDrawerOnMobile">
            <q-item-section avatar>
              <q-icon name="info" />
            </q-item-section>
            <q-item-section>このアプリについて</q-item-section>
          </q-item>
        </div>
      </q-list>
    </q-drawer>

    <!-- ページ表示 -->
    <q-page-container>
      <router-view />
    </q-page-container>

    <!-- 未保存変更確認ダイアログ（ログアウト時） -->
    <q-dialog v-model="showUnsavedDialog" persistent>
      <q-card>
        <q-card-section class="row items-center">
          <q-avatar icon="warning" color="warning" text-color="dark" />
          <span class="q-ml-sm text-h6">未保存の変更があります</span>
        </q-card-section>

        <q-card-section>
          <p>ログアウト前に変更を保存しますか？</p>
        </q-card-section>

        <q-card-actions :vertical="$q.screen.lt.md" :align="$q.screen.lt.md ? '' : 'right'">
          <q-btn
            label="💾 保存してログアウト"
            color="primary"
            @click="handleLogoutChoice('save')"
            :class="$q.screen.lt.md ? 'q-mb-sm' : 'q-mr-sm'"
          />
          <q-btn
            label="🗑️ 破棄してログアウト"
            color="negative"
            @click="handleLogoutChoice('discard')"
            :class="$q.screen.lt.md ? 'q-mb-sm' : 'q-mr-sm'"
          />
          <q-btn
            label="✕ キャンセル"
            color="grey"
            outline
            @click="handleLogoutChoice('cancel')"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-layout>
</template>
