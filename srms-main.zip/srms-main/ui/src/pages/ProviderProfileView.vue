<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">プロフィール</div>

    <q-card>
      <q-card-section>

        <!-- 写真 -->
        <q-img
          :src="profile.photo_url || defaultPhoto"
          spinner-color="grey-5"
          style="max-width: 200px; border-radius: 8px;"
          class="q-mb-md"
        />

        <div><strong>呼んでほしい名前：</strong> {{ profile.name }}</div>
        <div><strong>職業：</strong> {{ profile.job }}</div>
        <div><strong>趣味：</strong> {{ profile.hobbies }}</div>
        <div><strong>I Like：</strong> {{ profile.likes }}</div>

        <div class="q-mt-md"><strong>対応言語：</strong>
          <span v-if="profile.lang_ja">日本語</span>
          <span v-if="profile.lang_en"> / 英語</span>
          <span v-if="profile.lang_other"> / その他</span>
        </div>

        <div><strong>提供形態：</strong>
          <span v-if="profile.in_person">対面</span>
          <span v-if="profile.online"> / オンライン</span>
        </div>

        <q-separator class="q-my-md" />

        <div><strong>みなさんへのメッセージ：</strong></div>
        <div class="q-mb-md">{{ profile.message }}</div>

        <div><strong>教えられる得意なこと：</strong></div>
        <div class="q-mb-md">{{ profile.skills }}</div>

        <div><strong>今までどんなことをやってきたか：</strong></div>
        <div class="q-mb-md">{{ profile.experience }}</div>

        <div><strong>どんな授業にしたいか：</strong></div>
        <div>{{ profile.lesson_style }}</div>

      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'

const route = useRoute()
const providerId = route.params.id

const defaultPhoto = '/images/default-profile.png'

const profile = ref({
  name: '',
  job: '',
  hobbies: '',
  likes: '',
  lang_ja: false,
  lang_en: false,
  lang_other: false,
  in_person: false,
  online: false,
  message: '',
  skills: '',
  experience: '',
  lesson_style: '',
  photo_url: ''
})

onMounted(async () => {
  try {
    const res = await axios.get(`/provider/profile/${providerId}`)
    Object.assign(profile.value, res.data || {})
  } catch {
    console.error('プロフィール取得に失敗しました')
  }
})
</script>
