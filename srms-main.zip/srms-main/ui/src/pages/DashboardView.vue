<template>
  <q-page class="q-pa-md">
    <div class="text-h5">ようこそ！ログイン成功です。</div>
    <q-btn label="ログアウト" @click="logout" color="negative" class="q-mt-md" />
  </q-page>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

function logout() {
  localStorage.removeItem('loggedIn')
  router.push('/login')
}
</script>
