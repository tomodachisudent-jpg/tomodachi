<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">生徒プロフィール</div>

    <!-- 生徒が見つからない場合のメッセージ -->
    <q-card v-if="isNotFound" class="bg-warning text-dark">
      <q-card-section>
        <div class="text-h6">⚠️ 生徒が見つかりません</div>
        <p class="q-mt-sm">指定されたIDの生徒情報は存在しないか、削除された可能性があります。</p>
      </q-card-section>
    </q-card>

    <!-- プロフィール表示 -->
    <q-card v-else>
      <q-card-section>

        <!-- 写真 -->
        <q-img
          :src="profile.profile_photo_url || defaultPhoto"
          spinner-color="grey-5"
          style="max-width: 200px; border-radius: 8px;"
          class="q-mb-md"
        />

        <div><strong>名前：</strong> {{ profile.name }}</div>
        <div><strong>年齢：</strong> {{ profile.age }}</div>
        <div><strong>性別：</strong> {{ profile.gender }}</div>
        <div><strong>国籍：</strong> {{ profile.nationality }}</div>

        <q-separator class="q-my-md" />

        <div><strong>自己紹介：</strong></div>
        <div class="q-mb-md">{{ profile.self_introduction }}</div>

        <div><strong>学習目標：</strong></div>
        <div class="q-mb-md">{{ profile.learning_goals }}</div>

        <div><strong>日本語レベル：</strong> {{ profile.japanese_level }}</div>

        <q-separator class="q-my-md" />

        <!-- オプション表示項目 -->
        <div v-if="profile.learning_history">
          <strong>学習歴：</strong>
          <div class="q-mb-md">{{ profile.learning_history }}</div>
        </div>

        <div v-if="profile.qualifications">
          <strong>資格：</strong>
          <div class="q-mb-md">{{ profile.qualifications }}</div>
        </div>

        <div v-if="profile.special_skills">
          <strong>特技：</strong>
          <div class="q-mb-md">{{ profile.special_skills }}</div>
        </div>

      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'

const route = useRoute()
const receiverId = route.params.id

const defaultPhoto = '/images/default-profile.png'
const isNotFound = ref(false)

const profile = ref({
  name: '',
  age: '',
  gender: '',
  nationality: '',
  self_introduction: '',
  learning_goals: '',
  learning_history: '',
  qualifications: '',
  special_skills: '',
  japanese_level: '',
  profile_photo_url: ''
})

onMounted(async () => {
  try {
    const res = await axios.get(`/receiver/profile/${receiverId}`)
    const data = res.data || {}
    Object.assign(profile.value, data)
    // 名前が空の場合は生徒が存在しないと判定
    isNotFound.value = !data.name
  } catch (err) {
    console.error('プロフィール取得に失敗しました:', err)
    console.error('エラーレスポンス:', err.response?.data)
    console.error('ステータスコード:', err.response?.status)
    isNotFound.value = true
  }
})
</script>