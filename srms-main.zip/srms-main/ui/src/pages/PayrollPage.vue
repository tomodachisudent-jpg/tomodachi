<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">給与計算</div>

    <!-- 検索フィルター -->
    <q-card class="q-mb-md">
      <q-card-section>
        <div class="row q-gutter-md items-end">
          <div class="col-auto" style="min-width: 150px">
            <q-select v-model="selectedYear" :options="yearOptions" label="対象年" outlined dense />
          </div>
          <div class="col-auto" style="min-width: 150px">
            <q-select
              v-model="selectedMonth"
              :options="monthOptions"
              label="対象月"
              outlined
              dense
            />
          </div>
          <div class="col-auto">
            <q-btn label="検索" color="primary" @click="fetchPayrollData" :loading="loading" />
          </div>
          <div class="col-auto">
            <q-btn
              label="CSVエクスポート"
              color="secondary"
              outline
              @click="exportCSV"
              :disable="payrollData.length === 0"
            />
          </div>
        </div>
      </q-card-section>
    </q-card>

    <!-- 給与一覧テーブル -->
    <q-table
      :rows="payrollData"
      :columns="columns"
      row-key="provider_id"
      flat
      bordered
      :loading="loading"
      no-data-label="データがありません"
    >
      <template v-slot:body-cell-provider_name="props">
        <q-td :props="props">
          <a
            href="javascript:void(0)"
            @click="showDetail(props.row)"
            class="text-primary"
            style="text-decoration: underline; cursor: pointer"
          >
            {{ props.row.provider_name }}
          </a>
        </q-td>
      </template>

      <template v-slot:body-cell-total_hours="props">
        <q-td :props="props"> {{ props.row.total_hours }} 時間 </q-td>
      </template>

      <template v-slot:body-cell-offline_hours="props">
        <q-td :props="props"> {{ props.row.offline_hours }} 時間 </q-td>
      </template>

      <template v-slot:body-cell-online_hours="props">
        <q-td :props="props"> {{ props.row.online_hours }} 時間 </q-td>
      </template>

      <template v-slot:body-cell-total_amount="props">
        <q-td :props="props">
          <strong>¥{{ props.row.total_amount.toLocaleString() }}</strong>
        </q-td>
      </template>

      <template v-slot:body-cell-payment_method="props">
        <q-td :props="props">
          {{ paymentMethodLabel(props.row.payment_method) }}
        </q-td>
      </template>

      <template v-slot:body-cell-is_transferred="props">
        <q-td :props="props">
          <q-badge :color="props.row.is_transferred ? 'positive' : 'grey'" :label="props.row.is_transferred ? '振込済み' : '未振込'" />
        </q-td>
      </template>

      <template v-slot:body-cell-transfer_action="props">
        <q-td :props="props">
          <q-btn
            v-if="!props.row.is_transferred"
            label="振込済みにする"
            color="primary"
            size="sm"
            outline
            @click="confirmTransfer(props.row)"
          />
        </q-td>
      </template>
    </q-table>

    <!-- 詳細ダイアログ -->
    <q-dialog v-model="detailDialog">
      <q-card style="width: 100%; max-width: 600px">
        <q-card-section>
          <div class="text-h6">給与詳細</div>
        </q-card-section>

        <q-separator />

        <q-card-section v-if="selectedProvider" style="word-break: break-word">
          <div class="q-mb-sm"><strong>先生名:</strong> {{ selectedProvider.provider_name }}</div>
          <div class="q-mb-sm"><strong>対象月:</strong> {{ selectedProvider.month }}</div>

          <q-separator class="q-my-md" />

          <div class="q-mb-sm">
            <strong>総授業時間:</strong> {{ selectedProvider.total_hours }} 時間
          </div>
          <div class="q-mb-sm">
            <strong>対面授業時間:</strong> {{ selectedProvider.offline_hours }} 時間
          </div>
          <div class="q-mb-sm">
            <strong>時給(対面):</strong> ¥{{
              selectedProvider.hourly_rate_offline.toLocaleString()
            }}
          </div>
          <div class="q-mb-sm">
            <strong>オンライン授業時間:</strong> {{ selectedProvider.online_hours }} 時間
          </div>
          <div class="q-mb-sm">
            <strong>時給(オンライン):</strong> ¥{{
              selectedProvider.hourly_rate_online.toLocaleString()
            }}
          </div>

          <q-separator class="q-my-md" />

          <div class="text-h6">
            <strong>総給与額:</strong> ¥{{ selectedProvider.total_amount.toLocaleString() }}
          </div>

          <q-separator class="q-my-md" />

          <div class="q-mb-sm">
            <strong>振込方法:</strong>
            {{ paymentMethodLabel(selectedProvider.payment_method) }}
          </div>
          <template v-if="selectedProvider.payment_method === 'bank'">
            <div class="q-mb-sm"><strong>銀行名:</strong> {{ selectedProvider.bank_name }}</div>
            <div class="q-mb-sm"><strong>支店名:</strong> {{ selectedProvider.bank_branch }}</div>
            <div class="q-mb-sm">
              <strong>口座種別:</strong> {{ selectedProvider.bank_account_type }}
            </div>
            <div class="q-mb-sm">
              <strong>口座番号:</strong> {{ selectedProvider.bank_account_number }}
            </div>
            <div class="q-mb-sm">
              <strong>口座名義:</strong> {{ selectedProvider.bank_account_holder }}
            </div>
          </template>
          <template v-if="selectedProvider.payment_method === 'paypay'">
            <div v-if="selectedProvider.paypay_id" class="q-mb-sm">
              <strong>PayPay ID:</strong> {{ selectedProvider.paypay_id }}
            </div>
            <div v-if="selectedProvider.paypay_phone_number" class="q-mb-sm">
              <strong>電話番号:</strong> {{ selectedProvider.paypay_phone_number }}
            </div>
          </template>
        </q-card-section>

        <q-separator />

        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import axios from 'axios'
import { useQuasar } from 'quasar'

const $q = useQuasar()

// 振込方法ラベル変換
const paymentMethodLabel = (method) => {
  const labels = { hand: '手渡し', bank: '銀行振込', paypay: 'PayPay' }
  return labels[method] || '未設定'
}

// 年月選択
const selectedYear = ref(new Date().getFullYear())
const selectedMonth = ref(new Date().getMonth() + 1)

// 年月のオプション
const yearOptions = computed(() => {
  const currentYear = new Date().getFullYear()
  const years = []
  for (let year = 2000; year <= currentYear + 1; year++) {
    years.push(year)
  }
  return years
})

const monthOptions = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

// データ
const payrollData = ref([])
const loading = ref(false)
const detailDialog = ref(false)
const selectedProvider = ref(null)

// テーブルカラム定義
const columns = [
  {
    name: 'provider_name',
    label: '先生名',
    field: 'provider_name',
    align: 'left',
    sortable: true,
  },
  {
    name: 'total_hours',
    label: '総授業時間',
    field: 'total_hours',
    align: 'right',
    sortable: true,
  },
  {
    name: 'offline_hours',
    label: '対面授業時間',
    field: 'offline_hours',
    align: 'right',
    sortable: true,
  },
  {
    name: 'online_hours',
    label: 'オンライン授業時間',
    field: 'online_hours',
    align: 'right',
    sortable: true,
  },
  {
    name: 'total_amount',
    label: '給与額',
    field: 'total_amount',
    align: 'right',
    sortable: true,
  },
  {
    name: 'payment_method',
    label: '振込方法',
    field: 'payment_method',
    align: 'center',
    sortable: true,
  },
  {
    name: 'is_transferred',
    label: '振込状態',
    field: 'is_transferred',
    align: 'center',
    sortable: true,
  },
  {
    name: 'transfer_action',
    label: '振込操作',
    align: 'center',
  },
]

// 給与データ取得
const fetchPayrollData = async () => {
  loading.value = true
  try {
    const res = await axios.get('/admin/payroll', {
      params: {
        year: selectedYear.value,
        month: selectedMonth.value,
      },
    })
    payrollData.value = res.data
    $q.notify({
      type: 'positive',
      message: '給与データを取得しました',
    })
  } catch (err) {
    $q.notify({
      type: 'negative',
      message: err.response?.data?.detail || '給与データの取得に失敗しました',
    })
  } finally {
    loading.value = false
  }
}

// 詳細表示
const showDetail = async (row) => {
  selectedProvider.value = row
  detailDialog.value = true
}

// 振込済み登録
const confirmTransfer = (row) => {
  $q.dialog({
    title: '振込確認',
    message: `${row.provider_name}の${selectedYear.value}年${selectedMonth.value}月の給与を振込済みにしますか？`,
    cancel: true,
    persistent: true,
  }).onOk(async () => {
    try {
      await axios.post(`/admin/payroll/${row.provider_id}/transfer`, {
        year: selectedYear.value,
        month: selectedMonth.value,
      })
      $q.notify({
        type: 'positive',
        message: '振込結果を登録しました',
      })
      await fetchPayrollData()
    } catch (err) {
      $q.notify({
        type: 'negative',
        message: err.response?.data?.detail || '振込結果の登録に失敗しました',
      })
    }
  })
}

// CSVエクスポート
const exportCSV = () => {
  if (payrollData.value.length === 0) {
    $q.notify({
      type: 'warning',
      message: 'エクスポートするデータがありません',
    })
    return
  }

  // CSVヘッダー
  const headers = [
    '先生名',
    '対象月',
    '総授業時間',
    '対面授業時間',
    'オンライン授業時間',
    '給与額',
    '対面授業時給',
    'オンライン授業時給',
    '振込方法',
  ]

  // CSVデータ
  const rows = payrollData.value.map((item) => [
    item.provider_name,
    item.month,
    item.total_hours,
    item.offline_hours,
    item.online_hours,
    item.total_amount,
    item.hourly_rate_offline,
    item.hourly_rate_online,
    paymentMethodLabel(item.payment_method),
  ])

  // CSV文字列生成
  const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n')

  // BOMを追加してUTF-8で保存（Excelで正しく開くため）
  const bom = '\uFEFF'
  const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' })

  // ダウンロード
  const link = document.createElement('a')
  const url = URL.createObjectURL(blob)
  link.setAttribute('href', url)
  link.setAttribute('download', `給与計算_${selectedYear.value}年${selectedMonth.value}月.csv`)
  link.style.visibility = 'hidden'
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)

  $q.notify({
    type: 'positive',
    message: 'CSVファイルをダウンロードしました',
  })
}

// 初期データ読み込み（当月）
onMounted(() => {
  fetchPayrollData()
})
</script>
