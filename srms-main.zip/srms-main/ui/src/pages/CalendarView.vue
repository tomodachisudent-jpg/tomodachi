<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">カレンダー</div>

    <vue-cal
      style="height: 600px"
      :time="true"
      :key="calendarView"
      v-model:active-view="calendarView"
      v-model:selected-date="selectedDate"
      :hide-weekdays="hideWeekdays"
      :events="filteredEvents"
      :event-classes="(ev) => ev.class"
      :disable-views="role === 'receiver' ? ['day'] : []"
      :on-event-create="false"
      :on-event-drag="false"
      :on-event-resize="false"
      :cell-classes="getCellClass"
      @event-click="handleEventClick"
      @cell-click="handleCellClick"
    />

    <!-- Provider用: シフト登録・編集 -->
    <q-dialog v-model="showShiftDialog" persistent>
      <q-card style="min-width: 350px; max-height: 80vh;">
        <q-card-section class="row items-center q-pb-none">
          <div class="text-h6">
            {{ selectedEvent?.id ? 'シフト編集' : 'シフト登録' }}
          </div>
          <q-space />
          <q-btn icon="close" flat round dense v-close-popup />
        </q-card-section>

        <q-card-section class="q-pt-sm" style="overflow-y: auto;">
          <q-input v-model="selectedEvent.title" label="タイトル（任意）" />

          <q-select
            v-model="selectedEvent.s_type"
            :options="shiftTypeOptions"
            label="シフト種別"
            filled
            class="q-mt-md"
          />

          <q-select
            v-model="selectedEvent.end"
            :options="endTimeOptions"
            label="終了時間"
            filled
            class="q-mt-md"
            map-options
          />

          <div class="q-mt-sm text-subtitle2">
            <template v-if="selectedEvent?.start && selectedEvent?.end">
              {{ formatDateTime(selectedEvent.start) }} 〜
              {{ formatDateTime(selectedEvent.end) }}
            </template>
            <template v-else>
              日時未定
            </template>
          </div>

          <div
            v-if="selectedEvent?.reserved_by_name"
            class="q-mt-sm text-negative"
          >
            予約者：{{ selectedEvent.reserved_by_name }}
          </div>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="キャンセル" @click="showShiftDialog = false" />

          <q-btn
            v-if="!selectedEvent?.id"
            label="登録"
            color="primary"
            @click="registerShift"
          />

          <q-btn
            v-if="selectedEvent?.id"
            label="更新"
            color="primary"
            :disable="selectedEvent?.is_locked || selectedEvent?.reserved_by"
            @click="updateShift"
          />

          <q-btn
            v-if="selectedEvent?.id"
            label="削除"
            color="negative"
            :disable="selectedEvent?.is_locked || selectedEvent?.reserved_by"
            @click="deleteShift"
          />

          <q-btn
            v-if="(role === 'provider' || role === 'admin') && selectedEvent?.id"
            label="ROOMを開く"
            color="secondary"
            @click="openRoom(selectedEvent.id)"
          />

          <q-btn
            v-if="selectedEvent?.reserved_by && !isCompleted(selectedEvent)"
            label="完了"
            color="positive"
            @click="completeShift"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- Receiver用: 個別イベント予約 -->
    <q-dialog v-model="showDialog" persistent>
      <q-card>
        <q-card-section>
          <div class="text-h6">
            {{ selectedEvent?.title || '未定義イベント' }}
          </div>

          <div class="text-subtitle2 q-mt-sm">
            {{ formatDateTime(selectedEvent?.start) }} 〜
            {{ formatDateTime(selectedEvent?.end) }}
          </div>

          <div
            v-if="selectedEvent?.provider_name"
            class="q-mt-sm text-primary"
          >
            提供者：
            <span
              class="provider-link"
              :data-id="selectedEvent.provider_id"
              @click="openProviderProfile(selectedEvent.provider_id)"
            >
              {{ selectedEvent.provider_name }}
            </span>
          </div>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="閉じる" @click="showDialog = false" />

          <q-btn
            v-if="role === 'receiver' && !selectedEvent?.reserved_by"
            label="予約する"
            color="primary"
            @click="reserve"
          />

          <q-btn
            v-if="
              role === 'receiver' &&
              String(selectedEvent?.reserved_by) === String(auth.userInfo.id) &&
              canCancel(selectedEvent)
            "
            label="キャンセル"
            color="negative"
            @click="cancelReservation"
          />

          <q-btn
            v-if="
              selectedEvent?.reserved_by &&
              String(selectedEvent?.reserved_by) === String(auth.userInfo.id)
            "
            label="ROOMを開く"
            color="secondary"
            @click="openRoom(selectedEvent.id)"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- Receiver用: まとめイベント（◎/〇/×） -->
    <q-dialog v-model="showCellEventListDialog">
      <q-card style="min-width: 380px;">
        <q-card-section>
          <div class="text-h6">
            {{ selectedGroupTitle }}
          </div>

          <div class="text-subtitle2 q-mt-xs">
            {{ selectedGroupTime }}
          </div>

          <q-separator class="q-my-sm" />

          <q-option-group
            v-model="selectedProviderId"
            :options="providerOptions"
            type="radio"
          >
            <template #label="scope">
              <span
                v-html="scope.label"
                @click="handleProviderLinkClick($event)"
              />
            </template>
          </q-option-group>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup />

          <q-btn
            v-if="selectedProviderId && !selectedProviderIsMine"
            label="予約する"
            color="primary"
            @click="reserveSelectedProvider"
          />

          <q-btn
            v-if="selectedProviderIsMine"
            label="キャンセル"
            color="negative"
            @click="cancelSelectedProvider"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- ROOM表示ダイアログ -->
    <q-dialog v-model="showRoomDialog">
      <q-card class="q-pa-md" style="max-width: 600px; width: 100%;">
        <q-card-section>
          <div class="text-h6">ROOM情報</div>

          <q-input
            v-model="roomData.meeting_url"
            label="会議URL"
            type="textarea"
            autogrow
            filled
            class="q-mt-sm"
            :readonly="role !== 'provider'"
          />

          <q-input
            v-model="roomData.materials"
            label="資料URL"
            type="textarea"
            autogrow
            filled
            class="q-mt-sm"
            :readonly="role !== 'provider'"
          />

          <q-btn
            v-if="role === 'provider'"
            label="更新"
            color="primary"
            class="q-mt-sm"
            @click="updateRoom"
          />
        </q-card-section>

        <q-separator />

        <q-card-section>
          <div class="text-subtitle1">コメント</div>

          <div
            v-for="comment in roomComments"
            :key="comment.created_at"
            class="q-mt-sm"
          >
            <div class="text-caption text-grey">
              {{ comment.display_name }}（{{ formatDateTime(comment.created_at) }}）
            </div>
            <div>{{ comment.content }}</div>
          </div>

          <q-input
            v-model="newComment"
            label="コメントを入力"
            filled
            class="q-mt-md"
          />

          <q-btn
            label="投稿"
            color="primary"
            @click="submitComment"
            class="q-mt-sm"
          />
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- Provider プロフィール表示ダイアログ -->
    <q-dialog v-model="showProviderProfileDialog">
      <q-card style="max-width: 500px; width: 100%;">
        <q-card-section>
          <div class="text-h6">プロフィール</div>

          <q-img
            :src="providerProfile?.photo_url || '/images/default-profile.png'"
            spinner-color="grey-5"
            style="max-width: 200px; border-radius: 8px;"
            class="q-mb-md"
          />

          <div><strong>名前：</strong> {{ providerProfile?.name }}</div>
          <div><strong>職業：</strong> {{ providerProfile?.job }}</div>
          <div><strong>趣味：</strong> {{ providerProfile?.hobbies }}</div>
          <div><strong>I Like：</strong> {{ providerProfile?.likes }}</div>

          <q-separator class="q-my-md" />

          <div><strong>メッセージ：</strong></div>
          <div class="q-mb-md">{{ providerProfile?.message }}</div>

          <div><strong>得意なこと：</strong></div>
          <div class="q-mb-md">{{ providerProfile?.skills }}</div>

          <div><strong>経験：</strong></div>
          <div class="q-mb-md">{{ providerProfile?.experience }}</div>

          <div><strong>授業スタイル：</strong></div>
          <div>{{ providerProfile?.lesson_style }}</div>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </q-page>
</template>



<script setup>
import VueCal from 'vue-cal'
import 'vue-cal/dist/vuecal.css'
import { ref, computed, onMounted, watch, onBeforeUnmount } from 'vue'
import { useAuthStore } from 'stores/auth'
import axios from 'axios'
import { date, useQuasar } from 'quasar'

const $q = useQuasar()
const auth = useAuthStore()
const role = auth.userRole
const allEvents = ref([])

const calendarView = ref('week')
const selectedDate = ref(new Date())
const threeDayMode = ref(false)

/* ============================================================
   Responsive View
============================================================ */
const hideWeekdays = computed(() => {
  if (!threeDayMode.value) return []
  const start = new Date(selectedDate.value)
  const daysToShow = [0, 1, 2].map(offset => {
    const d = new Date(start)
    d.setDate(start.getDate() + offset)
    const jsDay = d.getDay()
    return jsDay === 0 ? 7 : jsDay
  })
  const all = [1, 2, 3, 4, 5, 6, 7]
  return all.filter(n => !daysToShow.includes(n))
})

function updateView() {
  const width = window.innerWidth
  if (width < 500) {
    threeDayMode.value = false
    calendarView.value = 'day'
  } else {
    threeDayMode.value = false
    calendarView.value = 'week'
  }
}

/* ============================================================
   Fetch Shifts
============================================================ */
onMounted(async () => {
  try {
    let res
    if (role === 'provider') res = await axios.get('/provider/shifts')
    else if (role === 'receiver') res = await axios.get('/receiver/shifts')
    else if (role === 'admin') res = await axios.get('/admin/shifts')

    const myId = String(auth.userInfo.id)

    allEvents.value = res.data.map(shift => {
      const reservedId = shift.reserved_by ? String(shift.reserved_by) : null
      const isMine = reservedId === myId

      let eventClass = ''
      if (role === 'provider') {
        if (shift.is_completed) eventClass = 'completed-shift'
        else if (reservedId) eventClass = 'reserved-shift'
        else eventClass = 'open-shift'
      } else if (role === 'receiver') {
        if (shift.is_completed) eventClass = 'completed-shift'
        else if (shift.reservation_status === 'reserved') {
          if (isMine) eventClass = 'bg-blue-1 text-blue-9'
          else if (reservedId) eventClass = 'bg-grey-4 text-grey-7'
        }
      }

      return {
        id: shift.id,
        start: new Date(shift.start_at),
        end: new Date(shift.end_at),
        title:
          role === 'provider'
            ? `${shift.s_type === 'online' ? 'オンライン' : '対面'}${shift.reserved_by_name ? `：${shift.reserved_by_name}` : ''}`
            : !reservedId
              ? `${shift.provider_name || 'Provider'}（空き：${shift.s_type === 'online' ? 'オンライン' : '対面'}）`
              : isMine
                ? `${shift.provider_name || 'Provider'}（予約済：${shift.s_type === 'online' ? 'オンライン' : '対面'}）`
                : `${shift.provider_name || 'Provider'}（他人予約）`,
        s_type: shift.s_type,
        is_locked: shift.is_locked,
        reserved_by: shift.reserved_by,
        reserved_by_name: shift.reserved_by_name,
        provider_name: shift.provider_name || '',
        provider_id: shift.provider_id,
        reservation_id: shift.reservation_id,
        is_completed: shift.is_completed,
        class: eventClass
      }
    })

    updateView()
    window.addEventListener('resize', updateView)
  } catch (err) {
    console.error('シフト一覧取得失敗:', err)
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', updateView)
})

/* ============================================================
   Utility
============================================================ */
const formatDateTime = (value) => {
  const raw = value?.value || value
  if (!raw) return '未定義'
  const d = typeof raw === 'string' ? new Date(raw) : raw
  return d instanceof Date && !isNaN(d.getTime())
    ? date.formatDate(d, 'YYYY-MM-DD HH:mm')
    : '未定義'
}

/* ============================================================
   ◎ / 〇 / × まとめイベント生成（Receiver）
============================================================ */
function groupEventsByTime(events) {
  const map = new Map()
  for (const ev of events) {
    const key = ev.start.getTime() + '|' + ev.end.getTime()
    if (!map.has(key)) map.set(key, [])
    map.get(key).push(ev)
  }
  return map
}

function buildGroupedEventsForReceiver(events) {
  const grouped = groupEventsByTime(events)
  const result = []

  for (const [key, group] of grouped.entries()) {
    const [startMs, endMs] = key.split('|')
    const start = new Date(Number(startMs))
    const end = new Date(Number(endMs))

    const reserved = group.filter(ev => ev.reserved_by)
    const available = group.filter(ev => !ev.reserved_by)

    let marker = ''
    if (available.length === 0) marker = '×'
    else if (available.length >= 2 && reserved.length === 0) marker = '◎'
    else marker = '〇'

    const title = `${marker} 空き: ${available.length} / 全体: ${group.length}`

    result.push({
      id: group[0].id,
      start,
      end,
      title,
      class:
        marker === '×'
          ? 'completed-shift'
          : marker === '◎'
            ? 'open-shift'
            : 'reserved-shift',
      marker,
      group,
      provider_id: group[0].provider_id,
      provider_name: group[0].provider_name
    })
  }

  return result
}

/* ============================================================
   filteredEvents
============================================================ */
const filteredEvents = computed(() => {
  if (role === 'provider' || role === 'admin') {
    return allEvents.value
  }
  return buildGroupedEventsForReceiver(allEvents.value)
})

/* ============================================================
   Event Click / Register / Update / Delete / Reserve / Cancel
============================================================ */
const showShiftDialog = ref(false)
const showDialog = ref(false)
const selectedEvent = ref(null)

/* まとめイベント */
const showCellEventListDialog = ref(false)
const selectedCellEvents = ref([])
const selectedProviderId = ref(null)

/* Provider プロフィールダイアログ */
const showProviderProfileDialog = ref(false)
const providerProfile = ref(null)
const providerProfileId = ref(null)

/* Provider プロフィールを開く */
const openProviderProfile = async (providerId) => {
  if (!providerId) return
  providerProfileId.value = providerId

  try {
    const res = await axios.get(`/provider/profile/${providerId}`)
    providerProfile.value = res.data
    showProviderProfileDialog.value = true
  } catch {
    $q.notify({ type: 'negative', message: 'プロフィール取得に失敗しました' })
  }
}

/* providerOptions 内のリンククリックを拾う */
const handleProviderLinkClick = (event) => {
  const providerId = event.target.dataset.id
  if (providerId) {
    openProviderProfile(providerId)
  }
}

const shiftTypeOptions = [
  { label: 'オンライン', value: 'online' },
  { label: '対面', value: 'offline' }
]

/* ============================================================
   終了時間の選択肢（start と s_type に応じて動的生成）
   - オンライン: start+1h 〜 24:00
   - 対面: start+4h 〜 24:00
============================================================ */
const endTimeOptions = computed(() => {
  const ev = selectedEvent.value
  if (!ev?.start || !ev?.s_type?.value) return []

  const start = new Date(ev.start)
  const startHour = start.getHours()
  const minHours = ev.s_type.value === 'offline' ? 4 : 1

  const options = []

  const endOfDay = new Date(start)
  endOfDay.setDate(start.getDate() + 1)
  endOfDay.setHours(0, 0, 0, 0)

  for (let h = startHour + minHours; h <= 23; h++) {
    const end = new Date(start)
    end.setHours(h, 0, 0, 0)
    options.push({
      label: `${String(h).padStart(2, '0')}:00`,
      value: end
    })
  }

  const diffToMidnight = (24 - startHour)
  if (diffToMidnight >= minHours) {
    options.push({
      label: '24:00',
      value: endOfDay
    })
  }

  return options
})

/* s_type 変更時に end をリセット */
watch(
  () => selectedEvent.value?.s_type?.value,
  (newValue) => {
    const ev = selectedEvent.value
    if (!ev?.start || !newValue) return

    const start = new Date(ev.start)
    const minHours = newValue === 'offline' ? 4 : 1

    let end = new Date(start.getTime() + minHours * 60 * 60 * 1000)

    const endOfDay = new Date(start)
    endOfDay.setDate(start.getDate() + 1)
    endOfDay.setHours(0, 0, 0, 0)
    if (end > endOfDay) {
      end = endOfDay
    }

    ev.end = end
  }
)

function roundToHour(dateObj) {
  const d = new Date(dateObj)
  d.setMinutes(0, 0, 0)
  return d
}

const handleCellClick = (dateObj) => {
  if (role !== 'provider') return
  const start = roundToHour(dateObj)

  const defaultSType = shiftTypeOptions[0]
  const minHours = defaultSType.value === 'offline' ? 4 : 1

  const end = new Date(start.getTime() + minHours * 60 * 60 * 1000)

  selectedEvent.value = {
    start,
    end,
    title: '',
    s_type: defaultSType,
    roles: ['provider', 'receiver'],
    is_locked: false,
    reserved_by: null
  }

  showShiftDialog.value = true
}

/* まとめイベント・個別イベント共通クリック */
const handleEventClick = (event) => {
  const myId = String(auth.userInfo.id)
  const reservedId = event.reserved_by ? String(event.reserved_by) : null

  if (role === 'provider' || role === 'admin') {
    selectedEvent.value = {
      ...event,
      title: event.title,
      s_type:
        shiftTypeOptions.find((opt) => opt.value === event.s_type) ||
        shiftTypeOptions[0],
      reservation_id: event.reservation_id
    }

    selectedEvent.value.end = null

    showShiftDialog.value = true
    return
  }

  if (Array.isArray(event.group)) {
    selectedCellEvents.value = event.group

    const mine = event.group.find(ev => String(ev.reserved_by) === myId)
    selectedProviderId.value = mine ? Number(mine.id) : null

    showCellEventListDialog.value = true
    return
  }

  if (role === 'receiver') {
    if (reservedId && reservedId !== myId) return
    selectedEvent.value = { ...event }
    showDialog.value = true
  }
}

/* ============================================================
   Provider: Register / Update / Delete
============================================================ */
const registerShift = async () => {
  try {
    const rawStart = selectedEvent.value.start?.value || selectedEvent.value.start
    const rawEnd = selectedEvent.value.end?.value || selectedEvent.value.end

    const start = typeof rawStart === 'string' ? new Date(rawStart) : rawStart
    const end = typeof rawEnd === 'string' ? new Date(rawEnd) : rawEnd

    const s_type = selectedEvent.value.s_type.value
    const sTypeLabel = selectedEvent.value.s_type.label

    const hours = (end.getTime() - start.getTime()) / (60 * 60 * 1000)

    for (let i = 0; i < hours; i++) {
      const slotStart = new Date(start.getTime() + i * 60 * 60 * 1000)
      const slotEnd = new Date(slotStart.getTime() + 60 * 60 * 1000)

      const payload = {
        start_at: slotStart.toISOString(),
        end_at: slotEnd.toISOString(),
        s_type
      }

      const res = await axios.post('/provider/shifts', payload)

      allEvents.value.push({
        id: res.data.id,
        start: slotStart,
        end: slotEnd,
        s_type,
        title: sTypeLabel,
        roles: ['provider', 'receiver'],
        is_locked: false,
        reserved_by: null
      })
    }

    showShiftDialog.value = false
  } catch {
    //
  }
}

const updateShift = async () => {
  try {
    await axios.delete(`/provider/shifts/${selectedEvent.value.id}`)
    await registerShift()
  } catch {
    //
  }
}

const deleteShift = async () => {
  try {
    await axios.delete(`/provider/shifts/${selectedEvent.value.id}`)
    allEvents.value = allEvents.value.filter(
      (ev) => ev.id !== selectedEvent.value.id
    )
    showShiftDialog.value = false
  } catch {
    //
  }
}

/* ============================================================
   Receiver: 個別イベント予約
============================================================ */
const reserve = async () => {
  try {
    await axios.post(`/receiver/shifts/${selectedEvent.value.id}/reserve`)
    const idx = allEvents.value.findIndex(
      (ev) => ev.id === selectedEvent.value.id
    )
    if (idx !== -1) {
      const ev = allEvents.value[idx]
      ev.reserved_by = String(auth.userInfo.id)
      ev.reserved_by_name = String(auth.userInfo.name)
    }
    $q.notify({ type: 'positive', message: '予約が完了しました' })
    showDialog.value = false
  } catch (err) {
    $q.notify({
      type: 'negative',
      message: err.response?.data?.detail || '予約に失敗しました'
    })
  }
}

const cancelReservation = async () => {
  try {
    await axios.post(`/receiver/shifts/${selectedEvent.value.id}/cancel`)
    const idx = allEvents.value.findIndex(
      (ev) => ev.id === selectedEvent.value.id
    )
    if (idx !== -1) {
      const ev = allEvents.value[idx]
      ev.reserved_by = null
      ev.reserved_by_name = null
    }
    showDialog.value = false
  } catch {
    //
  }
}

/* ============================================================
   まとめイベント: Provider ラジオ選択 + 予約 / キャンセル
============================================================ */
const selectedGroupTitle = computed(() => {
  if (!selectedCellEvents.value.length) return ''
  const evs = selectedCellEvents.value
  const marker = evs[0].marker || ''
  const available = evs.filter((e) => !e.reserved_by).length
  const total = evs.length
  return `${marker} 空き: ${available} / 全体: ${total}`
})

const selectedGroupTime = computed(() => {
  if (!selectedCellEvents.value.length) return ''
  const ev = selectedCellEvents.value[0]
  return `${formatDateTime(ev.start)} 〜 ${formatDateTime(ev.end)}`
})

const providerOptions = computed(() => {
  return selectedCellEvents.value
    .filter(ev => ev && ev.id)
    .map(ev => {
      const providerId = ev.provider_id
      const name = ev.provider_name || 'Provider'

      return {
        label: providerId
          ? `<span class="provider-link" data-id="${providerId}">${name}</span>`
          : name,
        value: Number(ev.id),
        disable: !!ev.reserved_by && String(ev.reserved_by) !== String(auth.userInfo.id)
      }
    })
})

const selectedProviderIsMine = computed(() => {
  const ev = selectedCellEvents.value.find(
    e => Number(e.id) === Number(selectedProviderId.value)
  )
  if (!ev) return false
  return String(ev.reserved_by) === String(auth.userInfo.id)
})

const reserveSelectedProvider = async () => {
  const ev = selectedCellEvents.value.find(
    e => Number(e.id) === Number(selectedProviderId.value)
  )
  if (!ev) return

  try {
    await axios.post(`/receiver/shifts/${ev.id}/reserve`)

    const idx = allEvents.value.findIndex(e => e.id === ev.id)
    if (idx !== -1) {
      allEvents.value[idx].reserved_by = String(auth.userInfo.id)
      allEvents.value[idx].reserved_by_name = auth.userInfo.name
    }

    $q.notify({ type: 'positive', message: '予約が完了しました' })
    showCellEventListDialog.value = false
  } catch (err) {
    $q.notify({
      type: 'negative',
      message: err.response?.data?.detail || '予約に失敗しました'
    })
  }
}

const cancelSelectedProvider = async () => {
  const ev = selectedCellEvents.value.find(
    e => Number(e.id) === Number(selectedProviderId.value)
  )
  if (!ev) return

  try {
    await axios.post(`/receiver/shifts/${ev.id}/cancel`)

    const idx = allEvents.value.findIndex(e => e.id === ev.id)
    if (idx !== -1) {
      allEvents.value[idx].reserved_by = null
      allEvents.value[idx].reserved_by_name = null
    }

    $q.notify({ type: 'positive', message: '予約をキャンセルしました' })
    showCellEventListDialog.value = false
  } catch (err) {
    $q.notify({
      type: 'negative',
      message: err.response?.data?.detail || 'キャンセルに失敗しました'
    })
  }
}

/* ============================================================
   Cell Class
============================================================ */
function getCellClass({ date }) {
  if (role !== 'receiver') return ''
  const myId = String(auth.userInfo.id)

  const found = allEvents.value.find((ev) => {
    const reservedId = ev.reserved_by ? String(ev.reserved_by) : null
    return (
      ev.start <= date &&
      ev.end > date &&
      reservedId &&
      reservedId !== myId
    )
  })

  return found ? 'bg-grey-2' : ''
}


/* ============================================================
   ROOM 関連
============================================================ */
const showRoomDialog = ref(false)
const roomData = ref({})
const roomComments = ref([])
const newComment = ref('')

const openRoom = async (shiftId) => {
  try {
    const roomRes = await axios.get(`/rooms/${shiftId}`)
    roomData.value = roomRes.data

    const commentRes = await axios.get(`/rooms/${roomRes.data.id}/comments`)
    roomComments.value = commentRes.data
    showRoomDialog.value = true
  } catch {
    $q.notify({ type: 'negative', message: 'ROOM情報の取得に失敗しました' })
  }
}

const submitComment = async () => {
  try {
    await axios.post(`/rooms/${roomData.value.id}/comments`, {
      content: newComment.value
    })
    roomComments.value.push({
      content: newComment.value,
      created_at: new Date().toISOString(),
      display_name: auth.userInfo.name
    })
    newComment.value = ''
  } catch {
    $q.notify({ type: 'negative', message: 'コメント投稿に失敗しました' })
  }
}

const updateRoom = async () => {
  try {
    await axios.put(`/rooms/${selectedEvent.value.id}`, {
      meeting_url: roomData.value.meeting_url,
      materials: roomData.value.materials
    })
    $q.notify({ type: 'positive', message: 'ROOM情報を更新しました' })
  } catch {
    $q.notify({ type: 'negative', message: 'ROOM更新に失敗しました' })
  }
}
</script>

<style>
.bg-grey-4 {
  background-color: #f5f5f5 !important;
}
.text-grey-7 {
  color: #757575 !important;
}
.bg-grey-2 {
  background-color: #eeeeee !important;
}
.completed-shift {
  background-color: #c8e6c9 !important;
  color: #2e7d32 !important;
}

.reserved-shift {
  background-color: #fff9c4 !important;
  color: #f57f17 !important;
}

.open-shift {
  background-color: #e3f2fd !important;
  color: #1565c0 !important;
}

.provider-link {
  color: #027be3;
  cursor: pointer;
  text-decoration: underline;
}


</style>