<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import { useAuthStore } from 'stores/auth'

const email = ref('')
const password = ref('')
const error = ref(null)
const router = useRouter()
const auth = useAuthStore()

const roleHomeMap = {
  provider: '/provider/history',
  receiver: '/receiver/reservations',
  admin: '/admin/users'
}

const login = async () => {
  error.value = null
  try {
    const res = await axios.post('/auth/login', {
      email: email.value,
      password: password.value
    })

    const {
      id,
      name,
      email: userEmail,
      role,
      access_token,
      token_type,
      line_user_id
    } = res.data

    auth.setAuth(role, {
      id,
      name,
      email: userEmail,
      role,
      token: access_token,
      tokenType: token_type,
      line_user_id
    })

    const targetRoute = roleHomeMap[role] || '/calendar'
    router.push(targetRoute)
  } catch (err) {
    const status = err.response?.status
    const detail = err.response?.data?.detail

    if (status === 403) {
      error.value = detail || 'このアカウントは無効化されています。管理者に連絡してください。'
    } else if (status === 401) {
      error.value = detail || 'ログインに失敗しました。メールアドレスまたはパスワードをご確認ください。'
    } else {
      error.value = 'ログインエラーが発生しました。'
    }
  }
}
</script>

<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">ログイン</div>
    <q-input v-model="email" label="メールアドレス" filled class="q-mb-sm" />
    <q-input v-model="password" label="パスワード" type="password" filled class="q-mb-md" />
    <q-btn label="ログイン" @click="login" color="primary" class="full-width" />
    <div v-if="error" class="text-negative q-mt-md">{{ error }}</div>
  </q-page>
</template>