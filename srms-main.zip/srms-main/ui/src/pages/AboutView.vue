<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">SRMS (Shifts and Reservations Management System)</div>
    <div>バージョン：{{ version }}</div>
  </q-page>
</template>

<script setup>
const version = process.env.APP_VERSION
</script>