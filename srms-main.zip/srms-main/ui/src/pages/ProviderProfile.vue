<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">プロフィール編集</div>

    <q-card>
      <q-card-section>

        <!-- 写真表示 -->
        <div class="q-mb-md">
          <div class="text-subtitle2 q-mb-sm">プロフィール写真</div>
          <q-img
            :src="profile.photo_url || defaultPhoto"
            spinner-color="grey-5"
            style="max-width: 200px; border-radius: 8px;"
          />
        </div>

        <!-- 写真アップロード -->
        <q-file
          v-model="photoFile"
          label="写真を選択"
          accept="image/*"
          filled
          class="q-mb-md"
        />
        <q-btn
          label="アップロード"
          color="primary"
          @click="uploadPhoto"
          :disable="!photoFile"
        />

        <!-- 呼んでほしい名前 -->
        <q-input v-model="profile.name" label="呼んでほしい名前" filled class="q-mt-md" />

        <!-- 職業 -->
        <q-input v-model="profile.job" label="職業" filled class="q-mt-md" />

        <!-- 趣味 -->
        <q-input v-model="profile.hobbies" label="趣味（3つ程度）" filled class="q-mt-md" />

        <!-- 好きなもの -->
        <q-input v-model="profile.likes" label="好きなもの（I Like ...）" filled class="q-mt-md" />

        <!-- 言語 -->
        <div class="q-mt-md">
          <div class="text-subtitle2 q-mb-sm">対応言語</div>
          <q-toggle v-model="profile.lang_ja" label="日本語" />
          <q-toggle v-model="profile.lang_en" label="英語" class="q-ml-md" />
          <q-toggle v-model="profile.lang_other" label="その他" class="q-ml-md" />
        </div>

        <!-- 提供形態 -->
        <div class="q-mt-md">
          <div class="text-subtitle2 q-mb-sm">提供形態</div>
          <q-toggle v-model="profile.in_person" label="対面" />
          <q-toggle v-model="profile.online" label="オンライン" class="q-ml-md" />
        </div>

        <!-- メッセージ -->
        <q-input
          v-model="profile.message"
          label="みなさんへのメッセージ"
          type="textarea"
          autogrow
          filled
          class="q-mt-md"
        />

        <!-- 得意なこと -->
        <q-input
          v-model="profile.skills"
          label="教えられる得意なこと"
          type="textarea"
          autogrow
          filled
          class="q-mt-md"
        />

        <!-- 経歴 -->
        <q-input
          v-model="profile.experience"
          label="今までどんなことをやってきたか"
          type="textarea"
          autogrow
          filled
          class="q-mt-md"
        />

        <!-- 授業のイメージ -->
        <q-input
          v-model="profile.lesson_style"
          label="どんな授業にしたいか"
          type="textarea"
          autogrow
          filled
          class="q-mt-md"
        />

      </q-card-section>

      <q-card-actions align="right">
        <q-btn label="保存" color="primary" @click="saveProfile" />
      </q-card-actions>
    </q-card>

    <q-separator class="q-my-lg" />

    <!-- 振込方法設定 -->
    <q-card>
      <q-card-section>
        <div class="text-h6 q-mb-md">振込方法</div>

        <q-option-group
          v-model="paymentMethod.payment_method"
          :options="[
            { label: '手渡し', value: 'hand' },
            { label: '銀行振込', value: 'bank' },
            { label: 'PayPay', value: 'paypay' },
          ]"
          inline
        />

        <!-- 銀行振込フォーム -->
        <q-form
          v-if="paymentMethod.payment_method === 'bank'"
          ref="bankFormRef"
          greedy
          class="q-mt-md"
        >
          <q-input
            v-model="paymentMethod.bank_name"
            label="銀行名"
            filled
            class="q-mb-sm"
            :rules="[val => !!val || '銀行名を入力してください']"
          />
          <q-input
            v-model="paymentMethod.bank_branch"
            label="支店名"
            filled
            class="q-mb-sm"
            :rules="[val => !!val || '支店名を入力してください']"
          />
          <q-select
            v-model="paymentMethod.bank_account_type"
            label="口座種別"
            :options="['普通', '当座']"
            filled
            class="q-mb-sm"
            :rules="[val => !!val || '口座種別を選択してください']"
          />
          <q-input
            v-model="paymentMethod.bank_account_number"
            label="口座番号"
            filled
            class="q-mb-sm"
            :rules="accountNumberRules"
          />
          <q-input
            v-model="paymentMethod.bank_account_holder"
            label="口座名義"
            filled
            :rules="accountHolderRules"
          />
        </q-form>

        <!-- PayPay ID / 電話番号 -->
        <q-form
          v-if="paymentMethod.payment_method === 'paypay'"
          ref="paypayFormRef"
          greedy
          class="q-mt-md"
        >
          <q-input
            v-model="paymentMethod.paypay_id"
            label="PayPay ID"
            filled
            class="q-mb-sm"
            :rules="paypayIdRules"
          />
          <q-input
            v-model="paymentMethod.paypay_phone_number"
            label="電話番号"
            filled
            class="q-mb-sm"
            :rules="paypayPhoneRules"
          />
          <div class="text-caption text-grey">
            ※ どちらか1つ以上入力してください
          </div>
        </q-form>
      </q-card-section>

      <q-card-actions align="right">
        <q-btn label="振込方法を保存" color="primary" @click="savePaymentMethod" />
      </q-card-actions>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useQuasar } from 'quasar'

const $q = useQuasar()

const defaultPhoto = '/images/default-profile.png'
const photoFile = ref(null)
const bankFormRef = ref(null)
const paypayFormRef = ref(null)

const accountNumberRules = [
  val => !!val || '口座番号を入力してください',
  val => /^[0-9]{7}$/.test(val) || '半角数字7桁で入力してください'
]
const accountHolderRules = [
  val => !!val || '口座名義を入力してください',
  val => /^[ァ-ヶー\u3000]+$/.test(val) || '全角カタカナと全角空白のみで入力してください'
]

const paypayIdRules = [
  () =>
    !!(paymentMethod.value.paypay_id || paymentMethod.value.paypay_phone_number) ||
    'PayPay IDまたは電話番号のいずれかを入力してください',
  (val) => {
    if (!val) return true
    return /^[a-zA-Z0-9_]{3,15}$/.test(val) ||
      'PayPay IDは半角英数字とアンダーバーで3〜15文字で入力してください'
  },
]
const paypayPhoneRules = [
  () =>
    !!(paymentMethod.value.paypay_id || paymentMethod.value.paypay_phone_number) ||
    'PayPay IDまたは電話番号のいずれかを入力してください',
  (val) => {
    if (!val) return true
    const normalized = val.replace(/[-\s]/g, '')
    return /^[0-9]{10,11}$/.test(normalized) || '電話番号は10〜11桁の数字で入力してください'
  },
]

const profile = ref({
  name: '',
  job: '',
  hobbies: '',
  likes: '',
  lang_ja: true,
  lang_en: false,
  lang_other: false,
  in_person: true,
  online: true,
  message: '',
  skills: '',
  experience: '',
  lesson_style: '',
  photo_url: ''
})

const paymentMethod = ref({
  payment_method: 'hand',
  bank_name: '',
  bank_branch: '',
  bank_account_type: '',
  bank_account_number: '',
  bank_account_holder: '',
  paypay_id: '',
  paypay_phone_number: ''
})

onMounted(async () => {
  try {
    const res = await axios.get('/provider/profile')
    Object.assign(profile.value, res.data || {})
  } catch {
    $q.notify({ type: 'negative', message: 'プロフィールの取得に失敗しました' })
  }

  try {
    const res = await axios.get('/provider/payment-method')
    Object.assign(paymentMethod.value, res.data || {})
  } catch {
    // 404の場合はデフォルト値のまま
  }
})

const uploadPhoto = async () => {
  try {
    const formData = new FormData()
    formData.append('file', photoFile.value)

    const res = await axios.post('/provider/photo-upload', formData)
    profile.value.photo_url = res.data.url

    $q.notify({ type: 'positive', message: '写真をアップロードしました' })
  } catch (err) {
    $q.notify({ type: 'negative', message: 'アップロードに失敗しました: ' + err.message })
  }
}

const saveProfile = async () => {
  try {
    await axios.post('/provider/profile', profile.value)
    $q.notify({ type: 'positive', message: 'プロフィールを保存しました' })
  } catch {
    $q.notify({ type: 'negative', message: '保存に失敗しました' })
  }
}

const savePaymentMethod = async () => {
  if (paymentMethod.value.payment_method === 'bank') {
    const valid = await bankFormRef.value.validate()
    if (!valid) return
  }
  if (paymentMethod.value.payment_method === 'paypay') {
    const valid = await paypayFormRef.value.validate()
    if (!valid) return
  }

  const data = { ...paymentMethod.value }
  if (data.paypay_phone_number) {
    data.paypay_phone_number = data.paypay_phone_number.replace(/[-\s]/g, '')
  } else {
    data.paypay_phone_number = null
  }
  if (!data.paypay_id) {
    data.paypay_id = null
  }

  try {
    await axios.post('/provider/payment-method', data)
    $q.notify({ type: 'positive', message: '振込方法を保存しました' })
  } catch {
    $q.notify({ type: 'negative', message: '振込方法の保存に失敗しました' })
  }
}
</script>