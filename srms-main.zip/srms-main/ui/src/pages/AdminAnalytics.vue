<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">稼働状況分析</div>

    <q-card>
      <q-card-section>
        <div>提供者の稼働率グラフ</div>
        <!-- グラフコンポーネントをここに挿入 -->
      </q-card-section>
    </q-card>

    <q-card class="q-mt-md">
      <q-card-section>
        <div>受給者の利用率グラフ</div>
        <!-- グラフコンポーネントをここに挿入 -->
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
// グラフライブラリ連携予定（Chart.jsなど）
</script>