<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">LINE連携結果</div>

    <q-card>
      <q-card-section>
        <div v-if="result.status === 'success'">
          ✅ LINE連携が完了しました<br />
          LINE User ID: {{ result.line_user_id }}<br />
          アプリユーザーID: {{ result.user_id }}
        </div>
        <div v-if="result.status === 'loading'">
            ⏳ LINE連携処理中です...
        </div>

        <div v-else>
          ❌ LINE連携に失敗しました<br />
          {{ result.message }}
        </div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'

const route = useRoute()
const result = ref({ status: 'loading' })

onMounted(async () => {
  const code = route.query.code
  const state = route.query.state

  try {
    const res = await axios.get('/line/callback', {
      params: { code, state }
    })
    result.value = res.data
  } catch {
  // LINE連携エラー
    result.value = {
      status: 'error',
      message: 'API呼び出しに失敗しました'
    }
  }
})
</script>