<template>
  <q-page class="flex flex-center column q-pa-md">
    <q-icon name="error_outline" size="64px" color="negative" />
    <div class="text-h5 q-mt-md">ページが見つかりません</div>
    <q-btn label="トップへ戻る" color="primary" class="q-mt-lg" to="/" />
  </q-page>
</template>

<script setup>
// 404ページはルーティングの最後に設定済み
</script>