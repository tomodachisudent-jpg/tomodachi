<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">サービス提供実績一覧</div>

    <q-table
      :rows="history"
      :columns="columns"
      row-key="id"
      flat
      bordered
    />
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const columns = [
  { name: 'date', label: '日付', field: 'date', format: val => val.slice(0, 10) },
  { name: 'service', label: 'サービス種別', field: 'service' },
  { name: 'duration', label: '提供時間', field: 'duration' },
  { name: 'receiver', label: '利用者', field: 'receiver' }
]

const history = ref([])

onMounted(async () => {
  try {
    const res = await axios.get('/provider/history')
    history.value = res.data
  } catch {
    // 履歴取得失敗
  }
})

</script>
