<template>
  <q-page class="flex flex-center column q-pa-md">
    <q-icon name="lock" size="64px" color="negative" />
    <div class="text-h5 q-mt-md">アクセス権限がありません</div>
    <div class="text-subtitle2 q-mt-sm">このページを表示するには適切なロールが必要です。</div>

    <q-btn
      label="ダッシュボードへ戻る"
      color="primary"
      class="q-mt-lg"
      @click="goHome"
    />
  </q-page>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from 'stores/auth'

const router = useRouter()
const auth = useAuthStore()

const roleHomeMap = {
  provider: '/provider/history',
  receiver: '/receiver/reservations',
  admin: '/admin/users'
}

const goHome = () => {
  const role = auth.userRole
  const target = roleHomeMap[role] || '/calendar'
  router.push(target)
}
</script>