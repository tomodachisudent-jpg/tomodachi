<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">プロフィール編集</div>

    <!-- デスクトップ用バナー（横並び） -->
    <q-banner v-if="isDirty && !$q.screen.lt.md" class="bg-warning text-dark q-mb-md" rounded>
      <div class="row items-center full-width">
        <q-icon name="warning" size="sm" class="q-mr-sm" />
        <span class="text-body2 col-grow"><strong>未保存の変更があります。</strong>下の保存ボタンを押さないと変更は失われます。</span>
        <q-btn flat label="破棄" @click="confirmReset" color="dark" />
      </div>
    </q-banner>

    <!-- スマホ用バナー（縦並び） -->
    <q-banner v-if="isDirty && $q.screen.lt.md" class="bg-warning text-dark q-mb-md" rounded>
      <template v-slot:avatar>
        <q-icon name="warning" size="sm" />
      </template>
      <div class="text-body2">
        <strong>未保存の変更があります。</strong><br />
        下の保存ボタンを押さないと変更は失われます。
      </div>
      <template v-slot:action>
        <q-btn flat label="破棄" @click="confirmReset" color="dark" />
      </template>
    </q-banner>

    <q-card>
      <q-card-section>
        <div class="q-mb-md">
          <div class="text-subtitle2 q-mb-sm">顔写真（笑顔）<span class="text-red">*</span></div>

          <div v-if="profile.profile_photo_url" class="q-mb-md">
            <q-img
              :src="profile.profile_photo_url"
              :class="{ 'field-changed': isFieldChanged('profile_photo_url') }"
              style="max-width: 200px; max-height: 200px; border-radius: 8px"
              fit="contain"
            />
          </div>

          <div class="row q-gutter-sm">
            <q-btn
              label="写真を選択"
              icon="photo_camera"
              color="primary"
              outline
              @click="selectPhoto"
              :loading="uploading"
            />
            <q-btn
              v-if="profile.profile_photo_url"
              label="写真を削除"
              icon="delete"
              color="negative"
              outline
              @click="removePhoto"
            />
          </div>

          <input
            ref="fileInput"
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/gif"
            @change="handlePhotoSelect"
            style="display: none"
          />

          <div v-if="!profile.profile_photo_url" class="text-caption text-red q-mt-sm">
            ※ 顔写真は必須項目です。アップロードしないと保存できません。
          </div>
        </div>

        <q-separator class="q-my-md" />

        <q-input
          v-model="profile.name"
          label="名前 or ニックネーム"
          placeholder="山田太郎"
          filled
          :class="{ 'field-changed': isFieldChanged('name') }"
          class="q-mt-md"
          :rules="[(val) => !!val || '名前 or ニックネームを入力してください']"
        />

        <q-input
          v-model.number="profile.age"
          label="年齢"
          type="number"
          filled
          :class="{ 'field-changed': isFieldChanged('age') }"
          class="q-mt-md"
          :rules="ageRules"
        />

        <q-select
          v-model="profile.gender"
          label="性別"
          :options="genderOptions"
          filled
          :class="{ 'field-changed': isFieldChanged('gender') }"
          class="q-mt-md"
          clearable
        />

        <q-input
          v-model="profile.nationality"
          label="国籍"
          filled
          :class="{ 'field-changed': isFieldChanged('nationality') }"
          class="q-mt-md"
        />

        <q-input
          v-model="profile.self_introduction"
          label="自己紹介"
          type="textarea"
          autogrow
          filled
          :class="{ 'field-changed': isFieldChanged('self_introduction') }"
          class="q-mt-md"
        />

        <q-input
          v-model="profile.learning_goals"
          label="学習目的"
          type="textarea"
          autogrow
          filled
          :class="{ 'field-changed': isFieldChanged('learning_goals') }"
          class="q-mt-md"
        />

        <q-separator class="q-my-md" />

        <div class="text-subtitle1 q-mb-md">追加情報（任意）</div>

        <q-input
          v-model="profile.learning_history"
          label="学習歴"
          type="textarea"
          autogrow
          filled
          :class="{ 'field-changed': isFieldChanged('learning_history') }"
          class="q-mt-md"
          hint="例: 2020年4月〜2022年3月: ABC日本語学校"
        />

        <q-input
          v-model="profile.qualifications"
          label="資格"
          type="textarea"
          autogrow
          filled
          :class="{ 'field-changed': isFieldChanged('qualifications') }"
          class="q-mt-md"
          hint="例: 日本語能力試験 N3（2021年合格）"
        />

        <q-input
          v-model="profile.special_skills"
          label="特技"
          type="textarea"
          autogrow
          filled
          :class="{ 'field-changed': isFieldChanged('special_skills') }"
          class="q-mt-md"
          hint="例: ピアノ演奏、料理（和食）"
        />

        <q-select
          v-model="profile.japanese_level"
          label="日本語のレベル"
          :options="japaneseLevelOptions"
          filled
          :class="{ 'field-changed': isFieldChanged('japanese_level') }"
          clearable
          class="q-mt-md"
        />
      </q-card-section>

      <q-card-actions align="right" class="q-px-md q-pb-md">
        <q-btn
          label="保存"
          color="primary"
          :disable="!canSave"
          :loading="saving"
          @click="saveProfile"
          size="md"
          icon="save"
        />
      </q-card-actions>
    </q-card>

    <!-- 未保存変更のナビゲーションガードダイアログ -->
    <q-dialog v-model="showUnsavedDialog" persistent>
      <q-card>
        <q-card-section class="row items-center">
          <q-avatar icon="warning" color="warning" text-color="dark" />
          <span class="q-ml-sm text-h6">未保存の変更があります</span>
        </q-card-section>

        <q-card-section>
          <p>移動前に変更を保存しますか？</p>
        </q-card-section>

        <q-card-actions :vertical="$q.screen.lt.md" :align="$q.screen.lt.md ? '' : 'right'">
          <q-btn
            label="💾 保存して移動"
            color="primary"
            @click="handleNavigationChoice('save')"
            :class="$q.screen.lt.md ? 'q-mb-sm' : 'q-mr-sm'"
          />
          <q-btn
            label="🗑️ 破棄して移動"
            color="negative"
            @click="handleNavigationChoice('discard')"
            :class="$q.screen.lt.md ? 'q-mb-sm' : 'q-mr-sm'"
          />
          <q-btn
            label="✕ キャンセル"
            color="grey"
            outline
            @click="handleNavigationChoice('cancel')"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, computed, onMounted, watch, onUnmounted } from 'vue'
import { onBeforeRouteLeave } from 'vue-router'
import axios from 'axios'
import { useQuasar } from 'quasar'
import { isEqual } from 'lodash-es'
import { useUnsavedStore } from 'stores/unsaved'

const $q = useQuasar()
const unsavedStore = useUnsavedStore()

const genderOptions = ['男性', '女性', 'その他', '無回答']
const japaneseLevelOptions = ['初心者', '中級者', '上級者']

const profile = ref({
  name: '',
  age: null,
  gender: '',
  nationality: '',
  self_introduction: '',
  learning_goals: '',
  profile_photo_url: '',
  learning_history: '',
  qualifications: '',
  special_skills: '',
  japanese_level: '',
})

const originalProfile = ref(null)
const uploading = ref(false)
const saving = ref(false)
const fileInput = ref(null)

const ageRules = [
  (val) =>
    val === null ||
    val === '' ||
    val === undefined ||
    !isNaN(Number(val)) ||
    '年齢は数値で入力してください',
  (val) =>
    val === null ||
    val === '' ||
    val === undefined ||
    Number(val) > 0 ||
    '正の数値を入力してください',
]

const isDirty = computed(() => {
  if (!originalProfile.value) return false
  return !isEqual(profile.value, originalProfile.value)
})

const canSave = computed(() => {
  return isDirty.value && profile.value.profile_photo_url
})

const isFieldChanged = (fieldName) => {
  if (!originalProfile.value) return false
  return profile.value[fieldName] !== originalProfile.value[fieldName]
}

const extractDetailMessage = (detail) => {
  if (Array.isArray(detail) && detail.length > 0) {
    const first = detail[0]
    if (typeof first === 'string') return first
    if (first?.msg) return first.msg
  }
  if (typeof detail === 'string') return detail
  return null
}

const notifyApiError = (error, fallbackMessage) => {
  if (!error || !error.response) {
    $q.notify({ type: 'negative', message: 'ネットワークエラーが発生しました' })
    return
  }

  const status = error.response.status
  const detail = error.response.data?.detail
  const detailMessage = extractDetailMessage(detail)

  if (status === 401) {
    $q.notify({ type: 'negative', message: '認証が必要です' })
    return
  }

  if (status === 403) {
    $q.notify({ type: 'negative', message: '権限がありません' })
    return
  }

  if (detailMessage) {
    $q.notify({ type: 'negative', message: detailMessage })
    return
  }

  $q.notify({ type: 'negative', message: fallbackMessage })
}

const selectPhoto = () => {
  fileInput.value?.click()
}

const removePhoto = () => {
  profile.value.profile_photo_url = ''
}

const handlePhotoSelect = async (event) => {
  const file = event.target.files?.[0]
  if (!file) return

  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif']
  if (!allowedTypes.includes(file.type)) {
    $q.notify({
      type: 'negative',
      message: '対応している画像形式（JPG、PNG、GIF）を選択してください',
    })
    return
  }

  const maxSize = 5 * 1024 * 1024
  if (file.size > maxSize) {
    $q.notify({
      type: 'negative',
      message: `ファイルサイズは5MB以下にしてください。現在のサイズ: ${(file.size / (1024 * 1024)).toFixed(2)}MB`,
    })
    return
  }

  uploading.value = true
  try {
    const formData = new FormData()
    formData.append('file', file)

    const res = await axios.post('/receiver/profile-photo', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })

    profile.value.profile_photo_url = res.data.url
    $q.notify({ type: 'positive', message: '写真をアップロードしました' })
  } catch (error) {
    notifyApiError(error, '写真のアップロードに失敗しました')
  } finally {
    uploading.value = false
    if (fileInput.value) {
      fileInput.value.value = ''
    }
  }
}

const loadProfile = async () => {
  try {
    const res = await axios.get('/receiver/profile')
    const data = res.data || {}
    profile.value = { ...profile.value, ...data }
    originalProfile.value = JSON.parse(JSON.stringify(profile.value))
  } catch (error) {
    notifyApiError(error, 'プロフィールの取得に失敗しました')
  }
}

const saveProfile = async () => {
  if (!profile.value.profile_photo_url) {
    $q.notify({ type: 'negative', message: '顔写真をアップロードしてください' })
    return
  }

  saving.value = true
  try {
    const payload = {
      name: profile.value.name,
      age: profile.value.age === '' ? null : profile.value.age,
      gender: profile.value.gender,
      nationality: profile.value.nationality,
      self_introduction: profile.value.self_introduction,
      learning_goals: profile.value.learning_goals,
      profile_photo_url: profile.value.profile_photo_url,
      learning_history: profile.value.learning_history,
      qualifications: profile.value.qualifications,
      special_skills: profile.value.special_skills,
      japanese_level: profile.value.japanese_level,
    }
    await axios.post('/receiver/profile', payload)

    originalProfile.value = JSON.parse(JSON.stringify(profile.value))

    $q.notify({ type: 'positive', message: 'プロフィールを保存しました' })
  } catch (error) {
    notifyApiError(error, '保存に失敗しました')
  } finally {
    saving.value = false
  }
}

const resetForm = () => {
  if (originalProfile.value) {
    profile.value = JSON.parse(JSON.stringify(originalProfile.value))
  }
}

const confirmReset = () => {
  $q.dialog({
    title: '確認',
    message: '変更を破棄してもよろしいですか？',
    cancel: {
      flat: true,
      label: 'キャンセル',
    },
    ok: {
      label: '破棄',
      color: 'negative',
    },
    persistent: true,
  }).onOk(() => {
    resetForm()
    $q.notify({ type: 'info', message: '変更を破棄しました' })
  })
}

// 未保存変更のナビゲーションガード用ダイアログ
const showUnsavedDialog = ref(false)
const nextRoute = ref(null)

const handleNavigationChoice = async (choice) => {
  showUnsavedDialog.value = false

  if (choice === 'save') {
    await saveProfile()
    if (nextRoute.value) {
      nextRoute.value()
    }
  } else if (choice === 'discard') {
    if (nextRoute.value) {
      nextRoute.value()
    }
  } else {
    // キャンセル
    if (nextRoute.value) {
      nextRoute.value(false)
    }
  }
  nextRoute.value = null
}

onBeforeRouteLeave((to, from, next) => {
  if (isDirty.value) {
    nextRoute.value = next
    showUnsavedDialog.value = true
  } else {
    next()
  }
})

watch(
  isDirty,
  (dirty) => {
    if (dirty) {
      window.onbeforeunload = () => true
      // グローバルストアに未保存状態を登録
      unsavedStore.registerUnsaved(saveProfile, resetForm)
    } else {
      window.onbeforeunload = null
      // グローバルストアから未保存状態を解除
      unsavedStore.clearUnsaved()
    }
  },
  { immediate: true },
)

onUnmounted(() => {
  window.onbeforeunload = null
  // ページを離れる際に未保存状態をクリア
  unsavedStore.clearUnsaved()
})

onMounted(() => {
  loadProfile()
})
</script>

<style scoped>
.field-changed :deep(.q-field__control) {
  border: 2px solid #4caf50 !important;
  border-radius: 4px;
}

.field-changed :deep(.q-field__control):before {
  border-color: #4caf50 !important;
}

.field-changed.q-img {
  border: 3px solid #4caf50;
  padding: 4px;
  border-radius: 12px;
}
</style>
