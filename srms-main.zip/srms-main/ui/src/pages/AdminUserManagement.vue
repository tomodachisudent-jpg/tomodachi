<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">ユーザー管理</div>

    <q-table
      :rows="users"
      :columns="columns"
      row-key="id"
      flat
      bordered
      class="q-mb-md"
    >
      <template v-slot:body-cell-role="props">
        <span>
          {{
            props.row.role === 'provider' ? '先生'
            : props.row.role === 'receiver' ? '学生'
            : props.row.role === 'admin' ? '運営'
            : props.row.role
          }}
        </span>
      </template>
      <template v-slot:body-cell-actions="props">
        <q-btn
          icon="edit"
          color="primary"
          flat
          dense
          @click="openEditDialog(props.row)"
        />
        <q-btn
          icon="delete"
          color="negative"
          flat
          dense
          @click="confirmDelete(props.row.id)"
          :disable="props.row.id === currentUserId"
        />
      </template>
      <template v-slot:body-cell-line_linked="props">
        <q-icon
          :name="props.row.line_linked ? 'check_circle' : 'cancel'"
          :color="props.row.line_linked ? 'green' : 'grey'"
        />
      </template>
    </q-table>

    <q-btn label="新規ユーザー追加" color="primary" @click="dialog = true" />

    <!-- 登録フォーム -->
    <q-dialog v-model="dialog">
      <q-card style="min-width: 400px">
        <q-card-section>
          <div class="text-h6">ユーザー登録</div>
          <q-input v-model="form.display_name" label="氏名" filled class="q-mt-md" />
          <q-input v-model="form.email" label="メールアドレス" filled class="q-mt-md" />
          <q-select
            v-model="form.role"
            :options="roleOptions"
            label="ロール"
            filled
            class="q-mt-md"
            emit-value
            map-options
          />
          <q-input
            v-if="form.role === 'provider'"
            v-model="form.hourly_rate_offline"
            label="オフライン時給"
            type="number"
            filled
            class="q-mt-md"
          />
          <q-input
            v-if="form.role === 'provider'"
            v-model="form.hourly_rate_online"
            label="オンライン時給"
            type="number"
            filled
            class="q-mt-md"
          />
          <q-input
            v-if="form.role === 'receiver'"
            v-model="form.notes"
            label="備考"
            filled
            class="q-mt-md"
          />
          <q-input v-model="form.slack_webhook" label="Slack Webhook URL" filled class="q-mt-md" />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="キャンセル" v-close-popup />
          <q-btn label="登録" color="primary" @click="submitUser" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- 登録結果 -->
    <q-dialog v-model="resultDialog">
      <q-card>
        <q-card-section>
          <div class="text-h6">ユーザー登録完了</div>
          <div class="q-mt-md">初期パスワード: <strong>{{ generatedPassword }}</strong></div>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- 編集ダイアログ -->
    <q-dialog v-model="editDialog">
      <q-card style="min-width: 400px">
        <q-card-section>
          <div class="text-h6">ユーザー編集</div>
          <div class="q-mt-sm">氏名: {{ selectedUser?.display_name }}</div>
          <div class="q-mt-sm">メール: {{ selectedUser?.email }}</div>

          <q-select
            v-model="selectedUser.role"
            :options="roleOptions"
            label="ロール変更"
            filled
            class="q-mt-md"
            emit-value
            map-options
          />

          <q-btn
            label="パスワード再発行"
            color="secondary"
            class="q-mt-md"
            @click="resetUserPassword(selectedUser.id)"
          />

          <div v-if="resetPassword" class="q-mt-sm">
            新パスワード: <strong>{{ resetPassword }}</strong>
          </div>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup />
          <q-btn label="保存" color="primary" @click="updateUserRole" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useQuasar } from 'quasar'

const $q = useQuasar()
const users = ref([])
const dialog = ref(false)
const resultDialog = ref(false)
const generatedPassword = ref('')
const currentUserId = ref(null)

const editDialog = ref(false)
const selectedUser = ref(null)
const resetPassword = ref('')

const form = ref({
  display_name: '',
  email: '',
  role: '',
  hourly_rate_offline: 2000,
  hourly_rate_online: 1800,
  notes: '',
  slack_webhook: ''
})

// ✅ ロール選択肢（表示名付き）
const roleOptions = [
  { label: '先生', value: 'provider' },
  { label: '学生', value: 'receiver' },
  { label: '運営', value: 'admin' }
]


const columns = [
  { name: 'display_name', label: '氏名', field: 'display_name' },
  { name: 'email', label: 'メールアドレス', field: 'email' },
  { name: 'role', label: 'ロール', field: 'role' },
  { name: 'line_linked', label: 'LINE連携', field: 'line_linked' },
  { name: 'actions', label: '操作', field: 'id' }
]

const fetchUsers = async () => {
  try {
    const res = await axios.get('/admin/users')
    users.value = res.data
  } catch (err) {
    $q.notify({ type: 'negative', message: err.response?.data?.detail || '読込失敗' })
  }
}

const fetchCurrentUser = async () => {
  try {
    const res = await axios.get('/me')
    currentUserId.value = parseInt(res.data.user_id)
  } catch (err) {
    $q.notify({ type: 'negative', message: err.response?.data?.detail || '読込失敗' })
  }
}

const submitUser = async () => {
  try {
    const res = await axios.post('/admin/users', form.value)
    generatedPassword.value = res.data.generated_password
    dialog.value = false
    resultDialog.value = true
    await fetchUsers()
  } catch (err) {
    $q.notify({ type: 'negative', message: err.response?.data?.detail || '登録失敗' })
  }
}

const confirmDelete = (id) => {
  $q.dialog({
    title: '確認',
    message: 'このユーザーを削除しますか？',
    cancel: true,
    persistent: true
  }).onOk(() => deleteUser(id))
}

const deleteUser = async (id) => {
  try {
    await axios.delete(`/admin/users/${id}`)
    await fetchUsers()
    $q.notify({ type: 'positive', message: '削除しました' })
  } catch (err) {
    $q.notify({ type: 'negative', message: err.response?.data?.detail || '削除失敗' })
  }
}

const openEditDialog = (user) => {
  selectedUser.value = { ...user }
  resetPassword.value = ''
  editDialog.value = true
}

const updateUserRole = async () => {
  try {
    await axios.patch(`/admin/users/${selectedUser.value.id}/role`, selectedUser.value.role, {
      headers: { 'Content-Type': 'application/json' }
    })
    $q.notify({ type: 'positive', message: 'ロールを更新しました' })
    editDialog.value = false
    await fetchUsers()
  } catch (err) {
    $q.notify({ type: 'negative', message: err.response?.data?.detail || '更新失敗' })
  }
}

const resetUserPassword = async (userId) => {
  try {
    const res = await axios.post(`/admin/users/${userId}/reset-password`)
    resetPassword.value = res.data.generated_password
    $q.notify({ type: 'positive', message: 'パスワードを再発行しました' })
  } catch (err) {
    $q.notify({ type: 'negative', message: err.response?.data?.detail || '再発行失敗' })
  }
}

onMounted(() => {
  fetchUsers()
  fetchCurrentUser()
})
</script>