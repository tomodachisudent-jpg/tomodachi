<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">予約一覧</div>

    <!-- 今月のキャンセル回数バナー -->
    <q-banner
      :class="cancelLimitReached ? 'bg-negative text-white' : 'bg-blue-1 text-dark'"
      class="q-mb-md"
      rounded
    >
      <template v-slot:avatar>
        <q-icon :name="cancelLimitReached ? 'warning' : 'info'" />
      </template>
      今月のキャンセル回数: {{ cancelCount }}回 / {{ cancelLimit }}回
      <span v-if="cancelLimitReached" class="q-ml-sm text-weight-bold">
        （上限に達しています）
      </span>
    </q-banner>

    <!-- 過去の予約表示トグル -->
    <div class="q-mb-md">
      <q-toggle v-model="showPast" label="過去の予約を表示する" />
    </div>

    <q-table
      :rows="filteredReservations"
      :columns="columns"
      row-key="id"
      flat
      bordered
      :loading="loading"
    >
      <!-- キャンセルボタン列 -->
      <template v-slot:body-cell-cancel="props">
        <q-td :props="props">
          <template v-if="props.row.status === 'reserved' && !isPastStart(props.row)">
            <q-btn
              label="キャンセル"
              color="negative"
              flat
              dense
              :disable="cancelLimitReached"
              @click="openCancelDialog(props.row)"
            >
              <q-tooltip v-if="cancelLimitReached">
                今月のキャンセル上限に達しました。キャンセルをご希望の場合は、運営にお問い合わせください。
              </q-tooltip>
            </q-btn>
          </template>
        </q-td>
      </template>
    </q-table>

    <!-- キャンセル確認ダイアログ -->
    <q-dialog v-model="cancelDialog" persistent>
      <q-card style="min-width: 350px">
        <q-card-section class="bg-grey-2">
          <div class="text-h6">予約キャンセルの確認</div>
        </q-card-section>

        <q-card-section v-if="selectedReservation">
          <!-- 予約詳細 -->
          <q-list dense class="q-mb-md">
            <q-item>
              <q-item-section>
                <q-item-label overline>日時</q-item-label>
                <q-item-label>{{ formatDatetime(selectedReservation.start_at, selectedReservation.end_at) }}</q-item-label>
              </q-item-section>
            </q-item>
            <q-item>
              <q-item-section>
                <q-item-label overline>形式</q-item-label>
                <q-item-label>{{ selectedReservation.s_type === 'online' ? 'オンライン' : '対面' }}</q-item-label>
              </q-item-section>
            </q-item>
            <q-item>
              <q-item-section>
                <q-item-label overline>講師</q-item-label>
                <q-item-label>{{ selectedReservation.provider_name }}</q-item-label>
              </q-item-section>
            </q-item>
          </q-list>

          <!-- キャンセル料案内 -->
          <q-banner
            :class="cancelFeeClass"
            rounded
            dense
            class="q-mb-md"
          >
            <template v-slot:avatar>
              <q-icon :name="cancelFeeIcon" />
            </template>
            <div class="text-weight-bold">キャンセル料: {{ cancelFeeLabel }}</div>
            <div class="text-caption q-mt-xs">{{ cancelFeeDescription }}</div>
          </q-banner>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup :disable="canceling" />
          <q-btn
            label="キャンセルする"
            color="negative"
            :loading="canceling"
            @click="executeCancel"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useQuasar } from 'quasar'
import { axios } from 'src/boot/axios'

const $q = useQuasar()

// --- 状態 ---
const reservations = ref([])
const loading = ref(false)
const showPast = ref(false)
const cancelCount = ref(0)
const cancelLimit = ref(3)
const cancelDialog = ref(false)
const selectedReservation = ref(null)
const canceling = ref(false)

// --- 算出プロパティ ---

/** 上限到達フラグ */
const cancelLimitReached = computed(() => cancelCount.value >= cancelLimit.value)

/** トグルに応じて過去予約をフィルタ */
const filteredReservations = computed(() => {
  if (showPast.value) return reservations.value
  const todayStart = new Date()
  todayStart.setHours(0, 0, 0, 0)
  return reservations.value.filter((r) => new Date(r.start_at) >= todayStart)
})

/** キャンセル料区分: 'free' | 'partial' | 'full' */
const cancelFeeType = computed(() => {
  if (!selectedReservation.value) return 'free'
  const now = new Date()
  const start = new Date(selectedReservation.value.start_at)
  const diffMs = start - now
  const diffHours = diffMs / (1000 * 60 * 60)

  if (selectedReservation.value.s_type === 'online') {
    // オンライン: 6時間超前=無料, 6時間以内=20%, 開始後=全額
    if (diffMs < 0) return 'full'
    if (diffHours <= 6) return 'partial'
    return 'free'
  } else {
    // 対面: 7日超前=無料, 7日前〜前日=20%, 当日=全額
    const startDateJST = new Date(start.getTime() + 9 * 60 * 60 * 1000)
    const nowJST = new Date(now.getTime() + 9 * 60 * 60 * 1000)
    const isSameDay =
      startDateJST.getUTCFullYear() === nowJST.getUTCFullYear() &&
      startDateJST.getUTCMonth() === nowJST.getUTCMonth() &&
      startDateJST.getUTCDate() === nowJST.getUTCDate()
    if (diffMs < 0 || isSameDay) return 'full'
    const diffDays = diffHours / 24
    if (diffDays <= 7) return 'partial'
    return 'free'
  }
})

const cancelFeeLabel = computed(() => {
  const map = { free: '無料', partial: '受講料の20%', full: '受講料の全額' }
  return map[cancelFeeType.value]
})

const cancelFeeDescription = computed(() => {
  if (!selectedReservation.value) return ''
  const stype = selectedReservation.value.s_type === 'online' ? 'オンライン' : '対面'
  const feeMap = {
    free: `${stype}授業のため、現時点ではキャンセル料はかかりません。`,
    partial: `${stype}授業のキャンセル料として受講料の20%が発生します。`,
    full: `${stype}授業のキャンセル料として受講料の全額が発生します。`,
  }
  return feeMap[cancelFeeType.value]
})

const cancelFeeClass = computed(() => {
  const map = {
    free: 'bg-positive text-white',
    partial: 'bg-warning text-dark',
    full: 'bg-negative text-white',
  }
  return map[cancelFeeType.value]
})

const cancelFeeIcon = computed(() => {
  const map = { free: 'check_circle', partial: 'warning', full: 'error' }
  return map[cancelFeeType.value]
})

// --- テーブル列定義 ---
const columns = [
  {
    name: 'start_at',
    label: '日時',
    field: (row) => formatDatetime(row.start_at, row.end_at),
    sortable: true,
  },
  { name: 'provider_name', label: '提供者', field: 'provider_name' },
  {
    name: 's_type',
    label: '形式',
    field: (row) => (row.s_type === 'online' ? 'オンライン' : '対面'),
  },
  {
    name: 'status',
    label: 'ステータス',
    field: (row) => {
      const map = { reserved: '予約済み', canceled: 'キャンセル', completed: '完了' }
      return map[row.status] ?? row.status
    },
  },
  {
    name: 'cancel',
    label: '',
    field: 'cancel',
    align: 'center',
  },
]

// --- ヘルパー ---

/** 授業開始日時が現在時刻を過ぎているか判定 */
function isPastStart(row) {
  return new Date(row.start_at) <= new Date()
}

/** ISO日時文字列をJST表示形式に変換 */
function toJST(iso) {
  const d = new Date(iso)
  const jst = new Date(d.getTime() + 9 * 60 * 60 * 1000)
  const yyyy = jst.getUTCFullYear()
  const mm = String(jst.getUTCMonth() + 1).padStart(2, '0')
  const dd = String(jst.getUTCDate()).padStart(2, '0')
  const hh = String(jst.getUTCHours()).padStart(2, '0')
  const min = String(jst.getUTCMinutes()).padStart(2, '0')
  return { date: `${yyyy}/${mm}/${dd}`, time: `${hh}:${min}` }
}

function formatDatetime(startAt, endAt) {
  const s = toJST(startAt)
  const e = toJST(endAt)
  return `${s.date} ${s.time} - ${e.time}`
}

// --- アクション ---

/** キャンセル回数を取得 */
async function fetchCancelCount() {
  try {
    const { data } = await axios.get('/receiver/cancel-count')
    cancelCount.value = data.count
    cancelLimit.value = data.limit
  } catch {
    // 取得失敗は無視（表示はデフォルト値を使用）
  }
}

/** 予約一覧を取得 */
async function fetchReservations() {
  loading.value = true
  try {
    const { data } = await axios.get('/receiver/reservations')
    reservations.value = data
  } finally {
    loading.value = false
  }
}

/** キャンセルダイアログを開く */
function openCancelDialog(row) {
  selectedReservation.value = row
  cancelDialog.value = true
}

/** キャンセルを実行 */
async function executeCancel() {
  if (!selectedReservation.value) return
  canceling.value = true
  try {
    await axios.post(`/receiver/reservations/${selectedReservation.value.id}/cancel`)
    cancelDialog.value = false
    $q.notify({ type: 'positive', message: '予約をキャンセルしました' })
    // 一覧とキャンセル回数を再取得
    await Promise.all([fetchReservations(), fetchCancelCount()])
  } catch (err) {
    const detail =
      err.response?.data?.detail ||
      'キャンセルに失敗しました。しばらくしてから再度お試しください。'
    $q.notify({ type: 'negative', message: detail })
  } finally {
    canceling.value = false
  }
}

// --- 初期化 ---
onMounted(async () => {
  await Promise.all([fetchReservations(), fetchCancelCount()])
})
</script>
