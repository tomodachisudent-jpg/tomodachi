<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">ROOM情報</div>

    <!-- 会議URL（autogrow付き） -->
    <q-input
      v-model="roomData.meeting_url"
      label="会議URL"
      type="textarea"
      autogrow
      filled
      readonly
      class="q-mt-md"
      style="max-width: 100%;"
    />

    <!-- 資料URL（autogrow付き） -->
    <q-input
      v-model="roomData.materials"
      label="資料URL"
      type="textarea"
      autogrow
      filled
      readonly
      class="q-mt-md"
      style="max-width: 100%;"
    />

    <q-separator class="q-my-md" />

    <div class="text-subtitle1">コメント</div>
    <div v-for="comment in roomComments" :key="comment.created_at" class="q-mt-sm">
      <div class="text-caption text-grey">
        {{ comment.display_name }}（{{ formatDateTime(comment.created_at) }}）
      </div>
      <div>{{ comment.content }}</div>
    </div>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'
import { useQuasar, date } from 'quasar'

const $q = useQuasar()
const route = useRoute()
const shiftId = route.params.shiftId

const roomData = ref({})
const roomComments = ref([])

onMounted(async () => {
  try {
    const roomRes = await axios.get(`/rooms/${shiftId}`)
    roomData.value = roomRes.data

    const commentRes = await axios.get(`/rooms/${roomRes.data.id}/comments`)
    roomComments.value = commentRes.data
  } catch {
    $q.notify({ type: 'negative', message: 'ROOM情報の取得に失敗しました' })
  }
})

function formatDateTime(dt) {
  return date.formatDate(dt, 'YYYY/MM/DD HH:mm')
}
</script>