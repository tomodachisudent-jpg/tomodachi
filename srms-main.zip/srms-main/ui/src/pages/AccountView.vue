<script setup>
import { ref } from 'vue'
import { useAuthStore } from 'stores/auth'
import axios from 'axios'

const auth = useAuthStore()
const name = ref(auth.userInfo.name || '')
const email = ref(auth.userInfo.email || '')
const password = ref('')
const dialog = ref(false)
const resultMessage = ref('')

const save = () => {
  // 保存処理（未実装）
}

// User Info

const linkLine = () => {
  const clientId = '2008108336'
  const redirectUri = encodeURIComponent(`${window.location.origin}/api/line/callback`)
  const state = auth.userInfo.id
  const lineUrl = `https://access.line.me/oauth2/v2.1/authorize?response_type=code&client_id=${clientId}&redirect_uri=${redirectUri}&state=${state}&scope=openid%20profile`
  window.location.href = lineUrl
}

const sendLineTest = async () => {
  try {
    const res = await axios.post('/line/test-notify')
    resultMessage.value = res.data.message || '通知を送信しました'
  } catch  {
  // LINE通知エラー
    resultMessage.value = '通知送信に失敗しました'
  } finally {
    dialog.value = true
  }
}
</script>

<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">アカウント情報</div>
    <q-card>
      <q-card-section>
        <q-input v-model="name" label="氏名" filled />
        <q-input v-model="email" label="メールアドレス" filled class="q-mt-md" />
        <q-input v-model="password" label="パスワード（変更時のみ）" type="password" filled class="q-mt-md" />

        <div class="q-mt-lg">
          <q-btn label="LINE連携する" color="green" @click="linkLine" icon="chat" />
        </div>

        <div class="q-mt-md">
          <q-btn
            label="LINE通知テスト"
            color="blue"
            icon="send"
            :disable="!auth.userInfo.line_user_id"
            @click="sendLineTest"
          />
        </div>
      </q-card-section>

      <q-card-actions align="right">
        <q-btn label="保存" color="primary" @click="save" />
      </q-card-actions>
    </q-card>

    <q-dialog v-model="dialog">
      <q-card>
        <q-card-section>{{ resultMessage }}</q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="閉じる" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>