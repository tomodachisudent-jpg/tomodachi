// src/stores/user.ts
import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', {
  state: () => ({
    role: 'receiver' // 仮のロール（provider / receiver / admin）
  })
})