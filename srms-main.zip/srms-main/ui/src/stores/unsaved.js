import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useUnsavedStore = defineStore('unsaved', () => {
  // 未保存の変更があるかどうか
  const hasUnsavedChanges = ref(false)

  // コールバック関数
  const saveCallback = ref(null)
  const discardCallback = ref(null)

  /**
   * 未保存の変更を登録
   * @param {Function} saveFn - 保存処理を行う関数
   * @param {Function} discardFn - 変更を破棄する関数
   */
  function registerUnsaved(saveFn, discardFn) {
    hasUnsavedChanges.value = true
    saveCallback.value = saveFn
    discardCallback.value = discardFn
  }

  /**
   * 未保存の変更をクリア
   */
  function clearUnsaved() {
    hasUnsavedChanges.value = false
    saveCallback.value = null
    discardCallback.value = null
  }

  /**
   * 保存処理を実行
   */
  async function executeSave() {
    if (saveCallback.value) {
      await saveCallback.value()
    }
    clearUnsaved()
  }

  /**
   * 破棄処理を実行
   */
  function executeDiscard() {
    if (discardCallback.value) {
      discardCallback.value()
    }
    clearUnsaved()
  }

  return {
    hasUnsavedChanges,
    saveCallback,
    discardCallback,
    registerUnsaved,
    clearUnsaved,
    executeSave,
    executeDiscard
  }
})
