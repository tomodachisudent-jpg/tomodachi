import { defineStore } from 'pinia'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    userRole: null,
    isLoggedIn: false,
    userInfo: null
  }),
  actions: {
    setAuth(role, info) {
      this.userRole = role
      this.isLoggedIn = true
      this.userInfo = info

      // 永続化
      localStorage.setItem('userRole', role)
      localStorage.setItem('userInfo', JSON.stringify(info))
      localStorage.setItem('isLoggedIn', 'true')
    },
    logout() {
      this.userRole = null
      this.isLoggedIn = false
      this.userInfo = null

      // 永続化解除
      localStorage.removeItem('userRole')
      localStorage.removeItem('userInfo')
      localStorage.removeItem('isLoggedIn')
    },
    restoreSession() {
      const storedRole = localStorage.getItem('userRole')
      const storedInfo = localStorage.getItem('userInfo')
      const loggedIn = localStorage.getItem('isLoggedIn') === 'true'

      if (loggedIn && storedInfo) {
        this.userRole = storedRole
        this.userInfo = JSON.parse(storedInfo)
        this.isLoggedIn = true
      }
    }
  }
})